<?php

error_reporting(E_ALL);
ini_set('date.timezone','Asia/Shanghai');

if (isset($_GET['_url'])) {
	$_url = explode('/', $_GET['_url']);
    $_GET['_url'] = strtolower(array_shift($_url).'/'.array_shift($_url)).'/'.implode('/', $_url);
}

try {

	/**
	 * Read the configuration
	 */
	$config = include(__DIR__."/../app/config/config.php");

	$loader = new \Phalcon\Loader();

	/**
	 * We're a registering a set of directories taken from the configuration file
	 */
	$loader->registerDirs(
		array(
			$config->application->controllersDir,
			$config->application->modelsDir,
			$config->application->pluginsDir,
			$config->application->libraryDir,
		)
	)->register();

	/**
	 * The FactoryDefault Dependency Injector automatically register the right services providing a full stack framework
	 */
	$di = new \Phalcon\DI\FactoryDefault();
	
	/**
	 * Load router from external file
	 */
	$di->set('router', function(){
		require __DIR__.'/../app/config/routes.php';
		return $router;
	});
	
	$di->set('dispatcher', function() use ($di) {

		$eventsManager = $di->getShared('eventsManager');

		$security = new Security($di);

		/**
		 * We listen for events in the dispatcher using the Security plugin
         */
		$eventsManager->attach('dispatch', $security);

		$dispatcher = new Phalcon\Mvc\Dispatcher();
		$dispatcher->setEventsManager($eventsManager);

		return $dispatcher;
	});
	
	/**
	 * The URL component is used to generate all kind of urls in the application
	 */
	$di->set('url', function() use ($config) {
		$url = new \Phalcon\Mvc\Url();
		$url->setBaseUri($config->application->baseUri);
		return $url;
	});

	/**
	 * Setting up the view component
	 */
	$di->set('view', function() use ($config) {
		$view = new \Phalcon\Mvc\View();
		$view->setViewsDir($config->application->viewsDir);
		$view->registerEngines(array(
			'.phtml' => function($view, $di) {
				$volt = new \Phalcon\Mvc\View\Engine\Volt($view, $di);
				$volt->setOptions(array(
					"compiledPath" => "../app/volt/"
				));
				return $volt;
			}
		));
		return $view;
	});
	
	/**
	 * Database connection is created based in the parameters defined in the configuration file
	 */
	$di->set('db', function() use ($config) {
		$connection = new Oracle(array(
			"host" => $config->database->host,
			"username" => $config->database->core_user,
			"password" => $config->database->password,
			"dbname" => $config->database->name
		));
		$connection->initialize();
	    return $connection;
	});
	
	$di->set('tms', function() use ($config) {
		$connection = new Oracle(array(
			"host" => $config->database->host,
			"username" => $config->database->tms_user,
			"password" => $config->database->password,
			"dbname" => $config->database->name
		));
		$connection->initialize();
	    return $connection;
	});

	/**
	 * If the configuration specify the use of metadata adapter use it or use memory otherwise
	 */
	$di->set('modelsMetadata', function() use ($config) {
		if (isset($config->models->metadata)) {
			$metadataAdapter = 'Phalcon\Mvc\Model\Metadata\\'.$config->models->metadata->adapter;
			return new $metadataAdapter();
		} else {
			return new \Phalcon\Mvc\Model\Metadata\Memory();
		}
	});

	/**
	 * Start the session the first time some component request the session service
	 */
	$di->set('session', function() {
		$session = new \Phalcon\Session\Adapter\Files();
		$session->start();
		return $session;
	});
	
	//Register a user component
	$di->set('elements', function(){
		return new Elements();
	});
	
	//Load a translation file
	$di->setShared('trans', function() use($di, $config) { 
		$session = $di->getShared('session');
		$request = $di->getShared('request');

		// Get language code
		if(!$language = $session->get("language")){
		    // Ask browser what is the best language
		    $language = strtolower($request->getBestLanguage());
		}
		$langPath = realpath('..'.DIRECTORY_SEPARATOR.'app'.DIRECTORY_SEPARATOR.'messages').DIRECTORY_SEPARATOR;
		
		// Check if we have a translation file for that language
		file_exists($langPath.$language.'.php') ? require_once $langPath.$language.'.php' : require_once $langPath.$config->defaultLang.'.php';

		// Return a translation object
		return new \Phalcon\Translate\Adapter\NativeArray(array(
		    "content" => $messages
		));
	});

	/**
	 * Handle the request
	 */
	$application = new \Phalcon\Mvc\Application();
	$application->setDI($di);
	echo $application->handle()->getContent();

} catch (Phalcon\Exception $e) {
	echo $e->getMessage();
} catch (PDOException $e){
	echo $e->getMessage();
}