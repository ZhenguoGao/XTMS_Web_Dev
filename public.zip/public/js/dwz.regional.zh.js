﻿/**
 * @author ZhangHuihua@msn.com
 */
(function($){
	// jQuery validate
	$.extend($.validator.messages, {
		required: "Required",
		remote: "Please fix this field",
		email: "E-mail format is incorrect",
		url: "Please enter a valid URL",
		date: "Please enter a valid date",
		dateISO: "Date Format(ISO).",
		number: "Please enter a valid number",
		digits: "Enter only integer",
		creditcard: "Please enter a valid credit card number",
		equalTo: "Please enter the same value again",
		accept: "Incorrect string suffix",
		maxlength: $.validator.format("Bit length of the longest {0}"),
		minlength: $.validator.format("Bit length at least {0}"),
		rangelength: $.validator.format("Length between {0} to {1}"),
		range: $.validator.format("Value between {0} to {1}"),
		max: $.validator.format("Can not exceed the maximum {0}"),
		min: $.validator.format("Can not be less than the minimum {0}"),
		
		alphanumeric: "Letters, numbers, underscores",
		lettersonly: "Must be a letter",
		phone: "Numbers, spaces, brackets"
	});
	
	// DWZ regional
	$.setRegional("datepicker", {
		dayNames: ['SUN', 'MON', 'TUS', 'WED', 'THU', 'FRI', 'SAT'],
		monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
	});
	$.setRegional("alertMsg", {
		title:{error:"<i class='fa fa-times'></i> Error :", info:"<i class='fa fa-info-circle'></i> Prompt :", warn:"<i class='fa fa-warning'></i> Warning :", correct:"<i class='fa fa-check'></i> Success :", confirm:"<i class='fa fa-question-circle'></i> Confirmation :"},
		butMsg:{ok:"<i class='fa fa-check'></i> OK", yes:"Yes", no:"No", cancel:"<i class='fa fa-times'></i> Cancle"}
	});
})(jQuery);