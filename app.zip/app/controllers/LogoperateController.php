<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class logoperateController extends ControllerBaseSoa2 {
    public $ModelClass = 'LogoperateSoa';

    public function indexAction()
    {
        $model = new $this->ModelClass();
        $operators = unserialize($this->session->get('operators'));
        $actions = unserialize($this->session->get('actions'));
        /**
        if($action = $this->request->get('opCode')){
            $tmpAct = array($action=>$actions[$action]);
            unset($actions[$action]);
            $actions = $tmpAct + $actions;
        }
        **/
        /**
        if($operator = $this->request->get('operator')){
            $tmpOp = array($operator=>$operators[$operator]);
            unset($operators[$operator]);
            $operators = $tmpOp + $operators;
        }
        **/
/**
        if('search' !== $this->request->get('cur_action')){
            $actions = $model->execute(array(), 'op');
            $operators = $model->execute(array(), 'user');
            $allOperators = array();
            foreach ($operators['result'] as $op){
                    $allOperators[$op['username']] = $op['name'];
            }
            $operators = array('all'=>'请选择操作人') + $allOperators;
            $actions = array('all'=>'请选择操作项') + $actions['data'];
            $this->session->set('operators', serialize($operators));
            $this->session->set('actions', serialize($actions));
        }
        **/
        //$operators = array('all'=>'请选择操作人') + $allOperators;
        //$actions['data'] = array('0' => '添加','1' => '修改','2' => '删除');
        //$actions = array('all'=>'请选择操作项') + $actions['data'];
        $actions = array('0'=>'Select Operate','3' => 'Add','1' => 'Modify','2' => 'Delete') ;
        //$this->session->set('operators', serialize($operators));
        //$this->session->set('actions', serialize($actions));
        $operators = array();
        
        $this->view->setVar('operators', $operators);
        $this->view->setVar('actions', $actions);
        
        $this->searchAction();
    }

    public function searchAction()
    {
        $_POST['operator'] = isset($_POST['operator'])? $_POST['operator']:'all';
        $_POST['action'] = isset($_POST['action'])? $_POST['action']:'all';
        Phalcon\Tag::setDefault('operator', $_POST['operator']);
        Phalcon\Tag::setDefault('action', $_POST['action']);//var_dump($_POST['opCode']);die;
        if(empty($_POST['opCode']) || $_POST['opCode'] == NULL)
            $_POST['opCode'] = '0';
        $this->view->setVar('opcode', $_POST['opCode']);
        if($_POST['operator']=='all')
            unset($_POST['operator']);
        if($_POST['opCode']=='all')
            unset($_POST['opCode']);
        parent::searchAction();
    }
}