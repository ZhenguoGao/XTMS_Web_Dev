<?php
/** 
 * 用户管理
 *@author lujun
 */


class UserController extends ControllerBaseSoa2 {
    public $ModelClass = 'UserModel';

    public function searchAction()
    {
        $roles = $this->getrole(true);
        $this->view->setVar('roles',$roles);
        $userIdAlias = $_SESSION['rbac']['idAlias'];
        $ids = explode('.', $userIdAlias);
        if (count($ids) < 4) {
            $this->view->setVar('createFlag', true);
        }
        $model = new $this->ModelClass;
        $volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 20;
        $volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;
        $res=$model->SearchRoute(array_merge($_POST,$volt));
//         $res = $model->findByPost(array_merge($_POST,$volt));
        //         print_r($res);die;
        $volt['numPerPage']=20;
        $volt['count'] = $res['page']['total'];
        $volt['list'] = $res['result'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['rel'] = $this->rel;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/index');//print_r($volt);die;
        $this->view->setVar('volt',$volt);
        
//         parent::searchAction();
    }

    public function createAction()
    {
        $roles = $this->getrole();
        $this->view->setVar('roles',$roles);
        parent::createAction();
        $this->view->pick('user/edit');
    }

    public function editAction($pk)
    {
        $user = new UserNew();
        $info = $user->getInfo($pk);
        $a_role = array($info['roleid'] => $info['name']);
        $roles = $this->getrole();
        $roles = $a_role + $roles;
        $this->view->setVar('roles',$roles);
        parent::updateAction($pk);
        $this->view->pick('user/edit');
    }

    public function getrole($f=false)
    {
        /**
        $roles = $f? array(''=>'全部角色'):array();
        $model = new $this->ModelClass;
        $res = $model->getRole();
        foreach ($res as $tmp) {
            $roles[$tmp['id']] = $tmp['name'];
        }
        $this->view->setVar('roles',$roles);
        **/
        $roles = $f? array(''=>'All roles'):array();
        $mo = new RoleModel();
        $res = $mo->execute(array(),'index');
        foreach ($res['result'] as $tmp)
        {
            $roles[$tmp['id']] = $tmp['name'];
        }

        return $roles;
    }

    public function resetAction($pk)
    {
        $model = new $this->ModelClass;
        $res = $model->execute(array('param'=>array('id'=>$pk)),'reset');
        if(!$res['status']['success'])
            $ret = array('statusCode'=>300,'message'=>"Reset failed：[{$res['status']['errorCode']}] {$res['status']['message']}");
        else
            $ret = array('statusCode'=>200,'message'=>"Reset success",'rel'=>$this->rel);
        echo json_encode($ret);
    }

    public function saveAction()
    {
        $_POST['locked'] = $_POST['Ulocked'];
        $_POST['roleid'] = $_POST['UroleId'];
        $_POST['deptId'] = $_POST['UdeptId'];
        $_POST['password'] = md5('88888888');
        $_POST['parentid'] = $_SESSION['rbac']['id'];
        unset($_POST['Ulocked'],$_POST['UroleId'],$_POST['UdeptId']);
        if($_POST['act'] == 'add') {
            $userIdAlias = $_SESSION['rbac']['idAlias'];
            $ids = explode('.', $userIdAlias);
            if (count($ids) >= 4) {
                $ret = array('statusCode'=>300,'message'=>"Only three levels of user level can be created");

                echo json_encode($ret);
                exit();
            }

            $_POST['userIdAlias'] = $this->aliasName($_POST['usertype']);
        }
        parent::saveAction();
    }
    
    /**
     * 用户别名id
     * '0':'角色用户', '1':'下级用户'
     */
    private function aliasName($userType)
    {
        $userAlias = $_SESSION['rbac']['idAlias'];
        $model = new UserNew();
        if($userType == 0){
            return $userAlias.'';
        }
        $res = $model->getSub();
        return $userAlias.'.'.$res;
    }
}