<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class terminalexceptionController extends ControllerBaseSoa2 {
    public $ModelClass = 'TerminalexceptionSoa';

    public function searchAction()
    {
        $_POST['exceptionFlag'] = isset($_POST['exceptionFlag'])? $_POST['exceptionFlag']:'99';
        $_POST['isSolved'] = isset($_POST['isSolved'])? $_POST['isSolved']:'99';
        Phalcon\Tag::setDefault('exceptionFlag', $_POST['exceptionFlag']);
        Phalcon\Tag::setDefault('isSolved', $_POST['isSolved']);
        if($_POST['exceptionFlag']=='99')
            unset($_POST['exceptionFlag']);
        if($_POST['isSolved']=='99')
            unset($_POST['isSolved']);
        parent::searchAction();
    }
}