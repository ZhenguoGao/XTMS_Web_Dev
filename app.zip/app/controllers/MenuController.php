<?php
/** 
 * 菜单管理
 *@author zhaimin
 */


class MenuController extends ControllerBaseSoa2 {
    public $ModelClass = 'MenuModel';

    public function indexAction()
    {
        $this->getlistAction();
    }

    public function getlistAction()
    {
        $model = new $this->ModelClass;
        $volt['rel'] = $this->rel;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/getlist');
        $lists = $model->execute(array(),'index');
        foreach ($lists['result'] as $list)
        {
            $url = $this->url->get($this->dispatcher->getControllerName().'/get/'.$list['id']);
            $volt['menulist'][] = array('id'=>$list['id'],'pId'=>$list['parentid'],'name'=>$list['name'],'url'=>$url,'open'=>true,'target'=>'ajax');
        }
        $volt['menulist'] = json_encode($volt['menulist']);
        $this->view->setVar('volt',$volt);
    }

    public function getAction($id)
    {
        $model = new $this->ModelClass;
        $volt = $model->findByPk($id);
        $volt = $volt['result'];
        $volt['delete'] = $this->url->get($this->dispatcher->getControllerName().'/remove/'.$id);
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $volt['rel'] = $this->rel;
        $this->view->setVar('volt',$volt);
    }

    public function saveAction()
    {
        if(!preg_match('/^[A-Za-z0-9_\/]*$/',$_POST['link']))
        {
            echo json_encode(array("statusCode"=>"300","message"=>'The links can only be letters, numbers, underscores, and "/"'));
            exit;
        }
        parent::saveAction(false);
    }
}