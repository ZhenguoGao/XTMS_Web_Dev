<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class TermuploadController extends ControllerBaseSoa2{
    public $ModelClass = 'TermuploadSoa';
    public $dir = 'filecache/termupload/';
    protected $linkFailedReason = array();
    protected $dataReceiveFailedReason = array();

    public function initialize()
    {
        parent::initialize();

        // 0-成功,1-人工取消,2-无SIM卡,3-连接失败,4-超时,5-通讯中断
        $this->linkFailedReason = array(0=>'Success', 1=>'Manual cancellation', 2=>'No SIM card', 3=>'Connection failed', 4=>'Time out', 5=>'Comloss');

        // 0-成功,1-人工取消,2-无SIM卡,3-连接失败,4-超时,5-通讯中断
        $this->dataReceiveFailedReason = array(0=>'Success', 1=>'Manual cancellation', 2=>'No SIM card', 3=>'Connection failed', 4=>'Time out', 5=>'Comloss');
    }

    public function indexAction()
    {
        parent::indexAction();
        $this->view->setVar('detailAction', $this->url->get($this->dispatcher->getControllerName().'/detail'));
    }

    public function detailAction($fileUploadId,$machineId,$merchantNo,$terminalNo)
    {
        $model = new $this->ModelClass;
        $volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 20;
        $volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;
        $volt['machineId'] = $machineId;
        $volt['fileUploadId'] = $fileUploadId;

        $res = $model->finddetail($volt);
        if(!$res['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'Search Failed ：'."[{$res['errorCode']}] {$res['error']}")));
        $volt['count'] = $res['totalRows'];
        $volt['rowset'] = $res['data'];
        unset($res);
        foreach ($volt['rowset'] as $key => &$val) {
            $volt['rowset'][$key]['LBS'] = explode(' ', trim($val['LBS']));
            $volt['rowset'][$key]['linkState'] = $this->linkFailedReason[$val['linkState']];
            $volt['rowset'][$key]['recvState'] = $this->dataReceiveFailedReason[$val['recvState']];
            unset($val);
        }
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName()."/detail/{$fileUploadId}/{$machineId}/{$merchantNo}/{$terminalNo}");
        $volt['merchantNo'] = $merchantNo;
        $volt['terminalNo'] = $terminalNo;
        $this->view->setVar('volt',$volt);
    }

    public function createAction()
    {
        $model = new $this->ModelClass;
        $con = $model->getConfig();
        $ctl = new CommonController();
        $volt['machtype'] = $ctl->getmachinetype(array('includeParent'=>0,'supplierId'=>$con->default_supplierid));

        $model = new ApptempletSoa();
        /**
        $ret = $model->findByPost(array('pageNum'=>1,'numPerPage'=>9999));
        $volt['appTemp'] = $ret['data'];
        **/
        $ret = $model->execute(array('page' => array('pageNum'=>1,'pageSize'=>9999),
            'order'=> array('field'=>'name','direction'=>'desc')),'index');
        $volt['appTemp'] = $ret['result'];

        $model = new PublicSoa();
        $ret = $model->execute(array('regionGrade'=>'1','parentId'=>''),'getRegion');
        $volt['province'] = $ret['data'];
        //$volt['regionAction'] = $this->url->get('Common/region');
        $volt['regionAction'] = $this->url->get('Device/region');
        
        $ret1 = $model->execute(array(),'getUser');
        $this->view->setVar('userlist',$ret1['data']);
        $model2 = new DeviceSoa;
        $ret1 = $model2->execute(array('regionGrade'=>'1','parentId'=>'0'),'getGroup');
        $this->view->setVar('group',$ret1['data']);
        $this->view->setVar('groupAction',$this->url->get('device/group'));
        $this->view->setVar('getgroupAction',$this->url->get('device/getgroup/'));
        
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/step2');
        $this->view->setVar('volt',$volt);
    }

    public function step2Action()
    {
        $this->step2searchAction();
        $this->view->pick('updplan/step2');
    }

    public function step2searchAction()
    {
        $post = $_POST;
        $post['merchantNo'] = $_POST['merchantNo2'];
        $post['merchantName'] = $_POST['merchantName2'];
        $post['machineId'] = $_POST['machineId2'];
        $post['terminalNo'] = $_POST['terminalNo2'];
        unset($post['merchantNo2'],$post['merchantName2'],$post['machineId2'],$post['terminalNo2'],$post['mcc'],$post['communicateWay'],$post['packbase1_id'],$post['packbase2_id'],$post['packbase3_id']);

        if(isset($post['regionId']))
            $post['regionId'] = $post['regionId'] == 'all'? '':$post['regionId'];

        //$model = new DeviceSoa();
        $model = new $this->ModelClass;

        $volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 20;
        $volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;
        $volt['orderField'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
        $volt['orderDirection'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];

        $res = $model->findByPost2(array_merge($post,$volt));
        $volt['count'] = $res['totalRows'];
        $volt['rowset'] = $res['data'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['rel'] = $this->dispatcher->getControllerName().'_step2_index';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/step2search');
        $volt['action2'] = $this->url->get($this->dispatcher->getControllerName().'/step3');

        $volt['modelId'] = $_POST['modelId'];
        $volt['appTempId'] = $_POST['appTempId'];
        if(isset($_POST['regionId']))
            $volt['regionId'] = $_POST['regionId'] == 'all'? '':$_POST['regionId'];

        $this->view->setVar('volt',$volt);
        $this->view->pick('updplan/step2search');
    }

    public function step3Action()
    {
        $volt['terminalId'] = implode(',',array_unique($_POST['deleteid']));
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/step4');
        $this->view->setVar('volt',$volt);
    }

    public function step4Action()
    {
        if(isset($_POST['uploadtype']) && count($_POST['uploadtype'])>0)
        {
            $_POST['terminal'] = explode(',',$_POST['terminalId']);
            $model = new $this->ModelClass;
            //$volt = $model->execute($_POST,'add');
            $volt = $model->execute(array('param' => $_POST),'add');
            echo json_encode($volt);
        }
        else
            echo json_encode(array('success'=>false,'error'=>'Please select send content!'));
    }

    public function exportAction($fileUploadId,$machineId,$merchantNo,$terminalNo)
    {
        $model = new $this->ModelClass;
        $volt['numPerPage'] = 2000;
        $volt['pageNum'] = 1;
        $volt['machineId'] = $machineId;
        $volt['fileUploadId'] = $fileUploadId;

        $res = $model->finddetail($volt);
        if(!$res['success']){
            exit('<script>$.pdialog.closeCurrent();alertMsg.error("Getting information failure!");</script>');
        }
        if(empty($res['data'])){
            exit('<script>$.pdialog.closeCurrent();alertMsg.error("NO Data!");</script>');
        }
        try{
            $dir = '../'.$this->dir;
            if (!is_dir($dir)){
                $this->mkdirs($dir);
                chmod($dir, 0777);//改变文件权限
            }

            set_time_limit(0);
            ini_set('memory_limit', '-1');

            $objPHPExcel = new PHPExcel();

            $colname = array('A1'=>'Select machine type', 'B1'=>'Base station information', 'C1'=>'Link time', 'D1'=>'Link interval', 'E1'=>'Link failure reason', 'F1'=>'Send data interval', 'G1'=>'Receive data interval', 'H1'=>'Data receiving end interval', 'I1'=>'Data reception failure reason', 'J1'=>'Disconnect interval', 'K1'=>'Signal intensity');

            $setWidth = array ('A'=>20, 'B'=>25, 'C'=>20, 'D'=>25, 'E'=>25, 'F'=>25, 'G'=>25, 'H'=>25, 'I'=>20, 'J'=>20, 'K'=>20, 'L'=>20, 'M'=>20, 'N'=>20, 'O'=>20, 'P'=>20, 'Q'=>20);

            foreach ( $setWidth as $key => $value ){
                $objPHPExcel->getActiveSheet()->getColumnDimension($key)->setWidth($value);
            }
            foreach ( $colname as $key => $value ){
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue($key,$value);
                $objPHPExcel->setActiveSheetIndex(0)->getStyle($key)->getFont()->setBold(true);
            }

            $j = 2;
            foreach($res['data'] as &$tr){
                $tr['LBS'] = str_replace(' ', "\n",trim($tr['LBS']));
                $tr['linkState'] = $this->linkFailedReason[$tr['linkState']];
                $tr['recvState'] = $this->dataReceiveFailedReason[$tr['recvState']];

                $objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValueExplicit('A'.$j, $machineId)
                    ->setCellValueExplicit('B'.$j, $tr['lbs'])
                    ->setCellValueExplicit('C'.$j, $tr['linkstart'])
                    ->setCellValueExplicit('D'.$j, $tr['linkend'].'ms')
                    ->setCellValueExplicit('E'.$j, $this->getStatus($tr['linkstate']))
                    ->setCellValue('F'.$j, $tr['sendstart'].'ms')
                    ->setCellValue('G'.$j, $tr['recvstart'].'ms')
                    ->setCellValue('H'.$j, $tr['recvend'].'ms')
                    ->setCellValue('I'.$j, $this->getStatus($tr['recvstate']))
                    ->setCellValue('J'.$j, $tr['linkstop'].'ms')
                    ->setCellValue('K'.$j, $tr['sigallevel'].'Byte[s]');
                $objPHPExcel->getActiveSheet()->getStyle("B{$j}")->getAlignment()->setWrapText(true);
                $j++;
                unset($tr);
            }

            unset($res['data']);
            //$objPHPExcel->getActiveSheet()->setTitle("Xnm");
            $objPHPExcel->setActiveSheetIndex(0);

            $guid = $this->_guid();
            $filename = "{$dir}{$guid}.xlsx";
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save($filename);

            $objPHPExcel->disconnectWorksheets();
            unset($objPHPExcel);

            $time = $machineId.'_termupload_'.date('Ymd',time());
            $this->downloadpageAction($guid,"{$time}.xlsx");
            $this->view->pick('templates/downloadpage');
        }
        catch (Exception $e) {  
            exit(json_encode(array('statusCode'=>300, 'message'=>'Export Error')));
        }
    }
    
    public function downloadpageAction($guid,$filename)
    {
    	$this->view->setVar('action',$this->url->get($this->dispatcher->getControllerName()."/download/{$guid}/{$filename}"));
        $this->view->setVar('filename',$filename);
    }
    
    public function downloadAction($guid,$filename)
    {
    	$filePath = $this->url->get("{$this->dir}{$guid}.xlsx");
    	$filePath = $_SERVER['DOCUMENT_ROOT'].$filePath;
    	$contents = '';
    	$ua = $_SERVER["HTTP_USER_AGENT"];
        $encoded_filename = urlencode($filename);
        $encoded_filename = str_replace("+", "%20", $encoded_filename);
    	$this->response->setHeader("Content-Type","application/octet-stream");
    
        if (preg_match("/MSIE/", $ua))
        {
            $this->response->setHeader("Content-Disposition",'attachment; filename="' . $encoded_filename . '"');
        }
        else if (preg_match("/Firefox/", $ua))
        {
            $this->response->setHeader("Content-Disposition",'attachment; filename*="utf8\'\'' . $filename . '"');
        }
        else
        {
            $this->response->setHeader("Content-Disposition",'attachment; filename="'.$filename.'"');
        }
    	if (file_exists($filePath) && ($file=fopen($filePath,"r")))
    	{
            $contents = fread($file,filesize($filePath));
            fclose($file);
    	}
    	echo $contents;
    }
    
    private function getStatus($i){
        switch ($i){
            case 0:
                return 'Success';
            case 1:
                return 'Manual cancellation';
            case 2:
                return 'No SIM card';
            case 3:
                return 'Connection failed';
            case 4:
                return 'Time out';
            case 5:
                return 'Comloss';
        }
    }
}