<?php

/** 
 * @author lujun
 * 
 * 
 */
class PosmonitorController extends ControllerBaseSoa2
{
    public $ModelClass = 'PosmonitorSoa';
}