<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class PackbaseController extends ControllerBaseSoa2
{
    public $ModelClass = 'PackbaseSoa';

    public function indexAction($tp)
    {
        if (!$this->request->isPost()) {
            $_POST['packageType'] = $tp;
            $_POST['resource'] = 'list';
        }
        parent::indexAction();
    }

    public function searchAction()
    {
        $model = new $this->ModelClass;
        $con = $model->getConfig();
        $ctl = new CommonController();
        $res = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid,'parentId'=>0,'modeltype'=>'0'));

        $modelNames = array('all'=>'Select machine type');
        foreach ($res as $re) {
            $modelNames[$re['id']] = $re['name'];
        }
        $this->view->setVar('modelNames',$modelNames);
        $this->view->setVar('packageType',$_POST['packageType']);
        $this->view->setVar('statusText', array(0=>'<b class="clrDkError"><i class="fa fa-times-circle"></i>Processing failure</b>', 1=>'Processing success', 2=>'<b class="clrDark"><i class="fa fa-refresh fa-spin"></i>Processing</b>'));

        $_POST['modelId'] = isset($_POST['modelId'])? $_POST['modelId']:'all';
        Phalcon\Tag::setDefault('modelId', $_POST['modelId']);
        if($_POST['modelId']=='all')
            unset($_POST['modelId']);
        $_POST['record'] = 'all';

        parent::searchAction();
    }

    public function detailAction($id,$packageType)
    {
        $volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 20;
        $volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;

        $volt['id'] = $id;
        $volt['packagetype'] = $packageType;
        if(isset($_POST['fileName']))
            $volt['fileName'] = $_POST['fileName'];
        $model = new $this->ModelClass;
        $res = $model->detail($volt);
        /**
        if(!$res['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'获取失败：'."[{$res['errorCode']}] {$res['error']}")));

        $volt['count'] = $res['totalRows'];
        $volt['rowset'] = $res['data'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/detail/'.$id.'/'.$packageType);
        $this->view->setVar('volt',$volt);
        **/
        $volt['count'] = $res['page']['total'];
        $volt['rowset'] = $res['result'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['rel'] = $this->rel;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/detail/'.$id.'/'.$packageType);
        $this->view->setVar('volt',$volt);
    }

    public function createAction($tp)
    {
        $model = new $this->ModelClass;
        $con = $model->getConfig();
        $ctl = new CommonController();
        $res = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid,'parentId'=>0,'modeltype'=>'0'));
        $volt['modelNames'] = array(''=>'Select machine type');
        foreach ($res as $re)
        {
            $volt['modelNames'][$re['id']] = $re['name'];
        }

        $volt['realPath'] = '../program/';
        $volt['absPath'] = 'program/tmp/';
        $volt['tempPath'] = '../program/tmp/';
        if (!is_dir($volt['tempPath']))
        {
            $this->mkdirs($volt['tempPath']);
            chmod($volt['tempPath'], 0777);//改变文件权限
        }
        $gid = $this->_guid();
        $volt['tempPath'] .= $gid;
        $volt['absPath'] .= $gid;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $volt['packageType'] = $tp;

        $session = $this->session->get('rbac');
        $volt['session'] = $session;
        $volt['session']['tempPath'] = str_replace('\\','/',$volt['tempPath']);
        $volt['session']['absPath'] = str_replace('\\','/',$volt['absPath']);
        $volt['session']['session_keys'] = implode(',',array_keys($session));
        $volt['session'][session_name()] = session_id();
        $volt['session'] = json_encode($volt['session']);
        if(PHP_SAPI == 'fpm-fcgi'){
            $volt['button'] = $this->url->get('uploadify/open.png');
            $volt['swf'] = $this->url->get('uploadify/uploadify.swf');
        } else {
            $volt['button'] = $this->url->get('public/uploadify/open.png');
            $volt['swf'] = $this->url->get('public/uploadify/uploadify.swf');
        }
        $volt['upload'] = $this->url->get($this->dispatcher->getControllerName().'/upload');
        $volt['getinf'] = $this->url->get($this->dispatcher->getControllerName().'/getinf');
        $this->view->setVar('volt',$volt);
        $this->view->setVar('rel',$this->rel);
        $this->view->pick("packbase/create");
    }

    public function reuploadAction($id,$tp)
    {
        $this->createAction($tp);
        $this->view->setVar('id',$id);
        $this->view->setVar('rel',$this->rel.'_reupload');
    }

    public function uploadAction()
    {	
        $model = new $this->ModelClass;
        if (!empty($_FILES))
        {
            $tempfile = $_FILES['Filedata']['tmp_name'];
            $filename = $_FILES["Filedata"]["name"];
            $extend = pathinfo($_FILES["Filedata"]["name"]);
            if(move_uploaded_file($tempfile,$_REQUEST['tempPath'].$_REQUEST['tp'].'.'.$extend[extension]))
            {
                $res = array('filename'=>$filename,'filesize'=>$_FILES["Filedata"]["size"],'uploadfile'=>$_REQUEST['absPath'].$_REQUEST['tp'].'.'.$extend[extension]);
                echo json_encode($res);
            }
            else{
                echo json_encode(array('error'=>'error'));
            }
        }
        else{
            echo json_encode(array('error'=>'error'));
        }
    }

    public function getinfAction()
    {
        $model = new $this->ModelClass;
        $res = $model->execute($_GET,'AllVersion');
        if(!$res['success'])
            echo false;
        else
            echo json_encode($res['data']);
    }

    public function saveAction()
    {
        $_POST['modelId'] = $_POST['model_id'];
        if(empty($_POST['uploadfile'])){
            exit(json_encode(array('statusCode'=>300,'message'=>'Please upload the file package to save!')));
        }
        //parent::saveAction();
        $model = new $this->ModelClass;
        $res = $model->postSave($_POST);
        if(!$res['success'])
            $ret = array('statusCode'=>300,'message'=>'Save Failed ：'."[{$res['errorCode']}] {$res['error']}");
        else
            $ret = array('statusCode'=>200,'message'=>'Save Success ','rel'=>$this->rel,'callbackType'=>'closeCurrent');
        echo json_encode($ret);
    }

    public function archiveAction($id,$tp)
    {
        $volt['id'] = $id;
        $volt['packageType'] = $tp;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/archivesave');
        $this->view->setVar('volt',$volt);
    }

    public function archivesaveAction()
    {
        $model = new $this->ModelClass;
        $res = $model->execute($_POST,'validateArchiveNo');
        if(!$res['success'])
            $ret = array('statusCode'=>300,'message'=>'Save Failed ：'."[{$res['errorCode']}] {$res['error']}");
        else
            $ret = array('statusCode'=>200,'message'=>'Save Success ','rel'=>$this->rel,'callbackType'=>'closeCurrent');
        echo json_encode($ret);
    }
	
}