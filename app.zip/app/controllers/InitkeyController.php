<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class initkeyController extends ControllerBaseSoa {
    public $ModelClass = 'InitkeySoa';

    public function indexAction()
    {
        $this->view->setVar('status',array('99'=>'All','0'=>'Disable','1'=>'Enable'));
        if($this->request->isGet())
            Phalcon\Tag::setDefault('status', '99');
        else
        {
            Phalcon\Tag::setDefault('status', $_POST['status']);
            if($_POST['status']=='99')
                unset($_POST['status']);
        }
        parent::indexAction();
    }

    public function updateAction($pk,$status)
    {
        $stus = array('0'=>'Disable','1'=>'Enable');
        $model = new $this->ModelClass;
        //$volt = $model->findByPk(array('batchno'=>$pk));
        //$volt = $volt['object'];
        $volt['status'] = $status;
        $volt['batchNo'] = $pk;
        $volt['operator'] = $_SESSION['rbac']['username'];
        $rets = $model->execute($volt,'update');

        $log = new \Phalcon\Logger\Adapter\File("../app/logs/initkey.log");
        $msg = "Batch：{$pk}，Operation：{$stus[$status]}，Operator：{$_SESSION['rbac']['username']}";

        if($rets['success'])
        {
            $log->log("【Key state modification】 ---- state：success,".$msg, \Phalcon\Logger::INFO);
            $ret = array('statusCode'=>200,'message'=>'Update Success','rel'=>$this->dispatcher->getControllerName().'_index');
        }
        else
        {
            $log->log("【Key state modification】 ---- state：failed,".$msg, \Phalcon\Logger::INFO);
            $ret = array('statusCode'=>300,'message'=>'Update Failed');
        }
        echo json_encode($ret);exit;
    }

    public function getkeyAction()
    {
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/savekey');
        $this->view->setVar('volt',$volt);
    }
    
    public function tofileAction()
    {
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/savefile');
        $this->view->setVar('volt',$volt);
    }
    public function savekeyAction()
    {
        $config = include(__DIR__."/../config/config.php");
        $model = new $this->ModelClass;
        $LC = '000B';
        $INS = 'F1';
        $SEQ = '00';
        $CR = '0000';
        $cmd = '17';
        $data = str_pad( strtoupper( strval(dechex(intval($_POST['keyIndex']))) ),4,'0',STR_PAD_LEFT ).str_pad(strval(dechex(intval($_POST['keyLength']))),2,'0',STR_PAD_LEFT );
        $CRC = strtoupper(    dechex( (237 ^ intval($_POST['keyIndex'])) ^ intval($_POST['keyLength'])  )    );
        $CRC = str_pad($CRC,2,'0',STR_PAD_LEFT);

        $in = $LC.$INS.$SEQ.$CR.$cmd.$data.$CRC;
        $datain = $model->hexToString($in);

        $post = array('msg'=>$in,'effectiveDate'=>$_POST['effectiveDate'].' 23:59:59','keyLength'=>intval($_POST['keyLength']),'keyIndex'=>intval($_POST['keyIndex']),'operator'=>$_SESSION['rbac']['username']);
        $rets = $model->execute($post, 'get');

        $log = new \Phalcon\Logger\Adapter\File("../app/logs/initkey.log");
        $msg = "Index：{$_POST['keyIndex']}，Length：{$_POST['keyLength']}，Effective Date：{$_POST['effectiveDate']}，Operator：{$_SESSION['rbac']['username']}";

        if($rets['success'])
        {
            $log->log("【Get the key】 ---- state：success,".$msg, \Phalcon\Logger::INFO);
            $ret = array('statusCode'=>200,'message'=>'Obtain success','rel'=>$this->dispatcher->getControllerName().'_index','callbackType'=>'closeCurrent');
        }
        else
        {
            $rtnmsg = 'System error';
            if($rets['rtnMsg']==='07')
                $rtnmsg = 'The encryption machine failed';
            elseif($rets['rtnMsg']==='08')
                $rtnmsg = 'The encryption machine data read timeout';

            $log->log("【Get the key】 ---- state：failed,cause of failure：{$rtnmsg}，".$msg, \Phalcon\Logger::INFO);
            $ret = array('statusCode'=>300,'message'=>"fail to get：{$rtnmsg}",'rel'=>$this->dispatcher->getControllerName().'_index','callbackType'=>'closeCurrent');
        }
        echo json_encode($ret);exit;

        /*
        error_reporting(E_ALL);

        $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        if (!$socket) {
           $ret = array('statusCode'=>300,'message'=>'创建连接失败','rel'=>$this->dispatcher->getControllerName().'_index');
                echo json_encode($ret);exit;
        } 

        $result = socket_connect($socket, $config->initkey->host, $config->initkey->port);
        if (!$result) {
           $ret = array('statusCode'=>300,'message'=>'连接加密机服务失败','rel'=>$this->dispatcher->getControllerName().'_index');
                echo json_encode($ret);exit;
        }
        else
        {
                $keys = array();
                $out = '';
        //socket_set_nonblock($socket); 
        for($i=0; $i<100; $i++) 
        {
                $time = time();
                socket_write($socket, $datain, strlen($datain));
            $out = socket_read($socket,40);
            if ((time() - $time) >= 10 )
            {
                socket_close($socket);
                $ret = array('statusCode'=>300,'message'=>'连接超时','rel'=>$this->dispatcher->getControllerName().'_index');
                                echo json_encode($ret);exit;  
            }
            if( empty($out) || $model->stringToHex(substr($out,7,1 ))!='01' )
            {
                socket_close($socket);
                $ret = array('statusCode'=>300,'message'=>'获取密钥错误，可能是您输入的密钥索引不存在','rel'=>$this->dispatcher->getControllerName().'_index');
                                echo json_encode($ret);exit;  
            }
            else
            {
                $keys[] = $out;
            }
        }
        socket_close($socket);

        if($model->save($keys))
                $ret = array('statusCode'=>200,'message'=>'获取成功','rel'=>$this->dispatcher->getControllerName().'_index','callbackType'=>'closeCurrent');
        else
                        $ret = array('statusCode'=>300,'message'=>'获取失败','rel'=>$this->dispatcher->getControllerName().'_index','callbackType'=>'closeCurrent');
                echo json_encode($ret);exit;
        }
        */
    }
	
    public function savefileAction()
    {
        $model = new $this->ModelClass;
        $key = $model->checkfile($_POST['batchNo']);
        if(!$key['flg'])
        {
            $msg = $key['value']==1? 'There is no such batch number!':'This batch number key file already exists!';
            $ret = array('statusCode'=>400,'message'=>$msg,'rel'=>$this->dispatcher->getControllerName().'_index');
            echo json_encode($ret);exit;
        }

        if (!is_dir('../initkey/'))
        {
            $this->mkdirs('../initkey/');
            chmod('../initkey/', 0777);//改变文件权限
        }

        $file = fopen("../initkey/ICKey{$_POST['batchNo']}.ik","wb");
        for($i=0; $i<100; $i++)
        {
            $batch = str_pad(dechex(intval($_POST['batchNo'])), 4, 0, STR_PAD_LEFT );
            $order = str_pad(dechex(intval($key['value'][$i]['orderNo'])), 4, 0, STR_PAD_LEFT );
            $keylen = str_pad(dechex(strlen($key['value'][$i]['cipherText'])/2), 4, 0, STR_PAD_LEFT );
            $ciphertext = $key['value'][$i]['cipherText'];
            $checkvalue = $key['value'][$i]['checkValue'];
            //$text = $model->hexToString($batch.$order.$keylen.$ciphertext.$checkvalue);
            $text = strtoupper($batch.$order.$keylen.$ciphertext.$checkvalue);
            fputs($file,$text."\n" );
        }
        fclose($file);

        $log = new \Phalcon\Logger\Adapter\File("../app/logs/initkey.log");
        $log->log("【Generate key file】 ---- Batch number：{$_POST['batchNo']}，Operator：{$_SESSION['rbac']['username']}", \Phalcon\Logger::INFO);
        $ret = array('statusCode'=>200,'file'=>"ICKey{$_POST['batchNo']}");
        echo json_encode($ret);exit;
    }
	
    public function downloadAction($filename)
    {
    	$filename .= '.ik';
    	$filePath = $this->url->get("initkey/{$filename}");
    	$filePath = $_SERVER['DOCUMENT_ROOT'].$filePath;
    	$contents = '';
    	$ua = $_SERVER["HTTP_USER_AGENT"];
        $encoded_filename = urlencode($filename);
        $encoded_filename = str_replace("+", "%20", $encoded_filename);
    	$this->response->setHeader("Content-Type","application/octet-stream");
    
        if (preg_match("/MSIE/", $ua))
        {
            $this->response->setHeader("Content-Disposition",'attachment; filename="' . $encoded_filename . '"');
        }
        else if (preg_match("/Firefox/", $ua))
        {
            $this->response->setHeader("Content-Disposition",'attachment; filename*="utf8\'\'' . $filename . '"');
        }
        else
        {
            $this->response->setHeader("Content-Disposition",'attachment; filename="'.$filename.'"');
        }
    	if (file_exists($filePath) && ($file=fopen($filePath,"r")))
    	{
            $contents = fread($file,filesize($filePath));
            fclose($file);
    	}
    	echo $contents;
    }
	
}