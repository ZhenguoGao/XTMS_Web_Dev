<?php

class CommonController extends ControllerBase
{
    public $ModelClass = 'PublicSoa';

    public function IndexAction()
    {
        return;
    }

    public function searchAction()
    {
        return;
    }

    public function createAction()
    {
        return;
    }

    public function updateAction()
    {
        return;
    }

    public function removeAction()
    {
        return;
    }

    public function remove2Action()
    {
        return;
    }

    public function getsupplier()
    {
        $model = new $this->ModelClass;
        $res = $model->execute(array(),"getSupplier");
        return $res['data'];
    }

    public function getmachinetype($post)
    {
        $model = new $this->ModelClass;
        $res = $model->execute($post,"getMachineType");
        return $res['data'];
    }

    public function regionAction($grade,$id)
    {
        $model = new $this->ModelClass;
        $ret = $model->execute(array('regionGrade'=>$grade,'parentId'=>$id),'getRegion');
        $place = array(array($id,'Unlimited'));
        foreach ($ret['data'] as $reg)
        {
            $place[] = array($reg['id'],$reg['regionName']);
        }
        echo json_encode($place); 
    }
    
    public function getmachinetypeAction($includeParent='1',$supplierId='',$parentId='')
    {
    	$model = new $this->ModelClass;
    	$res = $model->execute(array('$includeParent'=>includeParent,'supplierId'=>$supplierId,'parentId'=>$parentId),'getMachineType');
    	return $res['data'];
    }

    public function uploadAction()
    {
        if (!count($_FILES)){
            exit(json_encode(array('error'=>'error')));
        }
        $path = '../program/tmp/';
        if (!is_dir($path)){
            $this->mkdirs($path);

            //改变文件权限
            chmod($path, 0777);
        }
        $name = $this->_guid();
        $uploadfile = $path.$name.'.'.pathinfo($_FILES["Filedata"]["name"], PATHINFO_EXTENSION);
        if(move_uploaded_file($_FILES['Filedata']['tmp_name'], $uploadfile)){
            $this->session->set($name, $uploadfile);
            exit(json_encode(array('originalFilename'=>$_FILES["Filedata"]["name"], 'newFilename'=>$name)));
        }else{
            exit(json_encode(array('error'=>'error', 'message'=>'File upload failed')));
        }
    }

    public function readExcel($filename){
        try{
        $objReader = PHPExcel_IOFactory::createReaderForFile($filename);
        $objPHPExcel = $objReader->load($filename);
        $sheetData = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
        }catch(Exception $e){
            exit(json_encode(array('statusCode'=>'300', 'message'=>$e)));
        }
        $fields = array_shift($sheetData);
    	$data = $tmpData = array();
    	foreach ($sheetData as &$sheetValue) {
            foreach ($sheetValue as $key => &$val) {
                $tmpData[$fields[$key]] = $val;
                unset($key);
                unset($val);
            }
            $data[] = $tmpData;
            unset($sheetValue);
            unset($tmpData);
    	}
    	unset($sheetData);
    	unset($fields);
    	return $data;
    }
}

