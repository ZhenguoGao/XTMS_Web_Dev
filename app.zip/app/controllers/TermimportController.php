<?php

/** 
 * @author lujun
 * 
 *
 */
class TermimportController extends ControllerBaseSoa2
{
    public $ModelClass = 'Termimport';
    
    public function createAction()
    {
        parent::createAction();
        $this->view->pick('termimport/edit');
    }
    
    public function editAction($pk)
    {
        parent::updateAction($pk);
        $this->view->pick('termimport/edit');
    }
    
    public function saveAction()
    {
        $_POST['mersid'] = $_POST['model_mersid'];
        parent::saveAction();
    }
}