<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class paramtempletController extends ControllerBaseSoa
{
    public $ModelClass = 'ParamtempletSoa';

    public function searchAction()
    {
        $model = new $this->ModelClass;
        /**	
        $volt['numPerPage'] = 1000;
        $volt['pageNum'] = 1;
        $volt['orderField'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
        $volt['orderDirection'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];
        
        
        $volt['page']['pageNum'] = 1;
        $volt['page']['pageSize'] = 1000;
        $volt['order']['field'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
        $volt['order']['direction'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];
        //$res = $model->findByPost(array_merge($_POST,$volt));
        $res = $model->execute(array_merge($_POST,$volt),'index');print_r($res);die;
        if(!$res['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'查询失败：'."[{$res['errorCode']}] {$res['error']}")));
        $volt['count'] = $res['totalRows'];
        $volt['rowset'] = $res['data'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['rel'] = $this->rel;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/index');
        **/
        $volt['page']['pageNum'] = 1;
        $volt['page']['pageSize'] = 1000;
        //$volt['order']['field'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
        $volt['order']['field'] = 'id';
        //$volt['order']['direction'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];
        $volt['order']['direction'] ='desc';
        $volt['param']['keywords'] = $this->request->getPost('keywords');
        //$res = $model->findByPost(array_merge($_POST,$volt));
        $res = $model->execute(array_merge($_POST,$volt),'index');
        if(!$res['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'Search Failed ：'."[{$res['errorCode']}] {$res['error']}")));
        $volt['count'] = $res['page']['total'];
        $volt['list'] = $res['result'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['rel'] = $this->rel;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/index');
        
        $this->view->setVar('volt',$volt);
    }

    public function createAction()
    {
        $volt['act'] = "add";
        $volt['title'] = '<i class="fa fa-file"></i> Create parameter template';
        $volt['rel'] = $this->rel;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $volt['paramTemp']['creator'] = $_SESSION['rbac']['username'];
        $this->view->setVar('volt',$volt);
        $this->view->pick('paramtemplet/edit');
    }

    public function updateAction($pk)
    {
        /**
        $model = new $this->ModelClass;
        $res = $model->findByPk($pk);
        if(!$res['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'获取失败：'."[{$res['errorCode']}] {$res['error']}")));
        $volt = $res['data'];
        $volt['act'] = "upd";
        $volt['title'] = '<i class="fa fa-edit"></i> 编辑参数模板';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $volt['reload'] = $this->url->get($this->dispatcher->getControllerName().'/update/'.$pk);
        $volt['rel'] = $this->rel;
        $this->view->setVar('volt',$volt);
        $this->view->pick('paramtemplet/edit');
        **/
        $model = new $this->ModelClass;
        $res = $model->findByPk($pk);
        if(!$res['status']['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'Search Failed '."[{$res['status']['errorCode']}] {$res['status']['message']}")));
        $volt = $res['result'];
        $volt['act'] = "upd";
        $volt['title'] = '<i class="fa fa-edit"></i> Edit';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $volt['reload'] = $this->url->get($this->dispatcher->getControllerName().'/update/'.$pk);
        $volt['rel'] = $this->rel;
        $this->view->setVar('volt',$volt);
        $this->view->pick('paramtemplet/edit');
    }

    public function getitemsAction()
    {
        $model = new ParamitemSoa();
        $volt['numPerPage'] = 1000;
        $volt['pageNum'] = 1;
        $volt['orderField'] = 'number';
        $volt['orderDirection'] = 'asc';

        $res = $model->findByPost(array_merge($_POST,$volt));
        if(!$res['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'Search Failed ：'."[{$res['errorCode']}] {$res['error']}")));
        /**
        $volt['count'] = $res['totalRows'];
        $volt['rowset'] = $res['data'];
        **/
        $volt['count'] = $res['page']['total'];
        $volt['rowset'] = $res['result'];
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/getitems');
        $volt['rel'] = $this->rel;
        $this->view->setVar('volt',$volt);
    }

    public function saveAction()
    {
        $_POST['param'] = array();
        foreach ($_POST['id'] as $id)
        {
            $_POST['param'][] = array('id'=>$id,'defaultValue'=>$_POST['value'][$id]);
        }
        unset($_POST['id']);
        unset($_POST['value']);
        $model = new $this->ModelClass;
        $res = $model->postSave($_POST);
        if(!$res['status']['success'])
            $ret = array('statusCode'=>300,'message'=>'Save Failed ：'."[{$res['errorCode']}] {$res['error']}");
        else
            $ret = array('statusCode'=>200,'message'=>'Save Success ','rel'=>$this->rel.'_list');
        echo json_encode($ret);
    }

    public function removeAction($id)
    {
        $model = new $this->ModelClass;
        if($model->remove($id))
            $ret = array('statusCode'=>'200','message'=>'Delete Success','rel'=>$this->rel.'_list');
        else
            $ret = array('statusCode'=>'300','message'=>'Delete Failed ');
        echo json_encode($ret);
    }

    public function querybymachinetypeAction()
    {
        $ctl = new CommonController();
        $volt['list'] = $ctl->getmachinetype(array('onlyParent'=>1));
        $volt['rel'] = $this->rel;
        $this->view->setVar('volt',$volt);
    }

    public function getbymidAction($id,$name)
    {
        $model = new $this->ModelClass;
        $res = $model->execute(array('modelId'=>$id),'getbymid');
        /**
        if(!$res['status']['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'获取失败：'."[{$res['errorCode']}] {$res['error']}")));
            **/
        $volt = $res['result'];
        $volt['act'] = empty($res['data'])? "add":"upd";
        $e = empty($res['data'])? "(Not configured)":"";
        $volt['title'] = "Machine Type <b>{$name}</b> Parameter template{$e}";
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/savebymid/'.$id);
        $volt['reload'] = $this->url->get($this->dispatcher->getControllerName().'/getbymid/'.$id.'/'.$name);
        $volt['rel'] = $this->rel;
        $this->view->setVar('volt',$volt);
        $this->view->pick('paramtemplet/edit');
    }

    public function savebymidAction($id)
    {
        $_POST['paramTemp']['modelId'] = $id;
        $_POST['param'] = array();
        foreach ($_POST['id'] as $id)
        {
            $_POST['param'][] = array('id'=>$id,'defaultValue'=>$_POST['value'][$id]);
        }
        unset($_POST['id']);
        unset($_POST['value']);
        unset($_POST['act']);
        $model = new $this->ModelClass;
        $res = $model->execute($_POST,'savebymid');
        if(!$res['success'])
            $ret = array('statusCode'=>300,'message'=>'Save Failed ：'."[{$res['errorCode']}] {$res['error']}");
        else
            $ret = array('statusCode'=>200,'message'=>'Save Success ','rel'=>$this->rel.'_list');
        echo json_encode($ret);
    }
    
    public function copyAction($id){
        $model = new $this->ModelClass;
        $res = $model->execute(array('param'=>array('id'=>$id)),'copy');
        if(!$res['status']['success'])
            $ret = array('statusCode'=>300,'message'=>'Save Failed ：'."[{$res['errorCode']}] {$res['error']}");
        else
            $ret = array('statusCode'=>200,'message'=>'Save Success ','rel'=>$this->rel.'_left');
        echo json_encode($ret);
    }
}