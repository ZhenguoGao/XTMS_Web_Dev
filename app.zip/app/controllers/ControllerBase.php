<?php

class ControllerBase extends \Phalcon\Mvc\Controller
{
    //protected $volt = array();
    //public $rbac = array();
    public $ModelClass = '';
    public $rel = '';
    public $filter;

    protected function initialize()
    {
        $this->rbac = $this->session->get('rbac');//print_r($this->rbac['user']['idAlias']);die;
        if($this->dispatcher->getControllerName() != 'login' && $this->dispatcher->getControllerName() != 'board'){
            //print_r($this->dispatcher->getControllerName());die;
            if(strpos($_SESSION['rbac']['grants'], $this->dispatcher->getControllerName().',') === false){
                return $this->dispatcher->forward(array(
                    "controller" => "login",
                    "action" => "index",
                ));
            }
        }
        
        $this->rel = $this->dispatcher->getControllerName().'_index';
        $this->filter = new Phalcon\Filter();
        $this->view->setVar('t', $this->trans);
    }

    protected function forward($uri){
        $uriParts = explode('/', $uri);
        return $this->dispatcher->forward(
            array(
                'controller' => $uriParts[0], 
                'action' => $uriParts[1]
            )
        );
    }

    /**
     * 
     * 产生32位唯一序列号
     * @return string
     */
    protected function _guid()
    {
       $charid = strtoupper(md5(uniqid(mt_rand(), true)));
       $guid = substr($charid, 0, 8)
       .substr($charid, 8, 4)
       .substr($charid,12, 4)
       .substr($charid,16, 4)
       .substr($charid,20,12);
       return $guid;
    }

    function mkdirs($dir, $mode = 0777)
    {
        if (!is_dir($dir)) {
            $this->mkdirs(dirname($dir), $mode);
            return mkdir($dir, $mode);
        }
        return true;
    }

    /*protected function _getTranslation()
    {
        //Ask browser what is the best language
        $language = $this->request->getBestLanguage();

        //Check if we have a translation file for that lang
        if (file_exists(__DIR__."/../messages/".$language.".php")) {
           require __DIR__."/../messages/".$language.".php";
        } else {
           // fallback to some default
           require __DIR__."/../messages/cn.php";
        }

        //Return a translation object
        return new \Phalcon\Translate\Adapter\NativeArray(array(
           "content" => $messages
        ));
    }*/


    /**
     * 
     * 初始页
     */	
    public function indexAction()
    {
        $this->searchAction();
        if ($this->request->isPost())
            $this->view->pick($this->dispatcher->getControllerName().'/search');
    }

    /**
     * 
     * 查询页
     */		
    public function searchAction()
    {
        $model = new $this->ModelClass;		
        $volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 20;
        $volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;
        $volt['orderField'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
        $volt['orderDirection'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];

        $res = $model->findByPost(array_merge($_POST,$volt),array());
        $volt['count'] = $res[0];
        $volt['rowset'] = $res[1];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['rel'] = $this->rel;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/index');

        $this->view->setVar('volt',$volt);
    }

    /**
     * 
     * 新增页
     */		
    public function createAction()
    {
        $volt['act'] = 'add';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $this->view->setVar('volt',$volt);
        $this->view->pick($this->dispatcher->getControllerName().'/edit');
    }

    /**
     * 
     * 修改页
     */	
    public function updateAction($pk)
    {
        $model = new $this->ModelClass;
        $volt = $model->findByPk($pk);
        $volt['act'] = 'upd';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $this->view->setVar('volt',$volt);
        $this->view->pick($this->dispatcher->getControllerName().'/edit');
    }

    /**
     * 
     *批量删除
     */
    public function remove2Action()
    {
        $model = new $this->ModelClass;
        if($model->remove($_POST['ids']))
            $ret = array('statusCode'=>'200','message'=>'Delete Success','rel'=>rel);
        else
            $ret = array('statusCode'=>'300','message'=>'Delete Failed ');
        echo json_encode($ret);
    }

    /**
     * 
     *删除单条
     */
    public function removeAction($id)
    {
        $model = new $this->ModelClass;
        if($model->remove($id))
            $ret = array('statusCode'=>'200','message'=>'Delete Success','rel'=>$this->rel);
        else
            $ret = array('statusCode'=>'300','message'=>'Delete Failed ');
        echo json_encode($ret);
    }

    /**
     * 
     *保存记录
     */	
    public function saveAction($closeFlag=true)
    {
        $close = $closeFlag? 'closeCurrent' : '';
        $model = new $this->ModelClass;
        $result = $model->save($_POST);
        $ret = array('statusCode'=>$result['statusCode'],'message'=>$result['message'],'rel'=>$this->rel,'callbackType'=>$close);
        echo json_encode($ret);
    }
    
}