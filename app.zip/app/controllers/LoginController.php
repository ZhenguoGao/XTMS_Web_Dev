<?php

class LoginController extends ControllerBase
{

    public function indexAction()
    {
	$user = $this->session->get('rbac');
    	if (!empty($user)) {
            parent::forward('board/index');
    	}
    	$this->view->setVar('url',$this->url->get('login/valid'));
    }
    
    public function validAction()
    {
        $m = new UserModel();
        $user = $m->findUser($this->request->getPost('usernm'),$this->request->getPost('passwd'));
        if (!$user['result']) {
            // 打印用户密码错误提示信息
            $error['result'] = 0;
            $error['errormsg'] = $user['error']? $user['error'] :'connection failed';
            exit(json_encode($error));
        } else {
            $user = $user['user'];
            $this->session->set('rbac',$user);
            exit(json_encode(array('result'=>1, 'url'=>$this->url->get('Board/index'))));
        }
    }
    
    public function logoutAction()
    {
    	$this->session->remove('rbac');
    	parent::forward('login/index');
    }
}

