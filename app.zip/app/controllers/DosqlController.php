<?php
/** 
 * 执行sql
 *@author zhaimin
 */


class DosqlController extends ControllerBaseSoa {
    public $ModelClass = 'DosqlModel';

    public function indexAction()
    {
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $volt['rel'] = $this->rel;
        $this->view->setVar('volt',$volt);
    }

    public function saveAction()
    {
        $model = new $this->ModelClass;
        $res = $model->execute($_POST,'dosql');
        if(!$res['success'])
            $ret = array('statusCode'=>300,'message'=>'Failed','back'=>$res['result']);
        else
            $ret = array('statusCode'=>200,'message'=>'Success','back'=>$res['result']);
        echo json_encode($ret);
    }
}