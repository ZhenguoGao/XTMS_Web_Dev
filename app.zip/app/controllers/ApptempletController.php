<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class apptempletController extends ControllerBaseSoa2
{
    public $ModelClass = 'ApptempletSoa';

    public function  createAction()
    {
        $volt['app'] = array(array(),array('hidden'=>'1'),array('hidden'=>'1'),array('hidden'=>'1'),array('hidden'=>'1'));
        $volt['act'] = "add";
        $volt['title'] = "<i class='fa fa-plus'></i> Add";
        $volt['rel'] = $this->dispatcher->getControllerName().'_index';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $this->view->setVar('volt',$volt);
        $this->view->pick('apptemplet/edit');
    }

    public function updateAction($pk)
    {
        $model = new $this->ModelClass;
        $volt = $model->findByPk($pk);
        $volt = $volt['data'];
        $volt['app'] = $volt['appParamTemp'];
        while(count($volt['app'])<5){
            $volt['app'][] = array('hidden'=>'1');
        }
        $volt['act'] = "upd";
        $volt['title'] = "<i class='fa fa-edit'></i> Edit";
        $volt['rel'] = $this->dispatcher->getControllerName().'_index';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $volt['reload'] = $this->url->get($this->dispatcher->getControllerName().'/update/'.$pk);
        $this->view->setVar('volt',$volt);
        $this->view->pick('apptemplet/edit');
    }

    public function saveAction()
    {
        $_POST['appTemp']['name'] = $_POST['name'];
        $_POST['appTemp']['number'] = $_POST['number'];
        $_POST['appTemp']['description'] = $_POST['description'];
        if($_POST['act']=='add')
        {
            $_POST['appTemp']['creator'] = $_SESSION['rbac']['userid'];
        }
        else
        {
            $_POST['appTemp']['id'] = $_POST['id'];
            $_POST['appTemp']['moidier'] = $_SESSION['rbac']['userid'];
        }
        $_POST['appParamTemp'] = array();
        foreach ($_POST['items_app_id'] as $key=>$id)
        {
            if($_POST['hidden'][$key]=='0')
                $_POST['appParamTemp'][] = array('appId'=>$id,'paramTempId'=>$_POST['items_param_id'][$key],'appUpdateMode'=>$_POST['appUpdateMode'][$key],'paramTempUpdateMode'=>$_POST['paramTempUpdateMode'][$key]);
        }
        parent::saveAction(false);
    }
    
    //new add by lujun 2016-12-28
    public function searchAction()
    {
        $model = new $this->ModelClass;
        $volt['page']['pageNum'] = 1;
        $volt['page']['pageSize'] = 1000;
        //$volt['order']['field'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
        $volt['order']['field'] = 'id';
        //$volt['order']['direction'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];
        $volt['order']['direction'] ='desc';
        $volt['param']['keywords'] = $this->request->getPost('keywords');
        //$res = $model->findByPost(array_merge($_POST,$volt));
        $res = $model->execute(array_merge($_POST,$volt),'index');
        if(!$res['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'Search Failed ：'."[{$res['errorCode']}] {$res['error']}")));
        $volt['count'] = $res['page']['total'];
        $volt['list'] = $res['result'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['rel'] = $this->rel;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/index');
    
        $this->view->setVar('volt',$volt);
    }
}