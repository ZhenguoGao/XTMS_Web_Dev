<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class ControllerBaseSoa extends ControllerBase{

    public function indexAction()
    {
        $this->searchAction();
        if ($this->request->isPost())
            $this->view->pick($this->dispatcher->getControllerName().'/search');
    }

    public function searchAction()
    {
        $model = new $this->ModelClass;
        $volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 20;
        $volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;
        $volt['orderField'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
        $volt['orderDirection'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];
        //print_r($volt);die;
        $res = $model->findByPost(array_merge($_POST,$volt));
        if(!$res['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'Search Failed ：'."[{$res['errorCode']}] {$res['error']}")));
        $volt['count'] = $res['totalRows'];
        $volt['rowset'] = $res['data'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['rel'] = $this->rel;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/index');
        $this->view->setVar('volt',$volt);
    }

    public function createAction()
    {
        $volt['act'] = 'add';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $this->view->setVar('volt',$volt);
    }

    public function updateAction($pk)
    {
        $model = new $this->ModelClass;
        $volt = $model->findByPk($pk);
        if(!$volt['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'Search Failed ：'."[{$volt['errorCode']}] {$volt['error']}")));
        $volt = $volt['data'];
        $volt['act'] = 'upd';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $this->view->setVar('volt',$volt);
    }

    public function saveAction($closeFlag=true)
    {
        $close = $closeFlag? 'closeCurrent' : '';
        $model = new $this->ModelClass;
        $res = $model->postSave($_POST);
        if(!$res['success'])
            $ret = array('statusCode'=>300,'message'=>'Save Failed ：'."[{$res['errorCode']}] {$res['error']}");
        else
            $ret = array('statusCode'=>200,'message'=>'Save Success ','rel'=>$this->rel,'callbackType'=>$close);
        echo json_encode($ret);
    }

    public function removeAction($pk,$closeFlag=false)
    {
        $close = $closeFlag? 'closeCurrent' : '';
        $model = new $this->ModelClass;
        $res = $model->remove($pk);
        if(!$res['success'])
            $ret = array('statusCode'=>300,'message'=>'Delete Failed ：'."[{$res['errorCode']}] {$res['error']}");
        else
            $ret = array('statusCode'=>200,'message'=>'Delete Success','rel'=>$this->rel,'callbackType'=>$close);
        echo json_encode($ret);
    }

}