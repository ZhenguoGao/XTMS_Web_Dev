<?php

/**
* 终端信息触发查询
*/
class TerminaltriggerController extends ControllerBaseSoa2
{
    public $ModelClass = 'TerminalTriggerSoa';

    public function indexAction()
    {
        /*
        * 0000800E	开外壳
        * 00000010	RTC电池掉
        * 0000800F	CPU触发
        * 00000011	RTC掉电
        */
        $this->view->setVar('happenReasons',$happenReasons = array('all'=>'Please select', '0000800E'=>'Open shell', '00000010'=>'RTC Battery out', '0000800F'=>'CPU trigger', '00000011'=>'RTC power off'));
        (!in_array($happenReason = strtolower($this->request->get('lastHappenReason')), array_map('strtolower', $codes = array_keys($happenReasons))) || $happenReason === $codes[0]) && $_POST['lastHappenReason'] = '';
        parent::indexAction();
    }

}