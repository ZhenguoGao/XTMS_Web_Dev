<?php

/** 
 * @author lujun
 * 
 * 
 */
class GroupController extends ControllerBaseSoa
{
    public $ModelClass = 'GroupSoa';
	
    public function indexAction()
    {
        $this->getlistAction();
    }

    public function getlistAction()
    {
        $model = new $this->ModelClass;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/getlist');
        $volt['rel'] = $this->rel;
        $url = $this->url->get($this->dispatcher->getControllerName().'/get/all/0/'.urlencode('All groups'));
        $volt['typelist'] = array(array('id'=>'0','pId'=>'0','name'=>'All groups','url'=>$url,'open'=>true,'target'=>'ajax'));
        $lists = $model->execute(array('includeParent'=>'1'),'index');
        foreach ($lists['data'] as $list)
        {
            $url = $this->url->get($this->dispatcher->getControllerName().'/get/'.$list['parentid'].'/'.$list['id'].'/'.urlencode($list['name']));
            $volt['typelist'][] = array('id'=>$list['id'],'pId'=>$list['parentid'],'name'=>$list['name'].'(id:'.$list['id'].')','url'=>$url,'open'=>true,'target'=>'ajax');
        }
        $volt['typelist'] = json_encode($volt['typelist']);
        $this->view->setVar('volt',$volt);
    }

    public function getAction($parentId,$id,$name)
    {
        $model = new $this->ModelClass;
        $volt = $model->findByPk($id);
        //$volt = $volt['data'];
        $volt = $volt['result'];
        $volt['islast'] = $model->execute($id,'last');
        $volt['parentid'] = $parentId=='all'? '0':$parentId;
        $volt['base'] = $parentId=='all'? 'all':'';
        $volt['id'] = $id;
        $volt['save'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $volt['delete'] = $this->url->get($this->dispatcher->getControllerName().'/remove/'.$id);
        $volt['rel'] = $this->rel;
        $volt['swf'] = $this->url->get('public/uploadify/uploadify.swf');
        $volt['upload'] = $this->url->get($this->dispatcher->getControllerName().'/upload');
        $volt['img'] = $this->url->get('public/img/machinetype/'.$volt['name'].'.jpg');
        $volt['imgpath'] = '../public/img/machinetype/'.$volt['name'].'.jpg';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $this->view->setVar('volt',$volt);
    }

    public function uploadAction()
    {
        $model = new $this->ModelClass;
        if (!empty($_FILES))
        {
            $volt['tempPath'] = '../public/img/machinetype/tmp/';
            if (!is_dir($volt['tempPath']))
            {
                $this->mkdirs($volt['tempPath']);
                chmod($volt['tempPath'], 0777);//改变文件权限
            }

            $gid = $this->_guid();
            $tempfile = $_FILES['Filedata']['tmp_name'];
            $dirfile = $volt['tempPath'].$gid.'.jpg';
            $img = $this->url->get('public/img/machinetype/tmp/'.$gid.'.jpg');

            if(move_uploaded_file($tempfile,$dirfile))
            {
                $res = array('img'=>$img,'path'=>$dirfile);
                echo json_encode($res);
            }
            else
                echo json_encode(array('error'=>'error'));
        }
        else
            echo json_encode(array('error'=>'error'));
    }

    public function saveAction()
    {
        if(isset($_POST['parentId'])) {
            $model = new $this->ModelClass;
            $res = $model->execute(array('param'=>$_POST),'add');
            if(!$res['status']['success'])
                $ret = array('statusCode'=>300,'message'=>'Save Failed ：'."[{$res['errorCode']}] {$res['error']}");
            else
            {
                unlink($_POST['tempfile']);
                $ret = array('statusCode'=>200,'message'=>'Save Success ','rel'=>$this->rel.'_left');
            }
            echo json_encode($ret);
        } else {
            //print_r($_POST);die;
            $model = new $this->ModelClass;
            $res = $model->execute(array('param'=>$_POST),'update');
            if(!$res['status']['success']) {
                $ret = array('statusCode'=>300,'message'=>'Update Failed ：'."[{$res['errorCode']}] {$res['error']}");
            } else {
                $ret = array('statusCode'=>200,'message'=>'Update Success','rel'=>$this->rel.'_left');
            }
            echo json_encode($ret);
        }
    }
    
    public function removeAction($id)
    {
        $model = new $this->ModelClass;
        //$res = $model->execute(array('ids'=>$id),'delete');
        $res = $model->execute(array('param'=>array('id'=>$id)),'delete');
        if(!$res['status']['success'])
            $ret = array('statusCode'=>300,'message'=>'Delete Failed ：'."[{$res['errorCode']}] {$res['error']}");
        else
            $ret = array('statusCode'=>200,'message'=>'Delete Success','rel'=>$this->rel.'_left');
        echo json_encode($ret);
    }
}