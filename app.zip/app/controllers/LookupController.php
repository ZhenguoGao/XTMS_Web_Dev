<?php

class LookupController extends ControllerBase
{
    /*public function IndexAction($modelClass)
    {
        $model = new $modelClass;
        $volt['numPerPage'] = $this->request->getPost('numPerPage','int',10);
        $volt['pageNum'] = $this->request->getPost('pageNum','int',1);
        $volt['orderField'] = $this->request->getPost('orderField',null,$model->order['field']);
        $volt['orderDirection'] = $this->request->getPost('orderDirection',null,$model->order['direction']);
        $volt['keywords'] = $this->request->getPost('keywords');

        $res = $model->findByPost($volt,array());
        $volt['count'] = $res[0];
        $volt['rowset'] = $res[1];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['field'] = $model->getLookupField();
        $volt['key'] = $model->getPK();
        $volt['action'] = $this->url->get("lookup/index/{$modelClass}");

        $this->view->setVar('volt',$volt);
    }*/

    public function indexAction($modelClass,$param)
    {
        $param1 = explode('|', $param);
        foreach ($param1 as $p)
        {
            $t = explode('=', $p);
            $volt[$t[0]] = $t[1];
        }
        $model = new $modelClass;
        $volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 20;
        $volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;
        $volt['orderField'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
        $volt['orderDirection'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];
        
        $res = $model->findByPost(array_merge($_POST,$volt));
        if(!$res['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'Search Failed ：'."[{$res['errorCode']}] {$res['error']}")));
        $volt['count'] = $res['totalRows'];
        $volt['rowset'] = $res['data'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['field'] = $model->getLookupField();
        $volt['replace'] = $model->getReplaceValue();
        $volt['key'] = $model->getPK();
        $volt['action'] = $this->url->get("lookup/index/{$modelClass}/{$param}");
        $this->view->setVar('volt',$volt);
        $this->view->pick('lookup/index');
    }
    
    public function index1Action($modelClass,$param)
    {
        $param1 = explode('|', $param);
        foreach ($param1 as $p)
        {
            $t = explode('=', $p);
            $volt[$t[0]] = $t[1];
        }
        $model = new $modelClass;
        $volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 10;
        $volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;
        $volt['orderField'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
        $volt['orderDirection'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];
        if ($modelClass == 'PackbaseSoa') {
            $_POST['resource'] = 'updplan';
        }
        if ($modelClass == 'DeviceSoa'){
        	$res = $model->findByPost3(array_merge($_POST,$volt));
        }else{
        	$res = $model->findByPost(array_merge($_POST,$volt));
        }
        $volt['count'] = $res['page']['total'];
        $volt['rowset'] = $res['result'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['field'] = $model->getLookupField();        
        if ($modelClass == 'ApkfileSoa' ||  $modelClass == 'SposSoa') {
            foreach ($volt['rowset'] as $val) {
                $array[] = $this->array_remove($val, 'desc');
            }
            $volt['rowset'] = $array;
        }
        $volt['replace'] = $model->getReplaceValue();
        $volt['key'] = $model->getPK();
        $volt['action'] = $this->url->get("lookup/index1/{$modelClass}/{$param}");
        $this->view->setVar('volt',$volt);
        $this->view->pick('lookup/index1');
    }
    
    public function groupAction($param)
    {
        if($param == '')
            $param = $_SESSION['rbac']['idAlias'];
        $model = new GroupSoa;
        $url = $this->url->get($this->dispatcher->getControllerName().'/get/all/0/'.urlencode('All groups'));
        $volt['typelist'] = array(array('id'=>'0','pId'=>'0','name'=>'All groups','url'=>$url,'open'=>true,'target'=>'ajax'));
        $lists = $model->execute(array('useridalias'=>$param),'getGroupByUser');
        foreach ($lists['data'] as $list) {
            //$bring = "{'groupid':'".$list['id']."','name':'".$list['name']."'}";
            $bring = "{groupid:".$list['id'].",name:".$list['name']."}";
            $url = $this->url->get($this->dispatcher->getControllerName().'/get/'.$list['parentid'].'/'.$list['id'].'/'.urlencode($list['name']));
            $url = 'JavaScript:$.bringBack('.$bring.');';
            $volt['typelist'][] = array('id'=>$list['id'],'pId'=>$list['parentid'],'name'=>$list['name'].'(id:'.$list['id'].')','url'=>$url, 'open'=>true,'target'=>'ajax');
            //$volt['typelist'][] = array('id'=>$list['id'],'pId'=>$list['parentid'],'name'=>$list['name'].'(id:'.$list['id'].')','open'=>true,'ondblclick'=>'$.bringBack('.$bring.')');
        }
        $volt['typelist'] = json_encode($volt['typelist']);
        $this->view->setVar('volt',$volt);
    }

    public function userAction($param)
    {
        if($param == '')
            $param = $_SESSION['rbac']['idAlias'];
        $model = new UserNew();
        $url = $this->url->get($this->dispatcher->getControllerName().'/get/all/0/'.urlencode('All users'));
        $volt['typelist'] = array(array('id'=>'0','name'=>'All users','url'=>$url,'open'=>true,'target'=>'ajax'));
        $lists = $model->getUser();
        foreach ($lists['data'] as $list)
        {
            $bring = "{groupid:".$list['id'].",name:".$list['name']."}";
            $url = $this->url->get($this->dispatcher->getControllerName().'/get/'.$list['parentid'].'/'.$list['id'].'/'.urlencode($list['name']));
            $url = 'JavaScript:$.bringBack('.$bring.');';
            $volt['typelist'][] = array('id'=>$list['id'],'pId'=>$list['parentid'],'name'=>$list['name'].'(id:'.$list['id'].')','url'=>$url, 'open'=>true,'target'=>'ajax');
        }
        $volt['typelist'] = json_encode($volt['typelist']);
        $this->view->setVar('volt',$volt);
    }
    
    private function array_remove($arr, $key) {
        if(!array_key_exists($key, $arr))
            return $arr;
        $keys = array_keys($arr);
        $index = array_search($key, $keys);
        if($index !== FALSE)
            array_splice($arr, $index, 1);
        return $arr;    
    }
    	
}

