<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class logupdateController extends ControllerBaseSoa2
{
    public $ModelClass = 'LogupdateSoa';

    public function searchAction()
    {
        $_POST['communicateWay'] = isset($_POST['communicateWay'])? $_POST['communicateWay']:'99';
        Phalcon\Tag::setDefault('communicateWay', $_POST['communicateWay']);
        if($_POST['communicateWay']=='99')
            unset($_POST['communicateWay']);

        $_POST['planEntryStatus'] = isset($_POST['planEntryStatus'])? $_POST['planEntryStatus']:'99';
        Phalcon\Tag::setDefault('planEntryStatus', $_POST['planEntryStatus']);
        if($_POST['planEntryStatus']=='99')
            unset($_POST['planEntryStatus']);

        parent::searchAction();
        $this->view->setVar('getAction',$this->url->get($this->dispatcher->getControllerName()."/get"));
        //$c = new UpdplanController();
        $this->view->setVar('planEntryStatus',array('99'=>'All status','0'=>'Uncompleted','2'=>'Completed'));
    }

    public function getAction($id)
    {
        $m = new $this->ModelClass;
        //$res = $m->execute(array('upgradeId'=>$id),'get');
        $res = $m->execute(array('param' => array('id'=>$id)),'get');
        $this->view->setVar('volt',$res['data']);
    }
}