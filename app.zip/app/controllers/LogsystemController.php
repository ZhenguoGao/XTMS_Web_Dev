<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class logsystemController extends ControllerBaseSoa {
    public $ModelClass = 'LogsystemSoa';

    public function searchAction()
    {
        $_POST['transactionType'] = isset($_POST['transactionType'])? $_POST['transactionType']:'99';
        $_POST['communicateWay'] = isset($_POST['communicateWay'])? $_POST['communicateWay']:'99';
        Phalcon\Tag::setDefault('transactionType', $_POST['transactionType']);
        Phalcon\Tag::setDefault('communicateWay', $_POST['communicateWay']);
        if($_POST['transactionType']=='99')
                unset($_POST['transactionType']);
        if($_POST['communicateWay']=='99')
                unset($_POST['communicateWay']);
        parent::searchAction();
    }
}