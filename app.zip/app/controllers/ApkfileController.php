<?php

/** 
 * @author lujun
 * 
 * 
 */
class ApkfileController extends ControllerBaseSoa2 {
    public $ModelClass = 'ApkfileSoa';

    public function createAction() {
        //$ctl = new CommonController();
        //$res = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid,'parentId'=>0,'modeltype'=>1));
        $ctl = new SposNew();
        $res = $ctl->getmodel($_SESSION['rbac']['idAlias']);
        $res = $res['data'];
        $volt['modelNames'] = array(''=>'Select machine type');
        foreach ($res as $re)
        {
            $volt['modelNames'][$re['id']] = $re['name'];
        }
        
        $model = new PublicSoa();
        $ret1 = $model->execute(array(),'getUser');
        $this->view->setVar('userlist',$ret1['data']);
        $this->view->setVar('getModelAction',$this->url->get($this->dispatcher->getControllerName().'/getmodel'));
        
        $volt['realPath'] = '../program/';
        $volt['absPath'] = 'program/tmp/';
        $volt['tempPath'] = '../program/tmp/';
        if (!is_dir($volt['tempPath']))
        {
            $this->mkdirs($volt['tempPath']);
            chmod($volt['tempPath'], 0777);//改变文件权限
        }
        $gid = $this->_guid();
        $volt['tempPath'] .= $gid;
        $volt['absPath'] .= $gid;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $volt['packageType'] = $tp;
        
        $session = $this->session->get('rbac');
        $volt['session'] = $session;
        $volt['session']['tempPath'] = str_replace('\\','/',$volt['tempPath']);
        $volt['session']['absPath'] = str_replace('\\','/',$volt['absPath']);
        $volt['session']['session_keys'] = implode(',',array_keys($session));
        $volt['session'][session_name()] = session_id();
        $volt['session'] = json_encode($volt['session']);
        if(PHP_SAPI == 'fpm-fcgi'){
            $volt['button'] = $this->url->get('uploadify/open.png');
            $volt['swf'] = $this->url->get('uploadify/uploadify.swf');
        } else {
            $volt['button'] = $this->url->get('public/uploadify/open.png');
            $volt['swf'] = $this->url->get('public/uploadify/uploadify.swf');
        }
        $volt['upload'] = $this->url->get($this->dispatcher->getControllerName().'/upload');
        $volt['upload1'] = $this->url->get($this->dispatcher->getControllerName().'/upload1');
        $volt['getinf'] = $this->url->get($this->dispatcher->getControllerName().'/getinf');
        $this->view->setVar('volt',$volt);
        $this->view->setVar('rel',$this->rel);
    }
    
    public function uploadAction()
    {
        $model = new $this->ModelClass;
        if (!empty($_FILES)) {
            $tempfile = $_FILES['Filedata']['tmp_name'];
            $filename = $_FILES["Filedata"]["name"];
            $extend = pathinfo($_FILES["Filedata"]["name"]);
            if(move_uploaded_file($tempfile,$_REQUEST['tempPath'].$_REQUEST['tp'].'.'.$extend[extension])) {
                //读取apk文件
                $uploadfile = '../'.$_REQUEST['absPath'].$_REQUEST['tp'].'.'.$extend[extension];
                $appObj  = new Apkparser();
                $res = $appObj->open($uploadfile);
                $name = $appObj->getAppName();         // 应用名称
                if ($name == '') {
                    $name = substr($filename, 0, -4);
                }
                $package = $appObj->getPackage();        // 应用包名
                $versionname = $appObj->getVersionName();    // 版本名称
                $versioncode = $appObj->getVersionCode();    // 版本代码
                //$icon = $appObj->getIcon();    // icon
				$nickname = explode('.',$package)[count(explode('.',$package))-1];
                $res = array('filename'=>$filename,'filesize'=>$_FILES["Filedata"]["size"],
                    'uploadfile'=>$_REQUEST['absPath'].$_REQUEST['tp'].'.'.$extend[extension],'name' => $name,'package' => $package,
                    'versionname' => $versionname,'versioncode' => $versioncode,'md5'=>md5_file($uploadfile),'nickname' =>$nickname);
                echo json_encode($res);
            } else{
                echo json_encode(array('error'=>'error'));
            }
        } else{
            echo json_encode(array('error'=>'error'));
        }
    }
    
    public function upload1Action()
    {
        $model = new $this->ModelClass;
        if (!empty($_FILES))
        {
            $tempfile1 = $_FILES['Filedata']['tmp_name'];
            $filename1 = $_FILES["Filedata"]["name"];
            $extend1 = pathinfo($_FILES["Filedata"]["name"]);
            $rename = rand(100,999);
            if(move_uploaded_file($tempfile1,$_REQUEST['tempPath'].$rename.'.'.$extend1[extension]))
            {
                $res = array('filenamelogo'=>$filename1,'filesizelogo'=>$_FILES["Filedata"]["size"],
                    'uploadfilelogo'=>$_REQUEST['absPath'].$rename.'.'.$extend1[extension]);
                echo json_encode($res);
            }
            else{
                echo json_encode(array('error'=>'error'));
            }
        }
        else{
            echo json_encode(array('error'=>'error'));
        }
    }
    
    public function saveAction()
    {
        $_POST['modelid'] = $_POST['model_id'];
        if(empty($_POST['uploadfile'])){
            exit(json_encode(array('statusCode'=>300,'message'=>'Please upload the file package to save!')));
        }
        //print_r($_POST);die;
        //parent::saveAction();
        $model = new $this->ModelClass;
        $res = $model->postSave($_POST);
        if(!$res['success'])
            $ret = array('statusCode'=>300,'message'=>'Save Failed ：'."[{$res['errorCode']}] {$res['error']}");
        else{
            $ret = array('statusCode'=>200,'message'=>'Save Success ','rel'=>$this->rel,'callbackType'=>'closeCurrent');
            unlink('../'.$_POST['uploadfile']);
            if ($_POST['filelogo'] != '')
                unlink('../'.$_POST['uploadfilelogo']);
        }
        echo json_encode($ret);
    }
    
    public function removeAction($pk,$closeFlag=false)
    {
        $close = $closeFlag? 'closeCurrent' : '';
        $model = new $this->ModelClass;
        $res = $model->remove($pk);
        if(!$res['success'])
            $ret = array('statusCode'=>300,'message'=>'Delete Failed , the upgrade plan associated with the application package is not over');
        else
            $ret = array('statusCode'=>200,'message'=>'Delete Success','rel'=>$this->rel,'callbackType'=>$close);
        echo json_encode($ret);
    }
    
    public function editAction($pk)
    {
        $model = new PublicSoa();
        $ret1 = $model->execute(array(),'getUser');
        $this->view->setVar('userlist',$ret1['data']);
        $this->view->setVar('getModelAction',$this->url->get($this->dispatcher->getControllerName().'/getmodel'));
        
        $model = new $this->ModelClass;
        $volt = $model->findByPk($pk);
        if(!$volt['status']['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'Search Failed '."[{$volt['status']['errorCode']}] {$volt['status']['message']}")));
        $volt = $volt['result'];
        $volt['act'] = 'upd';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save1');
        //$ctl = new CommonController();
        //$res = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid,'parentId'=>0,'modeltype'=>1));
        $ctl = new SposNew();
        $res = $ctl->getmodel($_SESSION['rbac']['idAlias']);
        $res = $res['data'];
        $volt['modelNames'] = array(''=>'Select machine type');
        foreach ($res as $re)
        {
            $volt['modelNames'][$re['id']] = $re['name'];
        }
        Phalcon\Tag::setDefault("model_id", $volt['modelid']);
        $this->view->setVar('volt',$volt);
        $this->view->pick('apkfile/edit');
    }
    
    public function save1Action(){
        if($_POST['model_id'] == '')
            die(json_encode(array('statusCode'=>300,'message'=>'Select machine type')));
        $model = new ApkfileNew;
        $res = $model->edit($_POST);
        if(!$res['success'])
            $ret = array('statusCode'=>300,'message'=>'Update Failed ：'."[{$res['errorCode']}] {$res['error']}");
        else
            $ret = array('statusCode'=>200,'message'=>'Update Success','rel'=>$this->rel,'callbackType'=>'closeCurrent');
        echo json_encode($ret);
    }
    
    public function getmodelAction(){
        $model = new SposNew();
        $res = $model->getmodel($_POST['useridalias']);
        $str = '<option selected="selected" value="">Select machine type</option>';
        foreach ($res['data'] as $re) {
            $str .= '<option value="'.$re['id'].'">'.$re['name'].'</option>';
        }
        echo $str;
    }
}