<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class MachineController extends ControllerBaseSoa {
    public $ModelClass = 'MachineSoa';

    public function indexAction()
    {
        $ctl = new CommonController();
        $this->view->setVar('supplier',$ctl->getsupplier());
        $this->view->setVar('typeListUrl',$this->url->get($this->dispatcher->getControllerName()."/typelist/"));
        $model = new $this->ModelClass;
        $con = $model->getConfig();
        $this->view->setVar('default_supplierid',$con->default_supplierid);
        $this->typelistAction($con->default_supplierid);
        $this->searchAction($con->default_supplierid,'','','');
    }

    public function typelistAction($supplierId)
    {
        $ctl = new CommonController();
        $res = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$supplierId));
        $type = array( array('id'=>'0', 'pid'=>'0', 'name'=>'All machine type', 'url'=>$this->url->get($this->dispatcher->getControllerName().'/search/'.$supplierId.'/'), 'open'=>true, 'target'=>'ajax') );
        foreach($res as $re)
        {
            $type[] = array('id'=>$re['id'],'pId'=>$re['parentId'],'name'=>$re['name'],'url'=>$this->url->get($this->dispatcher->getControllerName().'/search/'.$supplierId.'/'.$re['id'].'/'.$re['parentId'].'/'.urlencode($re['name'])),'open'=>true,'target'=>'ajax');
        }
        $this->view->setVar('type',json_encode($type));
        $this->view->setVar('rel',$this->rel);
    }

    public function searchAction($supplierId,$modelId,$parentId,$modelName)
    {
        $_POST['status'] = isset($_POST['status'])? $_POST['status']:'99';
        Phalcon\Tag::setDefault('status', $_POST['status']);
        if($_POST['status']=='99')
            unset($_POST['status']);
        $model = new $this->ModelClass;
        $volt['supplierId'] = $supplierId;
        $volt['modelId'] = $modelId;
        $volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 20;
        $volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;
        $volt['orderField'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
        $volt['orderDirection'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];

        $res = $model->findByPost(array_merge($_POST,$volt));
        if(!$res['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'Select failed：'."[{$res['errorCode']}] {$res['error']}")));
        $volt['count'] = $res['totalRows'];
        $volt['rowset'] = $res['data'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['rel'] = $this->rel;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName()."/search/{$supplierId}/{$modelId}/{$parentId}/{$modelName}");
        $volt['createAction'] = $this->url->get($this->dispatcher->getControllerName().'/create/'.$modelId.'/'.$modelName);
        $volt['parentId'] = $parentId;

        $this->view->setVar('volt',$volt);
    }

    public function createAction($modelId,$modelName)
    {
        $volt2['modelName'] = urldecode($modelName);
        $volt2['modelId'] = $modelId;
        $this->view->setVar('volt2',$volt2);
        parent::createAction();
    }
}