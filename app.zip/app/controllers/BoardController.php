<?php

/**
 * BoardController
 * 
 * @author zhaimin
 * @version 1.0
 */
class BoardController extends ControllerBase 
{
    /**
     * The default action - show the home page
     */
    public function indexAction() 
    {
        $user = $this->session->get('rbac');
        
        if(!isset($_SESSION['rbac']) || empty($user)){
            parent::forward('login/index');
        } else {
            $m = new UserModel();
            //print_r($this->session->get('rbac'));die;
            $menus = $m->makeMenu($this->session->get('rbac'));
            $this->view->setVar('logout', $this->url->get('login/logout'));
            $this->view->setVar('chgpwd', $this->url->get('chgpwd/index'));
            $this->view->setVar('menus', $menus);
            $this->view->setVar('reloginAction', $this->url->get("login/valid"));
            $this->view->setVar('sess', $this->session->get('rbac'));
        }
    }
}