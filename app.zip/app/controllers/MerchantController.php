<?php

/** 
 * @author lujun
 * 
 * 
 */
class MerchantController extends ControllerBaseSoa2 {
    public $ModelClass = 'MerchantSoa';
    
    public function createAction()
    {
        parent::createAction();
        $this->view->pick('merchant/edit');
    }
    
    public function editAction($pk)
    {
        parent::updateAction($pk);
        $this->view->pick('merchant/edit');
    }
}