<?php
/** 
 * 修改密码
 *@author zhaimin
 */


class ChgpwdController extends ControllerBaseSoa2 {
    public $ModelClass = 'UserModel';
	
    public function indexAction()
    {
    	$volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/savepwd');
    	$this->view->setVar('volt',$volt);
    }
    
    public function savepwdAction()
    {
        $user = $this->session->get('rbac');
        if($user['password']!=md5($this->request->getPost('oldpassword')))
        {
            echo json_encode(array('statusCode'=>300,'message'=>'Original password error!'));
            exit;
        }
        $model = new $this->ModelClass;
        $res = $model->execute(array('param'=>array('id'=>$user['id'],'password'=>md5($this->request->getPost('newpwd')))),'update');
        if(!$res['status']['success'])
            $ret = array('statusCode'=>300,'message'=>"Update Failed ：[{$res['status']['errorCode']}] {$res['status']['message']}");
        else
            $ret = array('statusCode'=>200,'message'=>'Update Success','callbackType'=>'closeCurrent');
        echo json_encode($ret);
    }
}