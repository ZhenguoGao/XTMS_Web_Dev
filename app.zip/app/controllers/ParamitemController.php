<?php

/** 
 * @author zhaimin
 * 
 * 
 */
//class paramitemController extends ControllerBaseSoa {
class paramitemController extends ControllerBaseSoa2
{
    public $ModelClass = 'ParamitemSoa';

    public function createAction()
    {
        parent::createAction();
        $this->view->pick("paramitem/edit");
    }

    public function updateAction($pk)
    {
        parent::updateAction($pk);
        $this->view->pick("paramitem/edit");
    }

    public function saveAction()
    {
        if(intval($_POST['max']) < intval($_POST['min'])) {
            echo json_encode(array('statusCode'=>300,'message'=>'The maximum length cannot be less than the minimum length'));
        } else {
            if($_POST['type']=='2') {
                $_POST['min']='0';
                $_POST['max']='1';
            }
            parent::saveAction();
        }
    }
}