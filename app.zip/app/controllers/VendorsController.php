<?php

/** 
 * @author lujun
 * 
 * 
 */
class VendorsController extends ControllerBaseSoa2 {
    public $ModelClass = 'VendorsSoa';
    
    public function createAction()
    {
        parent::createAction();
        $this->view->pick('vendors/edit');
    }
    
    public function editAction($pk)
    {
        parent::updateAction($pk);
        $this->view->pick('vendors/edit');
    }
}