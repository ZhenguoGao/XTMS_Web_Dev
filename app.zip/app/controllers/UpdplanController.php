<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class UpdplanController extends ControllerBaseSoa2
{
    public $ModelClass = 'UpdplanSoa';
    public $dir = 'filecache/updplandetail/';
    public $status = array('99' => 'All', '0' => 'Not start', '1' => 'Upgrading', '2' => 'Complete', '3' => 'Time out', '4' => 'Upgrade success', '5' => 'Upgrade Failed', '6' => 'Canceled');

    public function indexAction($type = 'tpos')
    {
        $type = isset($type) ? $type : 'tpos';
        $_POST['status'] = isset($_POST['status'])? $_POST['status']:'99';
        Phalcon\Tag::setDefault('status', $_POST['status']);
        if($_POST['status']=='99') {
            unset($_POST['status']);
        }
        $model = new $this->ModelClass;
        $volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 20;
        $volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;
        $volt['orderField'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
        $volt['orderDirection'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];
        $volt['type'] = $type;
        $res = $model->findByPost(array_merge($_POST,$volt));
        $volt['count'] = $res['page']['total'];
        $volt['list'] = $res['result'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['rel'] = $this->rel;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName()."/search/$type");//print_r($volt);die;

        $this->view->setVar('volt',$volt);
    }

//     public function searchAction($type = 'tpos')
//     {
//         $_POST['status'] = isset($_POST['status'])? $_POST['status']:'99';
//         Phalcon\Tag::setDefault('status', $_POST['status']);
//         if($_POST['status']=='99')
//             unset($_POST['status']);      
//         parent::searchAction();
//     }

	public function searchAction($type)
	{
		$type = isset($type) ? $type : 'tpos';
		$_POST['status'] = isset($_POST['status'])? $_POST['status']:'99';
		Phalcon\Tag::setDefault('status', $_POST['status']);
		if($_POST['status']=='99') {
			unset($_POST['status']);
		}
		$model = new $this->ModelClass;
		$volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 20;
		$volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;
		$volt['orderField'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
		$volt['orderDirection'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];
		$volt['type'] = $type;
		
		$res = $model->findByPost(array_merge($_POST,$volt));
		$volt['count'] = $res['page']['total'];
		$volt['list'] = $res['result'];
		$volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
		$volt['rel'] = $this->rel;
		$volt['action'] = $this->url->get($this->dispatcher->getControllerName()."/search/$type");//print_r($volt);die;
		//print_r($volt);die;
		$this->view->setVar('volt',$volt);
	}

    public function detailAction($id,$planname)
    {
        $model = new $this->ModelClass;		
        $volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 20;
        $volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;
        $volt['planID'] = $id;
        $volt['planname'] = urldecode($planname);

        $res = $model->detail(array_merge($_POST,$volt));
        if(!$res['success'])
                die(json_encode(array('statusCode'=>300,'message'=>'Search Failed ：'."[{$res['errorCode']}] {$res['error']}")));
        $res2 = $model->execute(array('planID'=>$id),'statistics');
        $volt['statistics'] = $res2['data'];
        /**
        $volt['count'] = $res['totalRows'];
        $volt['rowset'] = $res['data'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        **/
        $volt['count'] = $res['page']['total'];
        $volt['rowset'] = $res['result'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        
        $volt['rel'] = $this->rel.'_detail';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/detail/'.$id.'/'.$planname);
        
        $this->view->setVar('volt',$volt);
        $this->view->setVar('status',$this->status);
    }
    
    public function createAction()
    {
        $model = new $this->ModelClass;
        $con = $model->getConfig();
        $ctl = new CommonController();
        $volt['machtype'] = $ctl->getmachinetype(array('includeParent'=>0,'supplierId'=>$con->default_supplierid,'parentId'=>0,'modeltype'=>0));

        $model = new ApptempletSoa();
        //$ret = $model->findByPost(array('pageNum'=>1,'numPerPage'=>9999));

        $ret = $model->execute(array('page' => array('pageNum'=>1,'pageSize'=>9999),
            'order'=> array('field'=>'name','direction'=>'desc')),'index');
        $volt['appTemp'] = $ret['result'];

        $model = new PublicSoa();
        $ret = $model->execute(array('regionGrade'=>'1','parentId'=>''),'getRegion');
        $volt['province'] = $ret['data'];
        //$volt['regionAction'] = $this->url->get('Common/region');
        $volt['regionAction'] = $this->url->get('Device/region');
        $ret1 = $model->execute(array(),'getUser');
        $this->view->setVar('userlist',$ret1['data']);
        $volt['packbaseAction'] = $this->url->get('lookup/index1/PackbaseSoa/');
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/step2');

        $model2 = new DeviceSoa;
        $ret1 = $model2->execute(array('regionGrade'=>'1','parentId'=>'0'),'getGroup');
        $this->view->setVar('group',$ret1['data']);
        $this->view->setVar('groupAction',$this->url->get('device/group'));
        $this->view->setVar('getgroupAction',$this->url->get('device/getgroup/'));

        $this->view->setVar('volt',$volt);
    }
    
    public function createotaAction()
    {
        $model = new $this->ModelClass;
        $con = $model->getConfig();
        $ctl = new CommonController();
        $volt['machtype'] = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid,'parentId'=>0,'modeltype'=>1));
    
        $model = new ApptempletSoa();
        //$ret = $model->findByPost(array('pageNum'=>1,'numPerPage'=>9999));
    
        $ret = $model->execute(array('page' => array('pageNum'=>1,'pageSize'=>9999),
            'order'=> array('field'=>'name','direction'=>'desc')),'index');
        $volt['appTemp'] = $ret['result'];
    
        $model = new PublicSoa();
        $ret = $model->execute(array('regionGrade'=>'1','parentId'=>''),'getRegion');
        $volt['province'] = $ret['data'];
        //$volt['regionAction'] = $this->url->get('Common/region');
        $volt['regionAction'] = $this->url->get('Device/region');
        $ret1 = $model->execute(array(),'getUser');
        $this->view->setVar('userlist',$ret1['data']);
        $volt['packbaseAction'] = $this->url->get('lookup/index1/PackbaseSoa/');
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/otastep2');
    
        $model2 = new DeviceSoa;
        $ret1 = $model2->execute(array('regionGrade'=>'1','parentId'=>'0'),'getGroup');
        $this->view->setVar('group',$ret1['data']);
        $this->view->setVar('groupAction',$this->url->get('device/group'));
        $this->view->setVar('getgroupAction',$this->url->get('device/getgroup/'));
    
        $this->view->setVar('volt',$volt);
    }
    
    public function createappAction()
    {
        $model = new $this->ModelClass;
        $con = $model->getConfig();
        $ctl = new CommonController();
        $volt['machtype'] = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid,'parentId'=>0,'modeltype'=>1));
    
        $model = new ApptempletSoa();
        //$ret = $model->findByPost(array('pageNum'=>1,'numPerPage'=>9999));
    
        $ret = $model->execute(array('page' => array('pageNum'=>1,'pageSize'=>9999),
            'order'=> array('field'=>'name','direction'=>'desc')),'index');
        $volt['appTemp'] = $ret['result'];
    
        $model = new PublicSoa();
        $ret = $model->execute(array('regionGrade'=>'1','parentId'=>''),'getRegion');
        $volt['province'] = $ret['data'];
        //$volt['regionAction'] = $this->url->get('Common/region');
        $volt['regionAction'] = $this->url->get('Device/region');
        $ret1 = $model->execute(array(),'getUser');
        $this->view->setVar('userlist',$ret1['data']);
        $volt['packbaseAction'] = $this->url->get('lookup/index1/PackbaseSoa/');
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/appstep2');
    
        $model2 = new DeviceSoa;
        $ret1 = $model2->execute(array('regionGrade'=>'1','parentId'=>'0'),'getGroup');
        $this->view->setVar('group',$ret1['data']);
        $this->view->setVar('groupAction',$this->url->get('device/group'));
        $this->view->setVar('getgroupAction',$this->url->get('device/getgroup/'));
    
        $this->view->setVar('volt',$volt);
    }

    public function create222Action($tp)
    {
        if($tp == 2){
            
        } elseif($tp == 1) {
        $model = new $this->ModelClass;
        $con = $model->getConfig();
        $ctl = new CommonController();
        $volt['machtype'] = $ctl->getmachinetype(array('includeParent'=>0,'supplierId'=>$con->default_supplierid));

        $model = new ApptempletSoa();
        //$ret = $model->findByPost(array('pageNum'=>1,'numPerPage'=>9999));
        
        $ret = $model->execute(array('page' => array('pageNum'=>1,'pageSize'=>9999),
            'order'=> array('field'=>'name','direction'=>'desc')),'index');
        $volt['appTemp'] = $ret['result'];

        $model = new PublicSoa();
        $ret = $model->execute(array('regionGrade'=>'1','parentId'=>''),'getRegion');
        $volt['province'] = $ret['data'];
        //$volt['regionAction'] = $this->url->get('Common/region');
        $volt['regionAction'] = $this->url->get('Device/region');
        $ret1 = $model->execute(array(),'getUser');
        $this->view->setVar('userlist',$ret1['data']);
        $volt['packbaseAction'] = $this->url->get('lookup/index1/PackbaseSoa/');
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/step2');
        
        $model2 = new DeviceSoa;
        $ret1 = $model2->execute(array('regionGrade'=>'1','parentId'=>'0'),'getGroup');
        $this->view->setVar('group',$ret1['data']);
        $this->view->setVar('groupAction',$this->url->get('device/group'));
        $this->view->setVar('getgroupAction',$this->url->get('device/getgroup/'));
        
        $this->view->setVar('volt',$volt);
        } else {
            $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/create/'.$tp);
            $this->view->pick('updplan/create0');
        }
    }

    public function importAction($type)
    {
        $type = isset($type) ? $type : 'tpos';
        $session = $this->session->get('rbac');
        $volt['session'] = $session;
        $volt['session']['session_keys'] = implode(',',array_keys($session));
        $volt['session'][session_name()] = session_id();
        $volt['session'] = json_encode($volt['session']);
        if(PHP_SAPI == 'fpm-fcgi'){
            $volt['swf'] = $this->url->get('uploadify/uploadify.swf');
        } else {
            $volt['swf'] = $this->url->get('public/uploadify/uploadify.swf');
        }
        $volt['downloadtxtAction'] = $this->url->get($this->dispatcher->getControllerName().'/downloadtxt');
        $volt['upload'] = $this->url->get($this->dispatcher->getControllerName().'/upload');
        $volt['getinf'] = $this->url->get($this->dispatcher->getControllerName().'/getinf');
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName()."/stepimport2/$type");
        $volt['type'] = $type;
        $this->view->setVar('volt',$volt);
    }

    public function uploadAction($type)
    {
        if (!empty($_FILES))
        {
            $Path = '../program/tmp/';
            if (!is_dir($Path))
            {
                $this->mkdirs($Path);
                chmod($Path, 0777);//改变文件权限
            }

            $tempfile = $_FILES['Filedata']['tmp_name'];
            $filename = $_FILES["Filedata"]["name"];
            $extend = pathinfo($_FILES["Filedata"]["name"]);
            $uploadfile = $Path.$this->_guid().'.'.$extend[extension];

            if(move_uploaded_file($tempfile,$uploadfile))
            {
                $res = array('filename'=>$filename,'filesize'=>$_FILES["Filedata"]["size"],'uploadfile'=>$uploadfile);
                echo json_encode($res);
            }
            else
                echo json_encode(array('error'=>'error'));
        }
        else
            echo json_encode(array('error'=>'error'));
    }

    public function stepimport2Action($type)
    {
        $type = isset($type) ? $type : 'tpos';
        $file = @fopen($_POST['file'],"r");
        if(($file == NULL))
        {
            $this->view->setVar('error','File upload failed! Please return to the first step to upload the normal TXT file!');
            return;
        }

        $data = '';
        while(!@feof($file))
        {
            $str = trim(@fgets($file));
            if(!empty($str)) {
                $data .= ','.$str;
            }
        }
        @fclose($file);
        unlink($_POST['file']);

        if(empty($data))
        {
            $this->view->setVar('error','No read to body number! Please return to the first step to upload the normal TXT file!');
            return;
        }

        $model = new $this->ModelClass;
        $res = $model->execute(array('machineId'=>substr($data,1), 'type' => $type),'getTerminalInfos');

        if(empty($res['data']))
        {
            $this->view->setVar('error','Terminal not found in system file! Please return to the first step to re upload the TXT file!');
            return;
        }

        $str = substr(trim($data),1);;
        $tmp = explode(',', $str);

        $result = array();
        foreach ($res['data'] as $key => $value) {
            $result[] = $value['machineid'];
        }

        if (count($result) != count($tmp)) {
            $error_arr = array_diff($tmp, $result);
            $this->view->setVar('error','The upload file has the error terminal number! Please check and return to the first step to re upload TXT file!');
            $this->view->setVar('machineids', $error_arr);
            return;
        }

        $data = array_unique(explode(',',substr($data,1)));
        $ids = array();
        foreach($res['data'] as $dat)
        {
            $ids[] = $dat['machineid'];
        }
        if($_POST['plantype'] == '1'){
            $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/step3');
        } elseif ($_POST['plantype'] == '2') {
            $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/otastep3');
        } elseif ($_POST['plantype'] == '3') {
            $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/appstep3');
        }
        $volt['rowset'] = $res['data'];
        $volt['rowset_notin'] = array_diff($data, $ids);
        $volt['count_res'] = count($res['data']);
        $volt['count_data'] = count($data);
        $this->view->setVar('volt',$volt);
    }

    public function step2Action($type = 'tpos')
    {
        $type = isset($type) ? $type : 'tpos';
        $this->step2searchAction($type);
    }

    public function step2searchAction($type)
    {
        $type = isset($type) ? $type : 'tpos';
        $_POST['baseId'] = $_POST['packbase1_id'];
        $_POST['sdkId'] = $_POST['packbase2_id'];
        $_POST['middleId'] = $_POST['packbase3_id'];
        $_POST['modeltype'] = 0;
        $_POST['type'] = $type;
        if(isset($_POST['regionId']))
            $_POST['regionId'] = $_POST['regionId'] == 'all'? '':$_POST['regionId'];
        if(isset($_POST['groupid']))
            $_POST['groupid'] = $_POST['groupid'] == 'all'? '':$_POST['groupid'];
        $model = new DeviceSoa();

        $volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 20;
        $volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;
        $volt['orderField'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
        $volt['orderDirection'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];
        //print_r($volt);die;
        $res = $model->findByPost2(array_merge($_POST,$volt));
        $volt['count'] = $res['totalRows'];
        $volt['rowset'] = $res['data'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['rel'] = $this->dispatcher->getControllerName().'_step2_index';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/step2search');
        $volt['action2'] = $this->url->get($this->dispatcher->getControllerName().'/step3');

        $volt['mcc'] = $_POST['mcc'];
        $volt['modelId'] = $_POST['modelId'];
        $volt['communicateWay'] = $_POST['communicateWay'];
        $volt['appTempId'] = $_POST['appTempId'];
        if(isset($_POST['regionId']))
            $volt['regionId'] = $_POST['regionId'] == 'all'? '':$_POST['regionId'];
        if(isset($_POST['groupid']))
            $volt['groupid'] = $_POST['groupid'] == 'all'? '':$_POST['groupid'];
        $volt['baseId'] = $_POST['baseId'];
        $volt['sdkId'] = $_POST['sdkId'];
        $volt['middleId'] = $_POST['middleId'];

        $this->view->setVar('volt',$volt);
    }

    public function step3Action()
    {
        $model = new ApptempletSoa();
        //$ret = $model->findByPost(array('pageNum'=>1,'numPerPage'=>9999));print_r($ret);die;
        $ret = $model->execute(array('page' => array('pageNum'=>1,'pageSize'=>9999),
            'order'=> array('field'=>'name','direction'=>'desc')),'index');
        $volt['appTemp'] = $ret['result'];
        // $volt['excludeTermId'] = implode(',',array_unique($_POST['deleteid']));
        //$volt['excludeTermId'] = implode(',', array_unique(explode(',', $_POST['terminalIds'])));
        //$volt['excludeTermId'] = implode(',', array_unique(explode(',', $_POST['deleteid'])));
        $volt['excludeTermId'] = implode(',',$_POST['deleteid']);
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/step4');

        $volt['packbase1Action'] = $this->url->get('lookup/index1/PackbaseSoa/packageType=1|modelId='.$_POST['modelId']);
        $volt['packbase2Action'] = $this->url->get('lookup/index1/PackbaseSoa/packageType=2|modelId='.$_POST['modelId']);
        $volt['packbase3Action'] = $this->url->get('lookup/index1/PackbaseSoa/packageType=3|modelId='.$_POST['modelId']);
        $this->view->setVar('volt',$volt);
    }

    public function step4Action()
    {
        if (!isset($_POST['appTempID2'])) {
            $result = array('status' => array('success' => 0,'message' => 'Lack of application templates','errorCode' => 0));

            echo json_encode($result);
            exit();
        }
        /*$volt = $_POST;
        $model = new DeviceSoa();
        $ret = $model->execute($_POST,'updplangetid');
        $volt['terminalID'] = $ret['data']['termIds'];*/
        $volt = $_POST;
        //$volt['terminalID'] = $_POST['excludeTermId'];
        $volt['terminalID'] = $_POST['excludeTermId'];
        $volt['creator'] = $_SESSION['rbac']['userid'];

        $volt['rel'] = $this->dispatcher->getControllerName().'_step4_index';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName()."/step5");
        $this->view->setVar('volt',$volt);
    }

    public function step5Action()
    {
        if (!isset($_POST['terminalID'])) {
            $result = array(
                'data' => '',
                'success' => false,
                'error' => 'Lack of application templates',
                'errorCode' => 300
            );
            echo json_encode($result);
            exit();
        }
        $model = new $this->ModelClass;
        //$volt = $model->execute($_POST,'add');
        $res = $model->execute(array('param' => $_POST),'add');
        if($res['status']['success']){
            $volt = array('data' => '', 'error' => '', 'errorCode' => 100, 'success' => true);
        } else {
            $volt = array('data' => '', 'error' => $res['status']['message'], 'errorCode' => 100, 'success' => false);
        }
        echo json_encode($volt);
    }

    public function canceldetailAction()
    {
        $model = new $this->ModelClass;
        $res = $model->execute(array('planIds'=>$_POST['idss']),'canceldetail');
        if(!$res['success'])
            $ret = array('statusCode'=>300,'message'=>'Save Failed ：'."[{$res['errorCode']}] {$res['error']}");
        else
            $ret = array('statusCode'=>200,'message'=>'Success','rel'=>$this->rel.'_detail');
        echo json_encode($ret);
    }

    public function exportdetailAction($id)
    {
        $model = new $this->ModelClass;
        $res = $model->execute(array('planID'=>$id),'exportdetail');
        if(!$res['success']) {
            echo '<script>$.pdialog.closeCurrent();alertMsg.error("Failed to get information!");</script>';
            exit;
        }
        if(empty($res['data'])) {
            echo '<script>$.pdialog.closeCurrent();alertMsg.error("No data!");</script>';
            exit;
        }

        $res2 = $model->execute(array('planID'=>$id),'statistics');
        $statics = $res2['data'];

        try{
            //$dir = '../'.$this->dir;
            $dir = '../public/'.$this->dir;
            if (!is_dir($dir)) {
                $this->mkdirs($dir);
                chmod($dir, 0777);//改变文件权限
            }

            set_time_limit(0);
            ini_set('memory_limit', '-1');

            $objPHPExcel = new PHPExcel();
            $objPHPExcel->setActiveSheetIndex(0);
            $objPHPExcel->getActiveSheet()->setTitle("Upgrade report");

            $objPHPExcel->getActiveSheet()
                ->setCellValue('A1', 'Not start')
                ->setCellValue('B1', 'Upgrading')
                ->setCellValue('C1', 'Complete')
                ->setCellValue('D1', 'Time out')
                ->setCellValue('E1', 'Upgrade success')
                ->setCellValue('F1', 'Upgrade Failed')
                ->setCellValue('G1', 'Canceled')
                ->setCellValueExplicit('A2', $statics['unComplete'])
                ->setCellValueExplicit('B2', $statics['onUpdating'])
                ->setCellValueExplicit('C2', $statics['downloadComplete'])
                ->setCellValueExplicit('D2', $statics['timeOut'])
                ->setCellValueExplicit('E2', $statics['updateSuccess'])
                ->setCellValueExplicit('F2', $statics['updateFailure'])
                ->setCellValueExplicit('G2', $statics['cancel']);

            foreach (array('A','B','C','D','E','F','G') as $key ) {
                $objPHPExcel->getActiveSheet()->getStyle($key.'1')->getFont()->setBold(true);
                $objPHPExcel->getActiveSheet()->getColumnDimension($key)->setWidth(20);
            }

            $msgWorkSheet = new PHPExcel_Worksheet($objPHPExcel, 'Details');
            $objPHPExcel->addSheet($msgWorkSheet);
            $objPHPExcel->setActiveSheetIndex(1);

            /*$colname = array(
                'A1'=>'商户名',
                'B1'=>'商户号',
                'C1'=>'终端号',
                'D1'=>'机身号',
                'E1'=>'状态',
                'F1'=>'开始时间',
                'G1'=>'结束时间',
                'H1'=>'经历时长'
            );*/
            $colname = array(
                'A1'=>'SN',
                'B1'=>'Termianl No.',
                'C1'=>'Merchant No.',
                'D1'=>'Merchant development organization',
                'E1'=>'Site address',
                'F1'=>'Status',
                'G1'=>'Start',
                'H1'=>'End',
                'I1'=>'Time'
            );
            $setWidth = array (
                'A'=>20,
                'B'=>20,
                'C'=>30,
                'D'=>20,
                'E'=>20,
                'F'=>30,
                'G'=>30,
                'H'=>30,
                'I'=>30
            );
            foreach ($setWidth as $key => $value ) {
                $objPHPExcel->getActiveSheet()->getColumnDimension($key)->setWidth($value);
            }
            foreach ($colname as $key => $value ) {
                $objPHPExcel->getActiveSheet()->setCellValue($key, $value);
                $objPHPExcel->getActiveSheet()->getStyle($key)->getFont()->setBold(true);
            }

            $j = 2;

            foreach($res['data'] as $tr) {
                if($tr['endtime'] == '0000-00-00 00:00:00')
                    $tr['endtime'] = date('Y-m-d H:i:s',time());
                $time = strtotime($tr['endtime'])-strtotime($tr['starttime']);
                $updateTime = (int)($time/(3600*24)).'Days'.(int)(($time%(3600*24))/(3600)).'Hours'.(int)($time%(3600)/60).'Minutes'.(int)($time%60).'Seconds';
                $objPHPExcel->getActiveSheet()
                    ->setCellValue('A'.$j, $tr['machineid'])
                    ->setCellValue('B'.$j, $tr['terminalno'])
                    ->setCellValue('C'.$j, $tr['merchantno'])
                    ->setCellValue('D'.$j, $tr['organization'])
                    ->setCellValue('E'.$j, $tr['address'])
                    ->setCellValueExplicit('F'.$j, $this->getName($tr['status']))
                    ->setCellValueExplicit('G'.$j, $tr['starttime'])
                    ->setCellValueExplicit('H'.$j, $tr['endtime'])
                    ->setCellValue('I'.$j, $updateTime);
                $j++;
            }

            $objPHPExcel->setActiveSheetIndex(0);

            //$guid = $this->_guid();
            $guid = date('YmdHis',time()).rand(100,999);
            $filename = "{$dir}{$guid}.xlsx";
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save($filename);

            $objPHPExcel->disconnectWorksheets();
            unset($objPHPExcel);

            //$time = date('YmdHis',time());
            //$this->downloadpageAction($guid,"{$time}.xlsx");
            $this->downloadpageAction($guid,"{$guid}.xlsx");
            $this->view->pick('factorymachineadd/downloadpage');
        }
        catch (Exception $e) {   
            echo json_encode(array('statusCode'=>300,'message'=>'Export Error'.$e->getMessage()));
            exit;
        }
    }
	
    public function downloadpageAction($guid,$filename)
    {
    	//$this->view->setVar('action',$this->url->get($this->dispatcher->getControllerName()."/download/{$guid}/{$filename}"));
        $this->view->setVar('action',"/filecache/updplandetail/{$filename}");
            $this->view->setVar('filename',$filename);
    }
    
    public function downloadAction($guid,$filename)
    {
    	$filePath = $this->url->get("{$this->dir}{$guid}.xlsx");
    	$filePath = $_SERVER['DOCUMENT_ROOT'].$filePath;
    	$contents = '';
    	/**
    	$ua = $_SERVER["HTTP_USER_AGENT"];
	$encoded_filename = urlencode($filename);
	$encoded_filename = str_replace("+", "%20", $encoded_filename);
    	$this->response->setHeader("Content-Type","application/octet-stream");
    
        if (preg_match("/MSIE/", $ua))
        {
            $this->response->setHeader("Content-Disposition",'attachment; filename="' . $encoded_filename . '"');
        }
        else if (preg_match("/Firefox/", $ua))
        {
            $this->response->setHeader("Content-Disposition",'attachment; filename*="utf8\'\'' . $filename . '"');
        }
        else
        {
            $this->response->setHeader("Content-Disposition",'attachment; filename="'.$filename.'"');
        }
    	if (file_exists($filePath) && ($file=fopen($filePath,"r")))
    	{
            $contents = fread($file,filesize($filePath));
            fclose($file);
    	}
    	echo $contents;
    	**/
    	header("Content-Type: application/force-download");
    	
    	header("Content-Disposition:attachment;filename={$filename}");
    	//echo file_get_contents($filePath);
    	readfile($filePath);
    }
	
    public function regionAction($id,$grade)
    {
        $model = new PublicSoa();
        $ret = $model->execute(array('regionGrade'=>$grade,'parentId'=>$id),'getRegion');
        if($grade=='2')
        {
            if(in_array($id,array('110000','120000','310000','500000')))
                $place = array(array('zx','All area'));
            else 
                $place = array(array('all','All city'));
        }
        elseif($grade=='3')
        {
            if( in_array(substr($id,0,2),array('zx','11','12','31','50')) )
                $place = array();
            else
                $place = array(array('all','All district and county'));
        }
        else 
            $place = array();
        foreach ($ret['data'] as $reg)
        {
            $place[] = array($reg['regioncode'],$reg['regionname']);
        }
        echo json_encode($place); 
    }
    
    public function otastep2Action()
    {
        $this->otastep2searchAction();
    }
    
    public function otastep2searchAction()
    {
        $_POST['baseId'] = $_POST['packbase1_id'];
        $_POST['sdkId'] = $_POST['packbase2_id'];
        $_POST['middleId'] = $_POST['packbase3_id'];
        $_POST['modeltype'] = 1;
        if(isset($_POST['regionId']))
            $_POST['regionId'] = $_POST['regionId'] == 'all'? '':$_POST['regionId'];
        if(isset($_POST['groupid']))
            $_POST['groupid'] = $_POST['groupid'] == 'all'? '':$_POST['groupid'];
        $model = new DeviceSoa();
    
        $volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 20;
        $volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;
        $volt['orderField'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
        $volt['orderDirection'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];
        $res = $model->findByPost2(array_merge($_POST,$volt));
        $volt['count'] = $res['totalRows'];
        $volt['rowset'] = $res['data'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['rel'] = $this->dispatcher->getControllerName().'_step2_index';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/otastep2search');
        $volt['action2'] = $this->url->get($this->dispatcher->getControllerName().'/otastep3');
        
        $volt['mcc'] = $_POST['mcc'];
        $volt['modelId'] = $_POST['modelId'];
        $volt['communicateWay'] = $_POST['communicateWay'];
        $volt['appTempId'] = $_POST['appTempId'];
        if(isset($_POST['regionId']))
            $volt['regionId'] = $_POST['regionId'] == 'all'? '':$_POST['regionId'];
        if(isset($_POST['groupid']))
            $volt['groupid'] = $_POST['groupid'] == 'all'? '':$_POST['groupid'];
        $volt['baseId'] = $_POST['baseId'];
        $volt['sdkId'] = $_POST['sdkId'];
        $volt['middleId'] = $_POST['middleId'];
        $this->view->setVar('volt',$volt);
    }
    
    public function otastep3Action()
    {
        $model = new ApptempletSoa();
        //$ret = $model->findByPost(array('pageNum'=>1,'numPerPage'=>9999));print_r($ret);die;
        $ret = $model->execute(array('page' => array('pageNum'=>1,'pageSize'=>9999),
            'order'=> array('field'=>'name','direction'=>'desc')),'index');
        $volt['appTemp'] = $ret['result'];
        // $volt['excludeTermId'] = implode(',',array_unique($_POST['deleteid']));
        //$volt['excludeTermId'] = implode(',', array_unique(explode(',', $_POST['terminalIds'])));
        //$volt['excludeTermId'] = implode(',', array_unique(explode(',', $_POST['deleteid'])));
        $volt['excludeTermId'] = implode(',',$_POST['deleteid']);
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/otastep4');
    
        $volt['packbase1Action'] = $this->url->get('lookup/index1/SposSoa');
        $this->view->setVar('volt',$volt);
    }
    
    public function otastep4Action()
    {
        /*$volt = $_POST;
         $model = new DeviceSoa();
         $ret = $model->execute($_POST,'updplangetid');
         $volt['terminalID'] = $ret['data']['termIds'];*/
        $volt = $_POST;
        //$volt['terminalID'] = $_POST['excludeTermId'];
        $volt['terminalID'] = $_POST['excludeTermId'];
        $volt['creator'] = $_SESSION['rbac']['userid'];
    
        $volt['rel'] = $this->dispatcher->getControllerName().'_step4_index';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName()."/otastep5");
        $this->view->setVar('volt',$volt);
    }
    
    public function otastep5Action()
    {
        if (!isset($_POST['otaid']) || $_POST['otaid'] == '') {
            $result = array(
                'data' => '',
                'success' => false,
                'error' => 'The lack of ota package',
                'errorCode' => 300
            );

            echo json_encode($result);
            exit();
        }
        $model = new $this->ModelClass;
        //$volt = $model->execute($_POST,'add');
        $res = $model->execute(array('param' => $_POST),'add');
        if($res['status']['success']){
            $volt = array('data' => '', 'error' => '', 'errorCode' => 100, 'success' => true);
        } else {
            $volt = array('data' => '', 'error' => $res['status']['message'], 'errorCode' => 100, 'success' => false);
        }
        echo json_encode($volt);
    }
    
    public function appstep2Action()
    {
        $this->appstep2searchAction();
    }
    
    public function appstep2searchAction()
    {
        $_POST['baseId'] = $_POST['packbase1_id'];
        $_POST['sdkId'] = $_POST['packbase2_id'];
        $_POST['middleId'] = $_POST['packbase3_id'];
        $_POST['modeltype'] = 1;
        if(isset($_POST['regionId']))
            $_POST['regionId'] = $_POST['regionId'] == 'all'? '':$_POST['regionId'];
        if(isset($_POST['groupid']))
            $_POST['groupid'] = $_POST['groupid'] == 'all'? '':$_POST['groupid'];
        $model = new DeviceSoa();
    
        $volt['numPerPage'] = $this->request->hasPost('numPerPage') ? (int) $this->request->getPost('numPerPage') : 20;
        $volt['pageNum'] = $this->request->hasPost('pageNum') ? (int) $this->request->getPost('pageNum') : 1;
        $volt['orderField'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
        $volt['orderDirection'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];
        //print_r($volt);die;
        $res = $model->findByPost2(array_merge($_POST,$volt));
        $volt['count'] = $res['totalRows'];
        $volt['rowset'] = $res['data'];
        $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
        $volt['rel'] = $this->dispatcher->getControllerName().'_step2_index';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/appstep2search');
        $volt['action2'] = $this->url->get($this->dispatcher->getControllerName().'/appstep3');
    
        $volt['mcc'] = $_POST['mcc'];
        $volt['modelId'] = $_POST['modelId'];
        $volt['communicateWay'] = $_POST['communicateWay'];
        $volt['appTempId'] = $_POST['appTempId'];
        if(isset($_POST['regionId']))
            $volt['regionId'] = $_POST['regionId'] == 'all'? '':$_POST['regionId'];
        if(isset($_POST['groupid']))
            $volt['groupid'] = $_POST['groupid'] == 'all'? '':$_POST['groupid'];
        $volt['baseId'] = $_POST['baseId'];
        $volt['sdkId'] = $_POST['sdkId'];
        $volt['middleId'] = $_POST['middleId'];
    
        $this->view->setVar('volt',$volt);
    }
    
    public function appstep3Action()
    {
        $model = new ApptempletSoa();
        //$ret = $model->findByPost(array('pageNum'=>1,'numPerPage'=>9999));print_r($ret);die;
        $ret = $model->execute(array('page' => array('pageNum'=>1,'pageSize'=>9999),
            'order'=> array('field'=>'name','direction'=>'desc')),'index');
        $volt['appTemp'] = $ret['result'];
        // $volt['excludeTermId'] = implode(',',array_unique($_POST['deleteid']));
        //$volt['excludeTermId'] = implode(',', array_unique(explode(',', $_POST['terminalIds'])));
        //$volt['excludeTermId'] = implode(',', array_unique(explode(',', $_POST['deleteid'])));
        $volt['excludeTermId'] = implode(',',$_POST['deleteid']);
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/appstep4');
    
        $volt['packbase1Action'] = $this->url->get('lookup/index1/ApkfileSoa');
        $this->view->setVar('volt',$volt);
    }
    
    public function appstep4Action()
    {
        /*$volt = $_POST;
         $model = new DeviceSoa();
         $ret = $model->execute($_POST,'updplangetid');
         $volt['terminalID'] = $ret['data']['termIds'];*/
        $volt = $_POST;
        //$volt['terminalID'] = $_POST['excludeTermId'];
        $volt['terminalID'] = $_POST['excludeTermId'];
        $volt['creator'] = $_SESSION['rbac']['userid'];
    
        $volt['rel'] = $this->dispatcher->getControllerName().'_step4_index';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName()."/appstep5");
        $this->view->setVar('volt',$volt);
    }
    
    public function appstep5Action()
    {
        $model = new $this->ModelClass;
        //$volt = $model->execute($_POST,'add');
        $_POST['appid'] = '';
        if($_POST['appid1'] != '')
            $_POST['appid'] .= $_POST['appid1'].',';
        if($_POST['appid2'] != '')
            $_POST['appid'] .= $_POST['appid2'].',';
        if($_POST['appid3'] != '')
            $_POST['appid'] .= $_POST['appid3'].',';
        if($_POST['appid4'] != '')
            $_POST['appid'] .= $_POST['appid4'].',';
        if($_POST['appid5'] != '')
            $_POST['appid'] .= $_POST['appid5'].',';
        $_POST['appid'] = rtrim($_POST['appid'], ",");
        if ($_POST['appid'] == '') {
            $result = array(
                'data' => '',
                'success' => false,
                'error' => 'The lack of app package',
                'errorCode' => 300
            );
            echo json_encode($result);
            exit();
        }
        $res = $model->execute(array('param' => $_POST),'add');
        if($res['status']['success']){
            $volt = array('data' => '', 'error' => '', 'errorCode' => 100, 'success' => true,'rel'=>$this->rel,'callbackType'=>true,'message'=>$res['status']['message']);
        } else {
            $volt = array('data' => '', 'error' => $res['status']['message'], 'errorCode' => 100, 'success' => false);
        }
        echo json_encode($volt);
    }
    
    public function downloadtxtAction(){
        $name = 'shengji.txt';
        //$filename = realpath('../filecache/importdevice/'.$name);
        $file_dir = '../filecache/importdevice/';
        $file = @fopen($file_dir . $name,"r");
        $downfilename= basename($name);
        if (!$file) {
            echo "File not found";
        } else {
            header("content-type: application/octet-stream");
            header("content-disposition: attachment; filename=" . $downfilename);
            while (!feof ($file)) {
                echo fread($file,50000);
            }
            fclose ($file);
        }
    }
    
    public function adddeviceAction(){
    	$volt = $_POST;
     	$model = new $this->ModelClass;
//     	echo $this->rel;die;
     	$res=$model->execute($volt,'addDevice');
//     	//print_r($volt);die;
     	if($res['success']==1){
      		$ret = array('statusCode'=>200,'message'=>'Save Success ','rel'=>$this->rel.'_detail','callbackType'=>'closeCurrent');
     	}else{
     		$ret = array('statusCode' => 300,'message'=>$res['message']);
     	}
    	echo json_encode($ret);
    	exit;
    }
    
    private function getName($i) {
        switch ($i) {
            case 0:
                $res = 'Not start';
                break;
            case 1:
                $res = 'Upgrading';
                break;
            case 2:
                $res = 'Complete';
                break;
            case 3:
                $res = 'Time out';
                break;
            case 4:
                $res = 'Upgrade success';
                break;
            case 5:
                $res = 'Upgrade Failed';
                break;
            case 6:
                $res = 'Canceled';
                break;
        }
        return $res;
    }
}