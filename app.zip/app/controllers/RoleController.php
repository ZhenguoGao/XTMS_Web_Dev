<?php
/** 
 * 角色管理
 *@author zhaimin
 */


class RoleController extends ControllerBaseSoa2
{
    public $ModelClass = 'RoleModel';

    public function createAction()
    {
        $model = new MenuModel();
        $lists = $model->execute(array(),'index1');
        foreach ($lists['result'] as $list)
        {
            $menus[] = array('id'=>$list['id'],'pId'=>$list['parentid'],'name'=>$list['name'],'open'=>true);
        }
        $this->view->setVar('menus', json_encode($menus));
        parent::createAction();
        $this->view->pick('role/edit');
    }

    public function editAction($pk)
    {
        $model = new $this->ModelClass;
        $volt = $model->findByPk($pk);
        $volt = $volt['result'];//print_r($volt);die;
        $model = new MenuModel();
        $lists = $model->execute(array(),'index1');
        foreach ($lists['result'] as $list)
        {
            $checked = in_array($list['id'], $volt['menuList'])? true:false;
            $menus[] = array('id'=>$list['id'],'pId'=>$list['parentid'],'name'=>$list['name'],'open'=>true,'checked'=>$checked);
        }
        $volt['menuList'] = implode(',',$volt['menuList']);
        $volt['act'] = 'upd';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $this->view->setVar('volt',$volt);
        $this->view->setVar('menus', json_encode($menus));
    }

    public function saveAction()
    {
        if(empty($_POST['menuList']))
            echo json_encode(array('statusCode'=>300,'message'=>'Please select a role accessible menu'));
        else
        {
            $_POST['menuList'] = explode(',', trim($_POST['menuList'],','));
            parent::saveAction();
        }
    }
}