<?php

/** 
 * @author lujun
 * 
 * 
 */
class SposController extends ControllerBaseSoa2 {
    public $ModelClass = 'SposSoa';

    public function createAction() {
        //$ctl = new CommonController();
        //$res = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid,'parentId'=>0,'modeltype'=>1));
        $ctl = new SposNew();
        $res = $ctl->getmodel($_SESSION['rbac']['idAlias']);
        $res = $res['data'];
        $volt['modelNames'] = array(''=>'Select machine type');
        foreach ($res as $re)
        {
            $volt['modelNames'][$re['id']] = $re['name'];
        }
        
        $model = new PublicSoa();
        $ret1 = $model->execute(array(),'getUser');
        $this->view->setVar('userlist',$ret1['data']);
        $this->view->setVar('getModelAction',$this->url->get($this->dispatcher->getControllerName().'/getmodel'));
        
        $volt['realPath'] = '../program/';
        $volt['absPath'] = 'program/tmp/';
        $volt['tempPath'] = '../program/tmp/';
        if (!is_dir($volt['tempPath']))
        {
            $this->mkdirs($volt['tempPath']);
            chmod($volt['tempPath'], 0777);//改变文件权限
        }
        $gid = $this->_guid();
        $volt['tempPath'] .= $gid;
        $volt['absPath'] .= $gid;
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $volt['packageType'] = $tp;
        
        $session = $this->session->get('rbac');
        $volt['session'] = $session;
        $volt['session']['tempPath'] = str_replace('\\','/',$volt['tempPath']);
        $volt['session']['absPath'] = str_replace('\\','/',$volt['absPath']);
        $volt['session']['session_keys'] = implode(',',array_keys($session));
        $volt['session'][session_name()] = session_id();
        $volt['session'] = json_encode($volt['session']);
        if(PHP_SAPI == 'fpm-fcgi'){
            $volt['button'] = $this->url->get('uploadify/open.png');
            $volt['swf'] = $this->url->get('uploadify/uploadify.swf');
        } else {
            $volt['button'] = $this->url->get('public/uploadify/open.png');
            $volt['swf'] = $this->url->get('public/uploadify/uploadify.swf');
        }
        $volt['upload'] = $this->url->get($this->dispatcher->getControllerName().'/upload');
        $volt['getinf'] = $this->url->get($this->dispatcher->getControllerName().'/getinf');
        $this->view->setVar('volt',$volt);
        $this->view->setVar('rel',$this->rel);
    }
    
    public function uploadAction()
    {
        $model = new $this->ModelClass;
        if (!empty($_FILES))
        {
            $tempfile = $_FILES['Filedata']['tmp_name'];
            $filename = $_FILES["Filedata"]["name"];
            $extend = pathinfo($_FILES["Filedata"]["name"]);
            if(move_uploaded_file($tempfile,$_REQUEST['tempPath'].$_REQUEST['tp'].'.'.$extend['extension']))
            {
                //解压
                $uploadfile = '../'.$_REQUEST['absPath'].$_REQUEST['tp'].'.'.$extend['extension'];
                $zip = new ZipArchive();
                if($zip->open($uploadfile) === TRUE){
                    $zip->extractTo('../'.$_REQUEST['absPath']);
                    $zip->close();
                }
                //读取解压后的文件
                $dirName = explode('.zip', $filename);
                //$dirName = '../'.$_REQUEST['absPath'].'/'.$dirName[0];
                $dirName = '../'.$_REQUEST['absPath'];
                //$content = $this->fileContent($dirName.'/ota.json');
                //print_r($dirName);die;
                if (!file_exists($dirName.'/ota.json')) {
                    echo json_encode(array('error' => 'error', 'message' => 'Uploading packages does not conform to specifications'));
                    exit();
                }
                $content = json_decode($this->fileContent1($dirName.'/ota.json'),true);
                if (!isset($content)) {
                    echo json_encode(array('error' => 'error', 'message' => 'Uploading packages does not conform to specifications'));
                    exit();
                }
                //print_r($content);die;
                $array = scandir($dirName);
                foreach ($array as $val) {
                    if(substr($val, -4) == '.zip') {
                        $zipfile = $val;
                        break;
                    }
                }
                /**
                $res = array_merge(array('filename'=>$filename,'filesize'=>$_FILES["Filedata"]["size"],
                    'uploadfile'=>$_REQUEST['absPath'].$_REQUEST['tp'].'.'.$extend[extension]),$content);
                **/
                $res = array_merge(array('filename'=>$filename,'filesize'=>$_FILES["Filedata"]["size"],
                    'uploadfile'=>$dirName.'/'.$zipfile),$content);
                echo json_encode($res);
            }
            else{
                echo json_encode(array('error'=>'error'));
            }
        }
        else{
            echo json_encode(array('error'=>'error'));
        }
    }
    
    private function fileContent($file) {
        if(@file_exists($file)){
            $file_arr = file($file);
            for($i = 0;$i < count($file_arr);$i++){
                //逐行读取文件内容
                //echo $file_arr[$i]."<br />";
                $val = explode("=",$file_arr[$i]);
                $res[$val[0]] = $val[1];
            }
            return $res;
        }
        return array();
    }
    
    private function fileContent1($file) {
        if(@file_exists($file)){
            $str = file_get_contents($file);
            //$str = str_replace("\r\n","<br />",$str);
            return $str;
        }
        return '';
    }
    
    public function saveAction()
    {
        $_POST['modelid'] = $_POST['model_id'];
        if(empty($_POST['uploadfile'])){
            exit(json_encode(array('statusCode'=>300,'message'=>'Please upload the file package to save!')));
        }
        $fileModel = $this->formatModel($_POST['version']);
        $model1 = new SposNew;
        $modelname = $model1->getModelName($_POST['modelid']);
        if($fileModel != $modelname)
            exit(json_encode(array('statusCode'=>300,'message'=>'The selected model is inconsistent with the file type!')));
        //parent::saveAction();
        $model = new $this->ModelClass;
        $res = $model->postSave($_POST);
        if(!$res['success']) {
            $ret = array('statusCode'=>300,'message'=>'Save Failed ：'."[{$res['errorCode']}] {$res['error']}");
        } else {
            $ret = array('statusCode'=>200,'message'=>'Save Success ','rel'=>$this->rel,'callbackType'=>'closeCurrent');
            $arr = explode('.',$_POST['name']);
            $array = explode('/'.$arr[0].'/',$_POST['uploadfile']);
            $this->delDirAndFile($array[0],true);
            unlink($array[0].'main.zip');
            unlink(substr($array[0],0,strripos($array[0],'/')).'main.zip');
        }
        echo json_encode($ret);
    }
    
    /**
     * 删除目录及目录下所有文件或删除指定文件
     * @param str $path   待删除目录路径
     * @param int $delDir 是否删除目录，1或true删除目录，0或false则只删除文件保留目录（包含子目录）
     * @return bool 返回删除状态
     */
    private function delDirAndFile($path, $delDir = FALSE) {
        $handle = opendir($path);
        if ($handle) {
            while (false !== ( $item = readdir($handle) )) {
                if ($item != "." && $item != "..")
                    is_dir("$path/$item") ? $this->delDirAndFile("$path/$item", $delDir) : unlink("$path/$item");
            }
            closedir($handle);
            if ($delDir)
                return rmdir($path);
        }else {
            if (file_exists($path)) {
                return unlink($path);
            } else {
                return FALSE;
            }
        }
    }
    
    public function removeAction($pk,$closeFlag=false)
    {
        $close = $closeFlag? 'closeCurrent' : '';
        $model = new $this->ModelClass;
        $res = $model->remove($pk);
        if(!$res['success'])
            $ret = array('statusCode'=>300,'message'=>'Delete Failed , the file package associated upgrade plan is not over');
        else
            $ret = array('statusCode'=>200,'message'=>'Delete Success','rel'=>$this->rel,'callbackType'=>$close);
        echo json_encode($ret);
    }
    
    public function editAction($pk)
    {
        $model = new $this->ModelClass;
        $volt = $model->findByPk($pk);
        if(!$volt['status']['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'Search Failed '."[{$volt['status']['errorCode']}] {$volt['status']['message']}")));
        $volt = $volt['result'];
        $volt['act'] = 'upd';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save1');
        $ctl = new CommonController();
        $res = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid,'parentId'=>0,'modeltype'=>1));
        $volt['modelNames'] = array(''=>'Select machine type');
        foreach ($res as $re)
        {
            $volt['modelNames'][$re['id']] = $re['name'];
        }
        Phalcon\Tag::setDefault("model_id", $volt['modelid']);
        $this->view->setVar('volt',$volt);
        $this->view->pick('apkfile/edit');
    }
    
    public function save1Action(){
        if($_POST['model_id'] == '')
            die(json_encode(array('statusCode'=>300,'message'=>'Select machine type')));
        $model = new SposNew;
        $res = $model->edit($_POST);
        if(!$res['success'])
            $ret = array('statusCode'=>300,'message'=>'Update Failed ：'."[{$res['errorCode']}] {$res['error']}");
        else
            $ret = array('statusCode'=>200,'message'=>'Update Success','rel'=>$this->rel,'callbackType'=>'closeCurrent');
        echo json_encode($ret);
    }
    
    private function formatModel($version){
        $array = explode('_',$version);
        if(count($array) < 2)
            return '';
        return substr($array[1], 0, -6);
    }
    
    public function getmodelAction(){
        $model = new SposNew();
        $res = $model->getmodel($_POST['useridalias']);
        $str = '<option selected="selected" value="">Select machine type</option>';
        foreach ($res['data'] as $re) {
            $str .= '<option value="'.$re['id'].'">'.$re['name'].'</option>';
        }
        echo $str;
    }
}