<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class deviceController extends ControllerBaseSoa2 {
    public $ModelClass = 'DeviceSoa';
	
    public function indexAction()
    {  
        parent::indexAction();
        $this->view->setVar('detailAction',$this->url->get($this->dispatcher->getControllerName().'/detailinfo/'));
        $this->view->setVar('mapAction',$this->url->get($this->dispatcher->getControllerName().'/map/'));
        $this->view->setVar('importAction',$this->url->get($this->dispatcher->getControllerName().'/import/'));
        if (!$this->request->isPost()) {
            $model = new PublicSoa();
            $ret = $model->execute(array('regionGrade'=>'1','parentId'=>''),'getRegion');
            $this->view->setVar('province',$ret['data']);
            //$this->view->setVar('regionAction',$this->url->get('Common/region'));
            $this->view->setVar('regionAction',$this->url->get($this->dispatcher->getControllerName().'/region'));
            
            $model1 = new $this->ModelClass;
            $ret1 = $model1->execute(array('regionGrade'=>'1','parentId'=>'0'),'getGroup');
            $this->view->setVar('group',$ret1['data']);
            $this->view->setVar('groupAction',$this->url->get($this->dispatcher->getControllerName().'/group'));
            
            $ret1 = $model->execute(array(),'getUser');
            $this->view->setVar('userlist',$ret1['data']);
            $ctl = new CommonController();//print_r($ctl);die;
            $con = $model->getConfig();
            $res = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid));
            $this->view->setVar('machinetypelist',$res);
        }
        $this->view->setVar('getgroupAction',$this->url->get($this->dispatcher->getControllerName().'/getgroup/'));
    }
    public function reportAction($machineId){
 
    	$model = new $this->ModelClass;
    	$res = $model->execute(array('machineId'=>$machineId),'reportInfo');
    	if(!$res['success']){
    		exit($res['error']);
    	}
//     	print_r($res['data']); exit;
    	$this->view->setVar('list',$res['data']);
    	
    }

    public function searchAction()
    {
        foreach ($_POST as $key=>$value) {
            $_POST[$key] = trim($value);
        }
        $this->view->setVar('form',$_POST);
        if(isset($_POST['regionId']))
            $_POST['regionId'] = $_POST['regionId'] == 'all'? '':$_POST['regionId'];
        if(isset($_POST['groupid']))
            $_POST['groupid'] = $_POST['groupid'] == 'all'? '':$_POST['groupid'];
        parent::searchAction();
        $this->view->setVar('detailAction',$this->url->get($this->dispatcher->getControllerName().'/detailinfo/'));
        $this->view->setVar('mapAction',$this->url->get($this->dispatcher->getControllerName().'/map/'));
    }

    public function mapAction()
    {
        $volt['rel'] = $this->dispatcher->getControllerName().'_index';
        $this->view->setVar('volt',$volt);
    }

    public function map2Action()
    {
        $volt['rel'] = $this->dispatcher->getControllerName().'_index';
        $this->view->setVar('volt',$volt);
    }

    public function setstatusAction($terminalId,$tp)
    {
        $method = $tp=='1'? 'seton':'setoff';
        $model = new $this->ModelClass();
        $res = $model->execute(array('terminalId'=>$terminalId),$method);
        if($res['success'])
            $ret = array('statusCode'=>'200','message'=>'Save Success ','rel'=>$this->rel);
        else
            $ret = array('statusCode'=>'300','message'=>'Save Failed '."[{$res['errorCode']}] {$res['error']}");
        echo json_encode($ret);
    }

    public function detailinfoAction($termId,$machineId,$terminalNo)
    {
        // $this->softwareinfoAction($machineId);
        $this->view->setVar('rel',$this->rel.'_detail');
        $this->view->setVar('machineId',$machineId);
        $this->view->setVar('action3',$this->url->get($this->dispatcher->getControllerName()."/softwareinfo/{$machineId}"));
        $this->view->setVar('action5',$this->url->get($this->dispatcher->getControllerName()."/updinfo/{$machineId}"));
        $this->view->setVar('action6',$this->url->get($this->dispatcher->getControllerName()."/merchantinfo/{$machineId}"));
        $this->view->setVar('action8',$this->url->get($this->dispatcher->getControllerName()."/report/{$machineId}"));
        $model = new $this->ModelClass();
        $res = $model->execute(array('machineId'=>$machineId),'apkinfo');
        if(!empty($res)) {
            $this->view->setVar('action7',$this->url->get($this->dispatcher->getControllerName()."/apkinfo/{$machineId}"));
            $this->view->setVar('apkinfo',true);
        }
        $this->updinfoAction($machineId);
    }

    public function updinfoAction($machineId)
    {
        $model = new LogupdateSoa();
        $res = $model->execute(array('machineId'=>$machineId,'orderField'=>'startTime','orderDirection'=>'desc'),'LogByMachineId');
        if(!$res['success']){
            exit($res['error']);
        }
        $this->view->setVar('updinfo',$res['data']);
    }

    public function softwareinfoAction($machineId)
    {
        $model = new PackbaseSoa();
        $res = $model->execute(array('sn'=>$machineId),'logUpload');
        $this->view->setVar('softwareinfo',$res['data']);
    }

    public function regionAction($grade,$id)
    {
        //$model = new UpdplanServ;
        $model = new PublicSoa();
        //$ret = $model->execute(array('regiongrade'=>$grade,'parentregion'=>$id),'getAllRegion');
        $ret = $model->execute(array('regiongrade'=>$grade,'parentId'=>$id),'getRegion');
        $place = array(array($id,'Unlimited'));
        foreach ($ret['data'] as $reg)
        {
            //$place[] = array($reg['regioncode'],$reg['regionname']);
            $place[] = array($reg['id'],$reg['regionname']);
        }
        echo json_encode($place); 
    }

    public function importAction()
    {
        $volt = array('session'=>$this->session->get('rbac'));//print_r($volt);die;
        unset($volt['session']['password']);
        /**
        $volt['session']['session_keys'] = implode(',',array_keys($volt['session']));
        $volt['session'][session_name()] = session_id();
        **/
        $volt['session'] = json_encode($volt['session']);
        if(PHP_SAPI == 'fpm-fcgi'){
            $volt['swf'] = $this->url->get('uploadify/uploadify.swf');
        } else {
            $volt['swf'] = $this->url->get('public/uploadify/uploadify.swf');
        }
        //$volt['upload'] = $this->url->get('common/upload');
        $volt['upload'] = $this->url->get($this->dispatcher->getControllerName().'/upload');
        $volt['confirmImportAction'] = $this->url->get($this->dispatcher->getControllerName().'/confirmimport');
        $volt['downloadImportExampleAction'] = $this->url->get($this->dispatcher->getControllerName().'/downloadimportexample');
        
        $model = new PublicSoa();
        $ret1 = $model->execute(array(),'getUser');
        $this->view->setVar('userlist',$ret1['data']);
        $this->view->setVar('volt',$volt);
    }
    
    public function uploadAction()
    {
        if (!count($_FILES)){
            exit(json_encode(array('error'=>'error')));
        }
        $path = '../program/tmp/';
        if (!is_dir($path)){
            $this->mkdirs($path);

            //改变文件权限
            chmod($path, 0777);
        }
        $name = $this->_guid();
        $uploadfile = $path.$name.'.'.pathinfo($_FILES["Filedata"]["name"], PATHINFO_EXTENSION);
        if(move_uploaded_file($_FILES['Filedata']['tmp_name'], $uploadfile)){
            $this->session->set($name, $uploadfile);
            exit(json_encode(array('originalFilename'=>$_FILES["Filedata"]["name"], 'newFilename'=>$name)));
        }else{
            exit(json_encode(array('error'=>'error', 'message'=>'File upload failed')));
        }
    }

    public function confirmimportAction()
    {
        $filename = realpath($this->session->get($this->request->getPost('name')));
        $name = $this->request->getPost('name');
        if(!is_file($filename)){
            exit(json_encode(array('statusCode'=>'300', 'message'=>'Please upload the Excel file')));
        }
        $model = new $this->ModelClass();
        //$res = $model->postFile(array('filename'=>$filename), 'import');
        $res = $model->postFile(array('filename'=>$filename,'useridalias'=>$_POST['useridalias'],'groupid'=>$_POST['groupid']), 'import');
        $this->session->remove($this->request->getPost('name'));
//        @unlink($filename);
        if(!$res['success']){
            exit(json_encode(array('statusCode'=>'300', 'message'=>'Import failed'."[{$res['errorCode']}] {$res['error']}")));
        }
        $this->updateimportFile($res['data'], $name);
        exit(
            json_encode(
                array(
                    'statusCode' => '200',
                    'message' => 'Import success',
                    'name' => $name
                )
            )
        );
//        exit(json_encode(array('statusCode'=>'200', 'message'=>isset($res['error']) ? $res['error'] : '导入成功', 'rel'=>$this->rel)));
    }

    private function updateimportFile($data, $name)
    {
        $filename = realpath('../program/tmp/'. $name . '.xlsx');
        if (file_exists($filename) && ($file = fopen($filename, "r"))) {
            $contents = fread($file, filesize($filename));
            fclose($file);
        }

        $PHPReader = new PHPExcel_Reader_Excel2007();
        if (!$PHPReader->canRead($filename)){
            return array('success' => false, 'message' => 'Loading Excel file failed！');
        }
        $PHPExcel = $PHPReader->load($filename);
        $currentSheet = $PHPExcel->getSheet(0); //读取excel文件中的第一个工作表
        $arr = array(1 => 'A', 2 => 'B', 3 => 'C', 4 => 'D', 5 => 'E', 6 => 'F', 7 => 'G', 8 => 'H', 9 => 'I', 10 => 'J', 11 => 'K',12 => 'L', 13 => 'M', 14 => 'N');
        foreach ($data as $key => $value) {
            $address = $arr[14] . $key;
            $currentSheet->setCellValue($address, $value['message']);
        }
        $PHPExcelWriter = new PHPExcel_Writer_Excel2007($PHPExcel);
        $PHPExcelWriter->save($filename);
    }

    public function downloadimportexampleAction()
    {
        $name = 'Import-device-example.xlsx';
        $filename = realpath('../filecache/importdevice/'.$name);
    	$contents = '';
    	$ua = $this->request->getUserAgent();
    	$this->response->setHeader("Content-Type", "application/octet-stream");
    
        if (preg_match("/MSIE/", $ua)) {
            $this->response->setHeader("Content-Disposition", 'attachment; filename="' . urlencode($name) . '"');
        } elseif (preg_match("/Firefox/", $ua)) {
            $this->response->setHeader("Content-Disposition", 'attachment; filename*="utf8\'\'' . $name . '"');
        } else {
            $this->response->setHeader("Content-Disposition", 'attachment; filename="'.$name.'"');
        }
    	if (file_exists($filename) && ($file = fopen($filename, "r"))) {
            $contents = fread($file, filesize($filename));
            fclose($file);
        }
        echo $contents;
    }

    public function downloadimportresultAction($name)
    {
        $filename = realpath('../program/tmp/'.$name);
        $contents = '';
        $ua = $this->request->getUserAgent();
        $this->response->setHeader("Content-Type", "application/octet-stream");

        if (preg_match("/MSIE/", $ua)) {
            $this->response->setHeader("Content-Disposition", 'attachment; filename="' . urlencode($name) . '"');
        } elseif (preg_match("/Firefox/", $ua)) {
            $this->response->setHeader("Content-Disposition", 'attachment; filename*="utf8\'\'' . $name . '"');
        } else {
            $this->response->setHeader("Content-Disposition", 'attachment; filename="'.$name.'"');
        }
        if (file_exists($filename) && ($file = fopen($filename, "r"))) {
            $contents = fread($file, filesize($filename));
            fclose($file);
        }
        echo $contents;
        @unlink($filename);
    }
    
    public function groupAction($grade,$id, $parentid)
    {
        $model = new $this->ModelClass;
        if ($id == $parentid) {
            $place = array(array($id,'All'));
        } else {
            $ret = $model->execute(array('regiongrade'=>$grade,'parentId'=>$id),'getGroup');
            $place = array(array($id,'All'));
            foreach ($ret['data'] as $reg)
            {
                //$place[] = array($reg['regioncode'],$reg['regionname']);
                $place[] = array($reg['id'],$reg['name']);
            }
        }

        echo json_encode($place);
    }
    
    public function createAction()
    {
        $ctl = new CommonController();
        $res = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid));
        $this->view->setVar('machinetypelist',$res);
        $getdata = $this->url->get($this->dispatcher->getControllerName().'/getdata');
        $this->view->setVar('getdata',$getdata);
        $model = new PublicSoa();
        $ret = $model->execute(array('regionGrade'=>'1','parentId'=>''),'getRegion');
        $province = $this->formatData($ret['data']);
        $ret1 = $model->execute(array(),'getUser');
        $this->view->setVar('userlist',$ret1['data']);
        parent::createAction();
        $this->view->setVar('province',$province);
    }
    
    public function editAction($pk)
    {
        $ctl = new CommonController();
        $res = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid));
        $this->view->setVar('machinetypelist',$res);
        $getdata = $this->url->get($this->dispatcher->getControllerName().'/getdata');
        $this->view->setVar('getdata',$getdata);
        $model = new PublicSoa();
        $ret = $model->execute(array('regionGrade'=>'1','parentId'=>''),'getRegion');
        $province = $this->formatData($ret['data']);
        $ret1 = $model->execute(array(),'getUser');
        $this->view->setVar('userlist',$ret1['data']);
        $this->view->setVar('province',$province);
        
        parent::updateAction($pk);
        $this->view->pick('device/edit');
    }
    
    public function merchantinfoAction($machineId)
    {
        $model = new $this->ModelClass;
        $res = $model->execute(array('machineId'=>$machineId),'merchantInfo');
        if(!$res['success']){
            exit($res['error']);
        }
        $this->view->setVar('merchantInfo',$res['data']);
    }
    
    public function saveAction($closeFlag=true)
    {
        /**
        $close = $closeFlag? 'closeCurrent' : '';
        $model = new $this->ModelClass;
        $res = $model->postSave($_POST);
        if(!$res['status']['success'])
            $ret = array('statusCode'=>300,'message'=>"数据保存失败{$res['status']['errorCode']}] {$res['status']['message']}");
        else
            $ret = array('statusCode'=>200,'message'=>"数据保存成功",'rel'=>$this->rel,'callbackType'=>$close);
        echo json_encode($ret);
        **/
        if($_POST['area'] != '') {
            $_POST['regionId'] = $_POST['area'];
            $_POST['installAddress'] = $this->areaDetail($_POST['province']).$this->areaDetail($_POST['city']).$this->areaDetail($_POST['area']).$_POST['installAddress'];
        } elseif($_POST['city'] != '') {
            $_POST['regionId'] = $_POST['city'];
            $_POST['installAddress'] = $this->areaDetail($_POST['province']).$this->areaDetail($_POST['city']).$_POST['installAddress'];
        } elseif($_POST['province'] != '') {
            $_POST['regionId'] = $_POST['province'];
            $_POST['installAddress'] = $this->areaDetail($_POST['province']).$_POST['installAddress'];
        } else {
            $_POST['regionId'] = '';
            $_POST['installAddress'] = $_POST['installAddress'];
        }
        if ($_POST['machineId'] == '') {
            $ret = array('statusCode'=>300,'message'=>'Add Failed,not input SN!');
            echo json_encode($ret);
            exit();
        }
        if ($_POST['modelId'] == '') {
            $ret = array('statusCode'=>300,'message'=>'Add Failed,unselected machine');
            echo json_encode($ret);
            exit();
        }
        if ($_POST['cycleTime'] < 60) {
            $ret = array('statusCode'=>300,'message'=>'Please enter cycle time more than 60 minutes');
            echo json_encode($ret);
            exit();
        }
        parent::saveAction();
    }
    
    public function getdataAction()
    {
        $model = new PublicSoa();
        $ret = $model->execute(array('regionGrade'=>'','parentId'=>$_POST['parentId']),'getRegion');
        $res = $this->formatData($ret['data']);
        echo $res;
    }
    
    public function formatData($array)
    {
        $res = '';
        foreach ($array as $val) {
            $res .= '<option value="'.$val['id'].'">'.$val['regionname'].'</option>';
        }
        return $res;
    }
    
    public function areaDetail($regionId){
        if($regionId == '')
            return '';
        $model = new PublicSoa();
        $res = $model->execute(array('id'=>$regionId),'getArea');
        return $res;
    }
    
    public function getgroupAction()
    {
        $useridalias = $_POST['useridalias'];
        $model = new $this->ModelClass;
        $ret = $model->execute(array('regionGrade'=>'1','parentId'=>'0','useridalias'=>$useridalias),'getGroup');
        //print_r($ret['data']);die;
        $place = array(array($id,'Unlimited'));
        foreach ($ret['data'] as $reg)
        {
            //$place[] = array($reg['regioncode'],$reg['regionname']);
            $place[] = array($reg['id'],$reg['name']);
        }
        echo json_encode($place);
    }
    
    public function apkinfoAction($machineId)
    {
        $model = new $this->ModelClass;
        $res = $model->execute(array('machineId'=>$machineId),'apkinfo');
        if(!$res['success']){
            exit($res['error']);
        }
        $result = json_decode($res,true);
        $this->view->setVar('apkInfo',$result);
    }
    
    public function updadd2Action($param)
    {
//     	$ctl = new CommonController();
//     	$res = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid));
//     	$this->view->setVar('machinetypelist',$res);
//     	$getdata = $this->url->get($this->dispatcher->getControllerName().'/getdata');
//     	$this->view->setVar('getdata',$getdata);
//     	$model = new PublicSoa();
//     	$ret = $model->execute(array('regionGrade'=>'1','parentId'=>''),'getRegion');
//     	$province = $this->formatData($ret['data']);
//     	$ret1 = $model->execute(array(),'getUser');
//     	$this->view->setVar('userlist',$ret1['data']);
//     	parent::createAction();
//     	$this->view->setVar('province',$province);
		$volt['planid'] = $param;
    	$volt['action'] = '/Updplan/adddevice';
    	$this->view->setVar('volt',$volt);
    }
}