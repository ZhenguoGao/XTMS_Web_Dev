<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class applicationController extends ControllerBaseSoa
{
    public $ModelClass = 'ApplicationSoa';

    public function createAction()
    {
        $volt['act'] = "add";
        $volt['title'] = "<i class='fa fa-plus'></i> Add";
        $volt['rel'] = $this->dispatcher->getControllerName().'_index';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $this->view->setVar('volt',$volt);
        $model = new $this->ModelClass;
        $con = $model->getConfig();
        $ctl = new CommonController();
        $res = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid,'parentId'=>0, 'modeltype' => 0));
        $this->view->setVar('machinetype',$res);
        $this->view->pick('application/edit');
    }

    public function updateAction($pk)
    {
        /**
        $model = new $this->ModelClass;
        $ret = $model->findByPk($pk);
        $volt = $ret['data']['app'];
        $progrem = $ret['data']['programList'];

        $con = $model->getConfig();
        $ctl = new CommonController();
        $res = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid,'parentId'=>0));

        $volt['act'] = "upd";
        $volt['title'] = "<i class='fa fa-edit'></i> 编辑应用";
        $volt['rel'] = $this->dispatcher->getControllerName().'_index';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $volt['reload'] = $this->url->get($this->dispatcher->getControllerName().'/update/'.$pk);
        $this->view->setVar('volt',$volt);
        $this->view->setVar('progrem',$progrem);
        $this->view->setVar('machinetype',$res);
        $this->view->pick('application/edit');
        Phalcon\Tag::setDefault('type', $volt['type']);
        Phalcon\Tag::setDefault('appIndex', $volt['appIndex']);
        **/
        $model = new $this->ModelClass;
        $res = $model->findByPk($pk);
        if(!$res['status']['success'])
            die(json_encode(array('statusCode'=>300,'message'=>'Search Failed '."[{$res['status']['errorCode']}] {$res['status']['message']}")));
        $volt = $res['result']['app'];
        $progrem = $res['result']['programList'];
        //print_r($progrem);die;
        //$con = $model->getConfig();
        //$ctl = new CommonController();
        //$res = $ctl->getmachinetype(array('includeParent'=>1,'supplierId'=>$con->default_supplierid,'parentId'=>0));
        //print_r($res['result']['machinetype']);die;
        $volt['act'] = "upd";
        $volt['title'] = '<i class="fa fa-edit"></i> Edit';
        $volt['rel'] = $this->dispatcher->getControllerName().'_index';
        $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/save');
        $volt['reload'] = $this->url->get($this->dispatcher->getControllerName().'/update/'.$pk);
        $this->view->setVar('volt',$volt);$this->view->setVar('progrem',$progrem);
        //$this->view->setVar('machinetype',$res);
        $this->view->setVar('machinetype',$res['result']['machinetype']);
        $this->view->pick('application/edit');
        Phalcon\Tag::setDefault('type', $volt['type']);
        Phalcon\Tag::setDefault('appIndex', $volt['appindex']);
    }

    public function saveAction()
    {
        $_POST['app']['name'] = $this->filter->sanitize($this->request->get('name'), 'string');
        $_POST['app']['number'] = $this->filter->sanitize($this->request->get('number'), 'int');
        $_POST['app']['type'] = $this->filter->sanitize($this->request->get('type'), 'int');
        $_POST['app']['appIndex'] = $this->filter->sanitize($this->request->get('appIndex'), 'int');
        $_POST['app']['version'] = $this->filter->sanitize($this->request->get('version'), 'string');
        $_POST['app']['description'] = $this->filter->sanitize($this->request->get('description'), 'string');
        if($this->filter->sanitize($this->request->get('act'), 'alphanum')=='add')
        {
            $_POST['app']['creator'] = $_SESSION['rbac']['userid'];
        }
        else
        {
            $_POST['app']['id'] = $this->filter->sanitize($this->request->get('id'), 'int');
            $_POST['app']['moidier'] = $_SESSION['rbac']['userid'];
        }
        $_POST['program'] = array();
        foreach ($_POST['modelId'] as $key=>$id)
        {
            if(!empty($_POST["pf{$key}_id"])){
                $_POST['program'][] = array('modelId'=>$id,'id'=>$_POST["pf{$key}_id"]);
            }
        }
        //parent::saveAction(false);
        $model = new $this->ModelClass;
        $res = $model->postSave($_POST);
        if(!$res['status']['success'])
            $ret = array('statusCode'=>300,'message'=>'Save Failed ：'."[{$res['errorCode']}] {$res['error']}");
        else
            $ret = array('statusCode'=>200,'message'=>'Save Success ','rel'=>$this->rel);
        echo json_encode($ret);
    }
    
    //new add by lujun 2016-12-28
    public function searchAction()
    {
        $model = new $this->ModelClass;
         $volt['page']['pageNum'] = 1;
         $volt['page']['pageSize'] = 1000;
         //$volt['order']['field'] = $this->request->hasPost('orderField') ? $this->request->getPost('orderField') : $model->order['field'];
         $volt['order']['field'] = 'id';
         //$volt['order']['direction'] = $this->request->hasPost('orderDirection') ? $this->request->getPost('orderDirection') : $model->order['direction'];
         $volt['order']['direction'] ='desc';
         $volt['param']['keywords'] = $this->request->getPost('keywords');
         //$res = $model->findByPost(array_merge($_POST,$volt));
         $res = $model->execute(array_merge($_POST,$volt),'index');
         if(!$res['success'])
             die(json_encode(array('statusCode'=>300,'message'=>'Search Failed ：'."[{$res['errorCode']}] {$res['error']}")));
         $volt['count'] = $res['page']['total'];
         $volt['list'] = $res['result'];
         $volt['totalPage'] = ceil($volt['count']/$volt['numPerPage']);
         $volt['rel'] = $this->rel;
         $volt['action'] = $this->url->get($this->dispatcher->getControllerName().'/index');
    
         $this->view->setVar('volt',$volt);
    }
}