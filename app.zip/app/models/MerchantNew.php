<?php

/**
 * merchant
 *  
 * @author lujun
 */

class MerchantNew extends ModelBase1
{
    var $pareTable = array(
        'getColumns'=>array('mersid','merchno','merchname','merchanttype','parentmersid','deptid','address','busitype','status',
            'opruser','salesman','createdate','modifydate','remark','useridalias','phoneno','organization'),
        'sequence'=>'T_MERCHANT_MERSID',
        'lookupfield'=>array('merchno','merchname')
    );
    
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
    );
    
    var $primaryKey = 'mersid';
    var $order = array('field'=>'merchno','direction'=>'desc');
    var $uniqueFields = array('merchno');
    
    public function getSource()
    {
        return 'T_MERCHANT';
    }
    
    public function getPK()
    {
        return 'mersid';
    }
}