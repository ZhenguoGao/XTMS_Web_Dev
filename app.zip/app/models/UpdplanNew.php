<?php

/**
 * UpdplanNew
 *  
 * @author lujun
 */

class UpdplanNew extends ModelBase1
{
    var $tableName = 't_upd_plan';
    var $pareTable = array(
        'getColumns'=>array('id','name','number','qty','appTempID','libID','middleID','sdkID','beginTime','endTime','connCount','intervalDay',
            'alarmTime','alarmType','modifier','updateTime','createTime','creator','description','status','useridalias','otaid','appid'),
        'lookupfield'=>array('name')
    );
    
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
    );
    var $primaryKey = 'id';
    
    public function findByPost($post, $get)
    {
        //print_r($post);die;
        $source = " FROM {$this->tableName} INNER JOIN t_auth_user ON {$this->tableName}.useridalias = t_auth_user.useridalias ";
		$condition = " where 1 = 1 and {$this->tableName}.status = 0 ";
        if(!empty($post['param'])){
            if($post['param']['name'] != '')
                $condition .= " and {$this->tableName}.name like '%{$post['param']['name']}%' ";
			if($post['param']['SN'] != '')
           		$condition .= " and {$this->tableName}.id in (select t_upd_planentry.planID from t_upd_planentry where t_upd_planentry.terminalID in (SELECT t_bd_terminal.id from t_bd_terminal where t_bd_terminal.machineId like '%{$post['param']['SN']}%'))";
            if($post['param']['beginTime'] != '')
                $condition .= " and {$this->tableName}.beginTime >= '{$post['param']['beginTime']} 00:00:00' ";
            if($post['param']['endTime'] != '')
                $condition .= " and {$this->tableName}.endTime <= '{$post['param']['endTime']} 23:59:59' ";
            if (isset($post['param']['type'])) {
                if ($post['param']['type'] == 'tpos') {
                    $condition .= " and {$this->tableName}.otaid = 0 AND {$this->tableName}.appid = '' ";
                } elseif ($post['param']['type'] == 'spos') {
                    $condition .= " and (({$this->tableName}.otaid = 0 and {$this->tableName}.appid != '') or {$this->tableName}.otaid > 0) ";
                } else {
                    $condition .= " ";
                }
            }
        }
        $count_sql = "SELECT COUNT(1) AS nrows {$source} {$condition} ";
        $sql = "SELECT {$this->tableName}.*,(SELECT NAME FROM t_app_temp WHERE id = {$this->tableName}.appTempID) AS appTempName,
            (SELECT packageName FROM t_app_package WHERE id={$this->tableName}.libID) AS libName,
            (SELECT packageName FROM t_app_package WHERE id={$this->tableName}.middleID) AS middleName,
            (SELECT packageName FROM t_app_package WHERE id={$this->tableName}.sdkID) AS sdkName,
            (SELECT `name` FROM t_app_android WHERE id={$this->tableName}.otaid) AS otaName,
            (SELECT `version` FROM t_app_android WHERE id={$this->tableName}.otaid) AS otaVersion,
            (SELECT GROUP_CONCAT(`name`) FROM t_app_apkfile WHERE FIND_IN_SET(id,t_upd_plan.appid)) AS appName,
            (SELECT GROUP_CONCAT(`versioncode`) FROM t_app_apkfile WHERE FIND_IN_SET(id,t_upd_plan.appid)) AS appVersionCode,
            (SELECT GROUP_CONCAT(`versionname`) FROM t_app_apkfile WHERE FIND_IN_SET(id,t_upd_plan.appid)) AS appVersionName,
            (SELECT GROUP_CONCAT(`nickname`) FROM t_app_apkfile WHERE FIND_IN_SET(id,t_upd_plan.appid)) AS appNickName,
            t_auth_user.name as username {$source} {$condition} ";
//             (SELECT GROUP_CONCAT(`name`,'/Version Name:',`versionname`,'/Version Code:',`versioncode`) FROM t_app_apkfile WHERE FIND_IN_SET(id,t_upd_plan.appid)) AS appName,
        $sql .= $this->param(true);
        $count_sql .= $this->param(true);
        //print_r($count_sql);die;
        $count = $this->db->fetchOne($count_sql);
        if(!empty($post)){
            $sql .= " ORDER BY {$this->qfield($post['order']['field'])} {$post['order']['direction']}";
            //echo $sql;die;
            $offset = (intval($post['page']['pageNum'])-1)*intval($post['page']['pageSize']);
            $sql .= " limit {$offset},{$post['page']['pageSize']}";
        }
        //print_r($sql);die;
        //$this->_logger->log($sql, \Phalcon\Logger::INFO);
        $rowset = $this->db->fetchAll($sql, 1);
        //print_r($rowset);die;
        return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
    }
    
    public function getPlanID($post)
    {
        //print_r($post);die;
        $sql = "SELECT p.*,t.machineId,t.terminalNo,t.merchantNo,t.modelName,t.communicateWay,t.buyerName,u.downNum,u.ignoreNum,u.needNum FROM t_upd_planentry p LEFT JOIN t_bd_terminal t ON p.terminalID = t.id LEFT JOIN (SELECT ddd.* FROM(SELECT planId,downNum,ignoreNum,needNum,terminalId FROM t_log_terminalupgrade WHERE t_log_terminalupgrade.planID = {$post['planID']} GROUP BY terminalId ORDER BY id DESC) ddd) u ON p.planId = u.planId AND t.id = u.terminalId WHERE  p.planID = {$post['planID']} ";
        $count_sql = "SELECT COUNT(1) AS nrows FROM t_upd_planentry p LEFT JOIN t_bd_terminal t ON p.terminalID = t.id LEFT JOIN (SELECT ddd.* FROM(SELECT planId,downNum,ignoreNum,needNum,terminalId FROM t_log_terminalupgrade GROUP BY terminalId ORDER BY id DESC) ddd) u 	ON p.planId = u.planId AND t.id = u.terminalId WHERE  p.planID = {$post['planID']} ";
        if($post['machineId'] != ''){
            $sql .= " and t.machineId like '%{$post['machineId']}%' ";
            $count_sql .= " and t.machineId like '%{$post['machineId']}%' ";
        }
        $count = $this->db->fetchOne($count_sql);
        //echo $count_sql;die;
        $offset = (intval($post['pageNum'])-1)*intval($post['numPerPage']);
        $sql .= " limit {$offset},{$post['numPerPage']}";
        //echo $sql;die;
        $rowset = $this->db->fetchAll($sql, 1);
        return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
    }
    
    /*
     * STATUS各参数代表的意义：未开始(0)、升级中(1)、下载完成(2)、超时(3)、升级成功(4)、升级失败(5)、已取消(6)
     */
    public function total($post)
    {
        $sql = "SELECT STATUS FROM t_upd_planentry WHERE planID = {$post['planID']};";
        $res = $this->db->fetchAll($sql, 1);
        $unComplete = 0;    //未开始0
        $onUpdating = 0;    //升级中1
        $downloadComplete = 0;  //下载完成2
        $timeOut = 0;   //超时3
        $updateSuccess = 0; //升级成功4
        $updateFailure = 0; //升级失败5
        $cancel = 0;    //已取消6

        foreach ($res as $val) {
            switch ($val['status']) {
                case 0:
                    $unComplete = $unComplete + 1;
                    break;
                case 1:
                    $onUpdating = $onUpdating + 1;
                    break;
                case 2:
                    $downloadComplete = $downloadComplete + 1;
                    break;
                case 3:
                    $timeOut = $timeOut + 1;
                    break;
                case 4:
                    $updateSuccess = $updateSuccess + 1;
                    break;
                case 5:
                    $updateFailure = $updateFailure + 1;
                    break;
                case 6:
                    $cancel = $cancel + 1;
                    break;
            }
        }
        return array('data' => array('cancel' => $cancel, 'downloadComplete' => $downloadComplete, 'onUpdating' => $onUpdating, 
            'timeOut' => $timeOut, 'unComplete' => $unComplete, 'updateFailure' => $updateFailure, 'updateSuccess' => $updateSuccess), 
            'error' => array('errorCode' => 100, 'success' => 1, 'totalRows' => '-1'));
    }
    
    public function exportPlan($post)
    {
        $sql = "SELECT t.machineId,t.merchantNo,t.terminalNo,t.buyerName,t.installAddress,pe.status,tu.startTime,tu.endTime,tu.totalTime,pe.id,m.merchname,m.address,m.organization FROM t_upd_planentry pe LEFT JOIN t_bd_terminal t ON t.id = pe.terminalID LEFT JOIN t_log_terminalupgrade tu ON tu.planID = pe.planID LEFT JOIN t_merchant m ON t.merchantNo = m.merchno WHERE tu.terminalId = t.id AND (pe.status = 1 OR pe.status = 2 OR pe.status = 4 OR pe.status = 5) AND pe.planID = {$post['planID']} group by t.machineId;";
        $count_sql = "SELECT COUNT(1) AS nrows FROM t_upd_planentry pe LEFT JOIN t_bd_terminal t ON t.id = pe.terminalID LEFT JOIN t_log_terminalupgrade tu ON tu.planID = pe.planID WHERE tu.terminalId = t.id AND (pe.status = 1 OR pe.status = 2 OR pe.status = 4 OR pe.status = 5) AND pe.planID = {$post['planID']} group by t.machineId;";
        $count = $this->db->fetchOne($count_sql);
        $res = $this->db->fetchAll($sql, 1);
        return array('data' => $res, 'errorCode' => 100, 'success' => 1, 'totalRows' => $count['nrows']);
    }
    
    public function save($post)
    {
        if('add' === $post['act']) {
            $res = $this->insertByPost($post);
            if($res['success']) {
                $result = array('status' => array('success' => 1,'message' => 'Add Success!'.$res['message']));
                $this->_afterCreateDb($this->getData($post));
            } else {
                $result = array('status' => array('success' => 0,'message' => $res['message'],'errorCode' => 0));
            }
        } elseif('upd' === $post['act']) {
            if($this->updateByPost($this->getData($post))) {
                $result = array('status' => array('success' => 1,'message' => 'Update Success!'));
                $this->_afterUpdateDb($this->getData($post));
            } else {
                $result = array('status' => array('success' => 0,'message' => 'Update Failed!','errorCode' => 0));
            }
        } else {
            $result = array('status' => array('success' => 0,'message' => 'Error!','errorCode' => 1));
        }
        return $result;
    }
    
    public function addDevice($post){
    	$sql1 = "SELECT otaid,appid,t_app_android.version as otaversion FROM t_upd_plan left join t_app_android on t_upd_plan.otaid=t_app_android.id where t_upd_plan.id={$post['planid']}";
    	$planRes = $this->db->fetchOne($sql1, 1);
      if($planRes['otaid'] == '' && $planRes['appid'] == ''){
            $sql2 = "SELECT t_bd_terminal.machineId FROM t_upd_planentry LEFT JOIN t_bd_terminal ON t_bd_terminal.id = t_upd_planentry.terminalID where t_upd_planentry.status < 2 and t_upd_planentry.terminalID IN({$post['device_id']}) ;";
            $res = $this->db->fetchOne($sql2, 1);
            if(!empty($res))
                return array('success' => 0, 'message' => 'The following terminal is unable to create a delivery task that may exist in other plans! SN ='.$res['machineid']);
        }
        //比较OTA版本
        if($planRes['otaid'] != '' && $planRes['otaid'] !=0) {
            $sql5 = "SELECT t_bd_terminal.machineId FROM t_upd_planentry LEFT JOIN t_bd_terminal ON 
                t_bd_terminal.id = t_upd_planentry.terminalID LEFT JOIN t_upd_plan ON t_upd_planentry.planID = t_upd_plan.id 
                WHERE t_upd_planentry.status < 2 AND t_upd_plan.otaid != 0 AND t_upd_planentry.terminalID IN({$post['device_id']}) ;";
            $res5 = $this->db->fetchOne($sql5, 1);
            if(!empty($res5))
                return array('success' => 0, 'message' => 'The following terminal is unable to create a delivery task that may exist in other plans! SN  ='.$res5['machineid']);
            $sql3 = "SELECT machineid,otaversion FROM t_bd_terminal where id IN({$post['device_id']}) ;";
            $res3 = $this->db->fetchAll($sql3, 1);
            foreach ($res3 as $val) {
                if(strcasecmp($val['otaversion'], $planRes['otaversion']) > 0){
                    return array('success' => 0, 'message' => 'The following terminal is unable to create a delivery task that(The current version of OTA is higher than the version to be upgraded!)SN ='.$val['machineid']);
                }
            }
            //判断支持的版本
            $sql4 = "select supportversion from t_app_android where id = {$planRes['otaid']}";
            $res4 = $this->db->fetchOne($sql4, 1);
            $support = $res4['supportversion'];
            if($support != '0'){
                foreach ($res3 as $val) {
                    if(strcasecmp($val['otaversion'], $support) != 0){
                        return array('success' => 0, 'message' => 'The following terminal is unable to create a delivery task that(The current version of OTA does not match the version supported by the upgrade package!)SN ='.$val['machineid']);
                    }
                }
            }
        }
        //app
        if($planRes['appid'] != '' && $planRes['appid'] !=0) {
            $sql6 = "SELECT t_bd_terminal.machineId FROM t_upd_planentry LEFT JOIN t_bd_terminal ON
            t_bd_terminal.id = t_upd_planentry.terminalID LEFT JOIN t_upd_plan ON t_upd_planentry.planID = t_upd_plan.id
            WHERE t_upd_planentry.status < 2 AND t_upd_plan.appid != '' AND t_upd_planentry.terminalID IN({$post['device_id']}) ;";
            $res6 = $this->db->fetchOne($sql6, 1);
            if(!empty($res6))
                return array('success' => 0, 'message' => 'The following terminal is unable to create a delivery task that may exist in other plans! SN ='.$res6['machineid']);
            $comres = $this->compareApp($post['device_id'], $planRes['appid']);
            if(!$comres['success']){
                return array('success' => 0, 'message' => $comres['message']);
            }
        }
        
        $sameVersions='';
        if($planRes['otaid'] != '' && $planRes['otaid'] !=0) {
        	$sameVersions = $this->checkPackageSameVersion($post['device_id'],$planRes['otaversion'],"OTA");
        }elseif($planRes['appid'] != '' && $planRes['appid'] !=0) {
        	$apkinfossql = "SELECT name,versionname,package,versioncode from t_app_apkfile where id in (".$planRes['appid'].")";
        	$apkinfosres = $this->db->fetchAll($apkinfossql);
        	$sameVersions = $this->checkPackageSameVersion($post['device_id'],$apkinfosres,"APK");
        }
        if($sameVersions  == 'All in current version!'){
        	return array('success' => 0, 'message' => $sameVersions);
        }
        
        $sql = "update t_upd_plan set qty=(select temp.qty from (select qty from t_upd_plan where id={$post['planid']}) temp)+1 where id={$post['planid']};";
        $this->db->begin();
        if(!$this->db->execute($sql)) {
        	$this->db->rollback();
        	return array('success' => 0, 'message' => 'Add to t_upd_plan error!');
        }
        $getID = $post['planid'];
        $sql1 = 'insert into t_upd_planentry(planId,terminalID) values';
        $array = explode(',',$post['device_id']);
        foreach ($array as $val) {
        	$sql1 .= "({$getID},'{$val}'),";
        }
        $sql1 = rtrim($sql1, ",").';';
        if(!$this->db->execute($sql1)) {
        	$this->db->rollback();
        	return array('success' => 0, 'message' => 'Add to t_upd_planentry error!');
        }
        $this->db->commit();
        $this->_afterUpdateDb($post);
        return array('success' => 1);
    }
    
    public function insertByPost($post)
    {
        $qty = count(explode(',',$post['terminalID']));
        $zero = date("y-m-d H:i:s");
        /**
        if($post['appTempID'] == '')
            $post['appTempID'] = 0;
        if($post['libID'] == '')
            $post['libID'] = 0;
        if($post['middleID'] == '')
            $post['middleID'] = 0;
        if($post['sdkID'] == '')
            $post['sdkID'] = 0;
        **/
        if(strtotime($post['beginTime']) > strtotime($post['endTime'])){
            return array('success' => 0, 'message' => 'Start time must not be greater than the end time');
        }
        if($post['otaid'] == '' && $post['appid'] == ''){
            $sql2 = "SELECT t_bd_terminal.machineId FROM t_upd_planentry LEFT JOIN t_bd_terminal ON t_bd_terminal.id = t_upd_planentry.terminalID where t_upd_planentry.status < 2 and t_upd_planentry.terminalID IN({$post['terminalID']}) ;";
            $res = $this->db->fetchOne($sql2, 1);
            if(!empty($res))
                return array('success' => 0, 'message' => 'The following terminal is unable to create a delivery task that may exist in other plans! SN ='.$res['machineid']);
        }
        //比较OTA版本
        if($post['otaid'] != '') {
            $sql5 = "SELECT t_bd_terminal.machineId FROM t_upd_planentry LEFT JOIN t_bd_terminal ON 
                t_bd_terminal.id = t_upd_planentry.terminalID LEFT JOIN t_upd_plan ON t_upd_planentry.planID = t_upd_plan.id 
                WHERE t_upd_planentry.status < 2 AND t_upd_plan.otaid != 0 AND t_upd_planentry.terminalID IN({$post['terminalID']}) ;";
            $res5 = $this->db->fetchOne($sql5, 1);
            if(!empty($res5))
                return array('success' => 0, 'message' => 'The following terminal is unable to create a delivery task that may exist in other plans! SN  ='.$res5['machineid']);
            $sql3 = "SELECT machineid,otaversion FROM t_bd_terminal where id IN({$post['terminalID']}) ;";
            $res3 = $this->db->fetchAll($sql3, 1);
            foreach ($res3 as $val) {
                if(strcasecmp($val['otaversion'], $post['otaversion']) > 0){
                    return array('success' => 0, 'message' => 'The following terminal is unable to create a delivery task that(The current version of OTA is higher than the version to be upgraded!)SN ='.$val['machineid']);
                }
            }
            //判断支持的版本
            $sql4 = "select supportversion from t_app_android where id = {$post['otaid']}";
            $res4 = $this->db->fetchOne($sql4, 1);
            $support = $res4['supportversion'];
            if($support != '0'){
                foreach ($res3 as $val) {
                    if(strcasecmp($val['otaversion'], $support) != 0){
                        return array('success' => 0, 'message' => 'The following terminal is unable to create a delivery task that(The current version of OTA does not match the version supported by the upgrade package!)SN ='.$val['machineid']);
                    }
                }
            }
        }
        //app
        if($post['appid'] != '') {
            $sql6 = "SELECT t_bd_terminal.machineId FROM t_upd_planentry LEFT JOIN t_bd_terminal ON
            t_bd_terminal.id = t_upd_planentry.terminalID LEFT JOIN t_upd_plan ON t_upd_planentry.planID = t_upd_plan.id
            WHERE t_upd_planentry.status < 2 AND t_upd_plan.appid != '' AND t_upd_planentry.terminalID IN({$post['terminalID']}) ;";
            $res6 = $this->db->fetchOne($sql6, 1);
            if(!empty($res6))
                return array('success' => 0, 'message' => 'The following terminal is unable to create a delivery task that may exist in other plans! SN ='.$res6['machineid']);
            $comres = $this->compareApp($post['terminalID'], $post['appid']);
            if(!$comres['success']){
                return array('success' => 0, 'message' => $comres['message']);
            }
        }

        $sameVersions='';
        if($post['otaid'] != '') {
        	$sameVersions = $this->checkPackageSameVersion($post['terminalID'],$post['otaversion'],"OTA");
        }elseif($post['appid'] != '') {
        	$apkinfossql = "SELECT name,versionname,package,versioncode from t_app_apkfile where id in (".$post['appid'].")";
        	$apkinfosres = $this->db->fetchAll($apkinfossql);
        	$sameVersions = $this->checkPackageSameVersion($post['terminalID'],$apkinfosres,"APK");
        }
        if($sameVersions  == 'All in current version!'){
        	return array('success' => 0, 'message' => $sameVersions);
        }
        
        
        $sql = "insert into t_upd_plan(`name`,qty,appTempID,libID,middleID,sdkID,beginTime,endTime,description,creator,createTime,useridalias,otaid,appid) values('{$post['name']}','{$qty}','{$post['appTempID']}','{$post['libID']}','{$post['middleID']}','{$post['sdkID']}','{$post['beginTime']}','{$post['endTime']}','{$post['description']}','{$_SESSION['rbac']['id']}','{$zero}','{$_SESSION['rbac']['idAlias']}','{$post['otaid']}','{$post['appid']}');";
        $this->db->begin();
        if(!$this->db->execute($sql)) {
            $this->db->rollback();
            return array('success' => 0, 'message' => 'Add to t_upd_plan error!');
        }
        $getID = $this->db->lastInsertId();        
        $sql1 = 'insert into t_upd_planentry(planId,terminalID) values';
        $array = explode(',',$post['terminalID']);
        foreach ($array as $val) {
            $sql1 .= "({$getID},'{$val}'),";
        }
        $sql1 = rtrim($sql1, ",").';';
        if(!$this->db->execute($sql1)) {
            $this->db->rollback();
            return array('success' => 0, 'message' => 'Add to t_upd_planentry error!');
        }
        $this->db->commit();
        return array('success' => 1,'message' => $sameVersions);
    }
    
    public function checkPackageSameVersion($terminalIDs,$packageinfos,$packageType)
    {
    	$sameVersions='';
    	$allInCurrentVersion = true;
    	if($packageType == "OTA"){
    		$terminalotasql = "select machineId,otaversion from t_bd_terminal where id in(".$terminalIDs.")";
    		$terminalotares = $this->db->fetchAll($terminalotasql);

    		foreach ($terminalotares as $termi){
    			if($packageinfos == $termi['otaversion']){
    				$sameVersions = '<br>'.$sameVersions.$termi['machineId'].'</br>';
    			}else{
    					$allInCurrentVersion = false;
    			}
    		}
    		if($sameVersions != ''){
    			$sameVersions = $sameVersions.'<br> in current version!</br>';
    		}
    	}
    	if($packageType == "APK"){
    		$terminalapksql = "select machineId,apkinfo from t_bd_terminal where id in(".$terminalIDs.")";
    		$terminalapkres = $this->db->fetchAll($terminalapksql);
    		foreach ($terminalapkres as $termi){
    			foreach ($packageinfos as $apkinfo){
    				$apkv = '"package":"'.$apkinfo['package'].'","versioncode":"'.$apkinfo['versioncode'].'","versionname":"'.$apkinfo['versionname'].'"';
    				if(strpos($termi['apkinfo'],$apkv) !== false){
    					$sameVersions = '<br>'.$sameVersions.$termi['machineid'].'/App:'.$apkinfo['name'].'</br>';
    				}else{
    					$allInCurrentVersion = false;
    				}
    			}
    		}
    		if($sameVersions != ''){
    			$sameVersions = $sameVersions.'<br> in current version!</br>';
    		}
    	}
    	if($allInCurrentVersion){
    		return 'All in current version!';
    	}
    	return $sameVersions;
    }
    
    public function cancel($post)
    {
        $sql = "update t_upd_planentry set status = 6 where id in({$post['planIds']});";
        if($this->db->execute($sql)){
            $this->_afterUpdateDb($post['planIds']);
            return array('success' => 1);
        } else{
            return array('success' => 0, 'errorCode' => 0, 'error' => '0');
        }
    }
    
    public function remove($post)
    {
        // 检查升级计划是否有设备已开始升级准备
        $check_sql = "SELECT COUNT(*) AS count FROM `t_upd_planentry` WHERE planID = {$post['param']['id']} AND `status` = 1";
        $check_res = $this->db->fetchOne($check_sql, 1);
        $plan = $this->findByPk($post['param']['id'])['result'];
        $c_useridAlias = $_SESSION['rbac']['idAlias'];
        if ($c_useridAlias != '1') {
            if ($plan['endtime'] > date('Y-m-d H:i:s') && $check_res['count']) {
                $ret = array('statusCode'=>300,'message'=>"The current upgrade plan is not finished and the terminal is in the upgrade, and the deletion is forbidden (please contact the administrator to delete).");
                echo json_encode($ret);
                exit();
            }
        }
        $sql = "DELETE FROM t_upd_plan WHERE id = {$post['param']['id']} ";
        $sql .= $this->param();
        $sql .= ";DELETE FROM t_upd_planentry WHERE planID = {$post['param']['id']};";
        //echo $sql;die;
        $this->db->begin();
        if(!$this->db->execute($sql)) {
            $this->db->rollback();
            return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => '0'));
        }
        $sql1 = "DELETE FROM t_upd_planentry WHERE planId = {$post['param']['id']} ";
        if(!$this->db->execute($sql1)) {
            $this->db->rollback();
            return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => '0'));
        }
        $this->_afterRemoveDbByPkv($post['param']['id']);
        $this->db->commit();
        return array('status' => array('success' => 1, 'errorCode' => 0, 'message' => '0'));
    }
    
    public function getTerminalInfos($post)
    {
        $array = explode(',',$post['machineId']);
        $data = '';
        foreach ($array as $val) {
            $data .= ",'".$val."'";
        }
        $data = substr($data,1);
        if (isset($post['type'])) {
            if ('tpos' == $post['type']) {
                $sql = "SELECT t_bd_terminal.id as terminalID,t_bd_terminal.machineId FROM t_bd_terminal LEFT JOIN t_bd_model ON t_bd_model.id = t_bd_terminal.modelId WHERE machineId IN({$data}) AND t_bd_model.modeltype=0 AND t_bd_terminal.useridalias={$_SESSION['rbac']['idAlias']};";
            } elseif ('spos' == $post['type']) {
                $sql = "SELECT t_bd_terminal.id as terminalID,t_bd_terminal.machineId FROM t_bd_terminal LEFT JOIN t_bd_model ON t_bd_model.id = t_bd_terminal.modelId WHERE machineId IN({$data}) AND t_bd_model.modeltype=1 AND t_bd_terminal.useridalias={$_SESSION['rbac']['idAlias']};";
            }
        } else {
            $sql = "SELECT id as terminalID,machineId FROM t_bd_terminal WHERE machineId IN({$data}) AND t_bd_terminal.useridalias={$_SESSION['rbac']['idAlias']};";
        }
//        $this->param(true);
        $machinIds = $this->db->fetchAll($sql, 1);
        if(!empty($machinIds)) {
            $res['data'] = $machinIds;
            return $res;
        }
        return '';
    }
    
    //app信息的比较
    private function compareApp($terminals,$appids){
        $sql = "SELECT machineid,apkinfo FROM t_bd_terminal WHERE id IN({$terminals}) ;";
        $res = $this->db->fetchAll($sql, 1);
        $sql2 = "SELECT package, versionname FROM t_app_apkfile WHERE id IN({$appids});";
        $res2 = $this->db->fetchAll($sql2, 1);
        foreach ($res as $val) {
            $apkinfo = json_decode($val['apkinfo'],true);
            foreach ($apkinfo as $apk) {
                foreach ($res2 as $val2) {
                    if(strcasecmp($apk['package'], $val2['package']) == 0){
                        if(strcasecmp($apk['versionname'], $val2['versionname']) >= 0){
                            return array('success' => false, 
                                'message' => 'The following terminal is unable to create a delivery task：SN ='.$val['machineid']).'App name'.$apk['versionname'].'version is higher than the upgrade files version';
                        }
                    }
                }
            }
        }
        return array('success' => true);
    }
}