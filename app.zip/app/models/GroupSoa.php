<?php

/**
 * GroupSoa
 *  
 * @author lujun
 */

class GroupSoa extends ModelSoa2
{
    //var $lookupfield = array('machinesid','machineno','model_id','status');
    public $primaryKey = 'id';
    //var $order = array('field'=>'machineId','direction'=>'desc');
    /**
    public $method = array(
    	'index'	=> 'model/getAll',
        'add'   => 'model/add',
    	'get'	=> 'model/getById',
    	'delete'=> 'model/delete'
    );
    **/
    public $method = array(
        'index'	=> 'group/getAll',
        'add'   => 'group/add',
        'get'	=> 'group/detail',
        'delete'=> 'group/delete',
        'update'    =>	'group/modify',
        'last'  => 'group/isLast',
        'getGroupByUser'=> 'group/getGroupByUser',
    );
    
    function findByPost2($post)
    {
    	$Num = $post['pageNum']!='' ? $post['pageNum'] : 1;
        $numPer = !empty($post['numPerPage']) ? $post['numPerPage'] : 20;
        $post['pageNum']=intval($Num);
        $post['pageSize']=intval($numPer);
        return $this->execute($post,'index2');
    }
}