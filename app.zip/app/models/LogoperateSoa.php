<?php

/**
 * Logoperate
 *  
 * @author zhaimin
 * @version 1.0
 */

class LogoperateSoa extends ModelSoa2
{
    public $primaryKey = 'id';
    public $order = array('field'=>'actionTime','direction'=>'desc');
    /**
    public $method = array(
    	'index'	=> 'logmanage/getSysOperateLog',
        'user'  => '/user/all',
    	'op'	=> '/logmanage/allOpItems'
    );
    **/
    public $method = array(
        'index'	=> 'logoperate/search',
        'user'  => '/user/all',
        'op'	=> '/logmanage/allOpItems'
    );
}

