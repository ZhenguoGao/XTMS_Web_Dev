<?php
/**
 * 角色接口
 *  
 * @author lujun
 */

class RoleNew extends ModelBase1
{
    var $tableName = 't_auth_role';
    var $pareTable = array(
       	'getColumns'=>array('id','name','locked','remark','useridalias'),
        'lookupfield'=>array('name')
    );
    
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
    );
    
    var $primaryKey = 'id';
    var $uniqueFields = array('name');
    var $order = array('field'=>'id','direction'=>'desc');
    
    public function findByPk($pk)
    {
        $sql = "select * from {$this->tableName} where id = {$pk};";
        $res = $this->db->fetchOne($sql, 1);

        $sql1 = "SELECT t_auth_menu.id FROM t_auth_menu LEFT JOIN t_auth_menu_rel ON t_auth_menu_rel.menuid = t_auth_menu.id 
            LEFT JOIN t_auth_role ON t_auth_role.id = t_auth_menu_rel.roleid WHERE t_auth_role.id = {$pk} ";

//        if ($res['useridalias'] == '1') {
//            $sql1 = "SELECT t_auth_menu.id FROM t_auth_menu";
//        } else {
//            $sql1 = "SELECT t_auth_menu.id FROM t_auth_menu LEFT JOIN t_auth_menu_rel ON t_auth_menu_rel.menuid = t_auth_menu.id
//            LEFT JOIN t_auth_role ON t_auth_role.id = t_auth_menu_rel.roleid WHERE t_auth_role.id = {$pk} ";
//        }

        $res1 = $this->db->fetchAll($sql1, 1);

        foreach ($res1 as $val){
            $res2[] = $val['id'];
        }
        $res2 = array('menuList' => $res2);
        //print_r($res1);die;
        $res = array_merge ($res2, $res);
        return array('result' => $res);
    }
    
    public function save($post){
        if(!$this->validation($post)) {
            return array('status' => array('success' => 0,'message' => $this->uniqueErrorInf,'errorCode' => 1));
        }
        if($post['act'] == 'add'){
            if($this->insertByPost($post)) {
                $result = array('status' => array('success' => 1,'message' => 'Add Success!'));
                $this->_afterCreateDb($this->getData($post));
            } else {
                $result = array('status' => array('success' => 0,'message' => 'Add Failed!','errorCode' => 0));
            }
        } elseif ($post['act'] == 'upd') {
            if($this->updateByPost($post)) {
                $result = array('status' => array('success' => 1,'message' => 'Update Success!'));
                $this->_afterUpdateDb($this->getData($post));
            } else {
                $result = array('status' => array('success' => 0,'message' => 'Update Failed!','errorCode' => 0));
            }
        } else{
            $result = array('status' => array('success' => 0,'message' => 'Error!','errorCode' => 1));
        }
        return $result;
    }
    
    public function insertByPost($post){
        if($post['locked'] == 'true') {
            $post['locked'] = 1;
        } else {
            $post['locked'] = 0;
        }
        $sql = "insert into {$this->tableName}(name, locked, remark, useridalias) values('{$post['name']}',
            {$post['locked']},'{$post['remark']}','{$_SESSION['rbac']['idAlias']}');";
        $this->db->execute($sql);
        $getID = $this->db->lastInsertId();
        $rel = $post['menuList'];
        $sql_insert = 'insert into t_auth_menu_rel(roleid, menuid) values';
        foreach ($rel as $val){
            $sql_insert .= '('.$getID.','.$val.'),';
        }
        $sql_insert = rtrim($sql_insert, ",").';';
        return $this->db->execute($sql_insert);
    }
    
    public function updateByPost($post){
        $rel = $post['menuList'];
        $sql_insert = 'insert into t_auth_menu_rel(roleid, menuid) values';
        foreach ($rel as $val){
            $sql_insert .= '('.$post['id'].','.$val.'),';
        }
        $sql_insert = rtrim($sql_insert, ",");
        $sql = "delete from t_auth_menu_rel where roleid = {$post['id']};".$sql_insert.';';
        $sql_update = "update {$this->tableName} set `name` = '{$post['name']}', locked = {$post['locked']}, remark = '{$post['remark']}' 
            where id = {$post['id']} and (useridalias like '{$_SESSION['rbac']['idAlias']}.%' or useridalias = '{$_SESSION['rbac']['idAlias']}');";
        $sql .= $sql_update;
        //echo $sql;die;
        return $this->db->execute($sql);
    }
    
    public function remove($ids)
    {
        $flag_sql = "select * from t_auth_user where roleId IN ({$ids});";
        $flag = $this->db->fetchAll($flag_sql, 1);
        if ($flag) {
            echo json_encode(
                array(
                    'statusCode' => 300,
                    'message' => 'The role has been associated with the user and cannot be deleted'
                )
            );
            exit();
        }
        $sql = "delete from t_auth_menu_rel where roleid IN({$ids});";
        $sql .= "DELETE FROM {$this->tableName} WHERE id IN({$ids}) and (useridalias 
            like '{$_SESSION['rbac']['idAlias']}.%' or useridalias = '{$_SESSION['rbac']['idAlias']}');";
        //echo $sql;die;
        //$this->_logger->log($sql, \Phalcon\Logger::INFO);
        if($this->db->execute($sql)){
            $this->_afterRemoveDbByPkv($ids);
            return array('status' => array('success' => 1));
        } else{
            return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => '0'));
        }
    }

    public function search($post, $get)
    {
        $this->_parseSql();
        $fields = ltrim($this->_selectField,',');
        $sql = "SELECT {$fields} FROM {$this->qtable($this->getSource())} {$this->_externSql} WHERE 1=1 ";
        $count_sql = "SELECT COUNT(1) AS nrows FROM {$this->qtable($this->getSource())} {$this->_externSql} WHERE 1=1 ";
        if (is_array($get) && !empty($get)) {
            foreach ($get as $k => $v) {
                if (in_array($k, $this->pareTable['getColumns'])) {
                    $this->_bindParams[$k] = $v;
                    $sql .= " AND {$this->qfield($k, $this->qtable($this->getSource()))} = {$this->_bindParams[$k]}";
                    $count_sql .= " AND {$this->qfield($k, $this->qtable($this->getSource()))} = {$this->_bindParams[$k]}";
                }
            }
        }
        $sql .= $this->_getSearchSql($post['param']);
        $sql .= " and {$this->tableName}.userIdAlias='{$_SESSION['rbac']['idAlias']}' ";
        $count_sql .= $this->_getSearchSql($post['param']);
        $count_sql .= " and {$this->tableName}.userIdAlias='{$_SESSION['rbac']['idAlias']}' ";
//        $sql .= $this->param(true);
//        $count_sql .= $this->param(true);
        $count = $this->db->fetchOne($count_sql);
        if(!empty($post)){
            $sql .= " ORDER BY {$this->qfield($post['order']['field'])} {$post['order']['direction']}";
            $offset = (intval($post['page']['pageNum'])-1)*intval($post['page']['pageSize']);
            $sql .= " limit {$offset},{$post['page']['pageSize']}";
        }
        $rowset = $this->db->fetchAll($sql, 1);
        return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
    }
}