<?php

/**
 * Logoperate
 *  
 * @author lujun
 * @version 1.0
 */

class LogoperateNew extends ModelBase1
{
    var $tableName = 't_log_sysoperate';
    var $pareTable = array(
        'getColumns'=>array('id','ip','action','actionUri','actionTime','operator','opCode','userid','useridalias'),
        'lookupfield'=>array('action')
    );
    
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
    );
    var $primaryKey = 'id';
    
    public function findByPost($post, $get)
    {
        //print_r($post);die;
        $fields = "t_log_sysoperate.id,t_log_sysoperate.ip,t_log_sysoperate.action,t_log_sysoperate.actionUri,t_log_sysoperate.actionTime,
            t_log_sysoperate.operator,t_log_sysoperate.opCode,t_log_sysoperate.userid,t_auth_user.name as username,t_log_sysoperate.useridalias";
        $source = "t_log_sysoperate INNER JOIN t_auth_user ON t_log_sysoperate.useridalias = t_auth_user.useridalias";
        $sql = "SELECT {$fields} FROM {$source} WHERE 1=1 ";
        $count_sql = "SELECT COUNT(1) AS nrows FROM {$source} WHERE 1=1 ";
        //print_r();die;
        $sql .= $this->param(true);
        $count_sql .= $this->param(true);
        $condition = '';
        if(!empty($post['param'])){
            //print_r($post['param']['opCode']);die;
            if($post['param']['opCode'] != '0' && $post['param']['opCode'] != '3')
                $condition .= " and t_log_sysoperate.opcode = '{$post['param']['opCode']}' ";
            if($post['param']['opCode'] == '3')
                $condition .= " and t_log_sysoperate.opcode = '0' ";
            if($post['param']['actionTimeStart'] != '')
                $condition .= " and t_log_sysoperate.actionTime >= '{$post['param']['actionTimeStart']} 00:00:00' ";
            if($post['param']['actionTimeEnd'] != '')
                $condition .= " and t_log_sysoperate.actionTime <= '{$post['param']['actionTimeEnd']} 23:59:59' ";
        }
        $sql .= $condition;
        $count_sql .= $condition;
        //print_r($count_sql);die;
        //$this->_logger->log($count_sql, \Phalcon\Logger::INFO);
        $count = $this->db->fetchOne($count_sql);
        if(!empty($post)){
            $sql .= " ORDER BY {$this->qfield($post['order']['field'])} {$post['order']['direction']}";
            //echo $sql;die;
            $offset = (intval($post['page']['pageNum'])-1)*intval($post['page']['pageSize']);
            $sql .= " limit {$offset},{$post['page']['pageSize']}";
        }
        //print_r($sql);die;
        //$this->_logger->log($sql, \Phalcon\Logger::INFO);
        $rowset = $this->db->fetchAll($sql, 1);
        //print_r($rowset);die;
        return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
    }
}

