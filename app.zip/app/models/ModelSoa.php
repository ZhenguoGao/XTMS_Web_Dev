<?php

/** 
 * @author zhaimin
 * 
 * 
 */
class ModelSoa {
	
    public $method =array();
    public $primaryKey = '';
    public $lookupfield = array();
    public $replacevalue = array();
    public $config = '';
    public $server = '';
    public $order = array('field'=>'', 'direction'=>'');

    function __construct(){
        $this->config = include(__DIR__."/../config/config.php");
    }

    function getConfig()
    {
        return $this->config;
    }

    public function getLookupField()
    {
        return $this->lookupfield;
    }

    public function getReplaceValue()
    {
        return $this->replacevalue;
    }
    
    public function getPK()
    {
    	return $this->primaryKey;
    }

    /**
     * 根据POST过来的数据提取查询条件查询记录
     * @param array $post
     * @return array
     */
    function findByPost($post)
    {
        $Num = $post['pageNum']!='' ? $post['pageNum'] : 1;
        $numPer = !empty($post['numPerPage']) ? $post['numPerPage'] : 20;
        $post['pageNum']=intval($Num);
        $post['pageSize']=intval($numPer);
        return $this->execute($post,'index');
    }

    function postSave($post)
    {
        $method = '';
        if($post['act']=='add')
            $method = 'add';
        elseif($post['act']=='upd')
            $method = 'update';
        else
            die(json_encode(array('statusCode'=>300,'message'=>'Error!')));
        unset($post['act']);
        return $this->execute($post,$method);
    }

    function findByPk($pk)
    {
        return $this->execute(array($this->primaryKey=>$pk),'get');
    }

    function remove($pk)
    {
        return $this->execute(array($this->primaryKey=>$pk),'delete');
    }

    public function execute($post, $method)
    {
        $result = '';
        //print_r($this->method[$method]);die;
        //$str = 'clientIp='.$_SERVER["REMOTE_ADDR"].'&jsonStr='.urlencode(json_encode($this->formatPost($post)));
        //$result = $this->request_by_vpost($str,$this->method[$method]);
        $result = $this->request_by_vpost($post,$this->method[$method]);
        if(false === $result['status']){
            exit(json_encode($result['data'], true));
        }
        return $result['data'];
    }

    function formatPost($post)
    {
        if(!empty($_SESSION['rbac'])) {
            $post['userId'] = isset($_SESSION['rbac']['id']) ? $_SESSION['rbac']['id'] : '';
            $post['userNo'] = isset($_SESSION['rbac']['username']) ? $_SESSION['rbac']['username'] : '';
            $post['passwd'] = isset($_SESSION['rbac']['password']) ? $_SESSION['rbac']['password'] : '';
            $post['userName'] = isset($_SESSION['rbac']['name']) ? $_SESSION['rbac']['name'] : '';
        }
        $post['ip'] = $_SERVER["REMOTE_ADDR"];
        return $post;
    }
    
    public function request_by_vpost($post,$method)
    {
        $server = $this->server? $this->server:'soa';
        $url = "{$this->config->$server}{$method}";
        $method = explode('/', $method);

        $model = ucfirst($method[0]).'New';
        $model = new $model;
        //print_r($post);die;
        //print_r($method[1].'('.$post.')');die;
        $res = json_encode($model->$method[1]($post));
        $data = array('status'=>true, 'data'=>json_decode(strtr($res,array("\r"=>' ',"\t"=>' ')), true));
        //print_r($data);die;
        return $data;
    }
    
    /**
    public function request_by_vpost($post_string,$method)
    {
        $server = $this->server? $this->server:'soa';
        $url = "{$this->config->$server}{$method}";
        $curl = curl_init();  // 启动一个CURL会话
        curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
        // curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1); // 从证书中检查SSL加密算法是否存在，已废弃
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2); // 从证书中检查SSL加密算法是否存在
        curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转
        curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer
        curl_setopt($curl, CURLOPT_POST, 1); // 发送一个常规的Post请求
        curl_setopt($curl, CURLOPT_POSTFIELDS, $post_string); // Post提交的数据包
        curl_setopt($curl, CURLOPT_TIMEOUT, 30); // 设置超时限制防止死循环
        curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回
        $tmpInfo = curl_exec($curl); // 执行操作
        if (curl_errno($curl)) {
           $data = array('status'=>false, 'data'=>array("statusCode"=>300,"message"=>'调用错误：'.curl_error($curl), "error"=>curl_error($curl)));
        }else{
            //过滤非法字符
            $data = array('status'=>true, 'data'=>json_decode(strtr($tmpInfo,array("\r"=>' ',"\t"=>' ')), true));
        }
        curl_close($curl); // 关闭CURL会话
        return $data; // 返回数据
    }
    **/

    public function postFile($post, $method)
    {
        $post['jsonStr'] = json_encode($this->formatPost($post));
        $request = new \Phalcon\Http\Request();
        $post['clientIp'] = $request->getClientAddress();
        if(version_compare(PHP_VERSION, '5.5.0', '>=')){
            $post['file'] = new CURLFile($post['filename']);
        }else{
            $post['file'] = '@'.$post['filename'];
        }
        unset($post['filename']);
        $res = $this->request_by_vpost($post, $this->method[$method]);
        if(false === $res['status']){
            exit(json_encode($res['data'], true));
        }
        return $res['data'];
    }

    public function stringToHex($asc) 
    {
        $r = '';
        $hexes = array ("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F");
        for ($i=0; $i<strlen($asc); $i++) {$r .= ($hexes [(ord($asc{$i}) >> 4)] . $hexes [(ord($asc{$i}) & 0xf)]);}
        return $r;
    }

    function hexToString($h) 
    {
        $r = "";
        for ($i= (substr($h, 0, 2)=="0x")?2:0; $i<strlen($h); $i+=2) {$r .= chr (base_convert (substr ($h, $i, 2), 16, 10));}
        return $r;
    }
}