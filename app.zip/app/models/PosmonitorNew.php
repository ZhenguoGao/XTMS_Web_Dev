<?php

/**
 * Spos
 *  
 * @author lujun
 */

class PosmonitorNew extends ModelBase1
{
    var $tableName = 't_log_visitdetails';
    var $pareTable = array(
        'getColumns'=>array('id','machineId','visit','sysVersion','visitIp','oneVisitTime','lastVisitTime','longitude','latitude','citycode', 'city','address'),
        'lookupfield'=>array('machineId')
    );

    var $primaryKey = 'id';
    
    public function findByPost($post, $get)
    {
        $useridAlias = $_SESSION['rbac']['idAlias'];
        $sql = "select * from t_log_visitdetails where 1=1 ";
        $count_sql = "select COUNT(1) AS nrows from t_log_visitdetails where 1=1  ";
        $condition = '';
        if(isset($post['param'])) {
            if($post['param']['machineid'] != '')
                $condition .= " and machineid like '%{$post['param']['machineid']}%' ";
        }
        $sql .= $condition;
        $count_sql .= $condition;
        $count = $this->db->fetchOne($count_sql);
        if(!empty($post)){
            $sql .= " ORDER BY {$this->qfield($post['order']['field'])} {$post['order']['direction']}";
            //echo $sql;die;
            $offset = (intval($post['page']['pageNum'])-1)*intval($post['page']['pageSize']);
            $sql .= " limit {$offset},{$post['page']['pageSize']}";
        }
        //print_r($sql);die;
        //$this->_logger->log($sql, \Phalcon\Logger::INFO);
        $rowset = $this->db->fetchAll($sql, 1);
        //print_r($rowset);die;
        return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
    }
}