<?php

/**
 * 终端信息上送
 *  
 * @author lujun
 */

class TermuploadNew extends ModelBase1
{
    var $tableName = 't_file_upload';
    var $pareTable = array(
        'getColumns'=>array('id AS fileUploadId','uploadPlanId','machineNo AS machineId','fileName','fileSize','compress','content',
            'createTime'),
        'lookupfield'=>array('machineNo'),
    );
    
    var $foreignTable = array(
        'uploadPlanId' => array(
            'tableName' => 't_file_upload_plan',
            'mappingKey' => 'id',
            'displayKey' => array('id as aaa'),
        ),
    );
    
    var $primaryKey = 'id';
    
    public function findByPost($post, $get)
    {
        //print_r($post);die;
        $sql = "SELECT  t_file_upload_plan.beginTime,t_file_upload_plan.endTime,t_file_upload.createTime,t_file_upload.machineNo AS machineId,
            t_file_upload.id AS fileUploadId,t_bd_terminal.terminalNo,t_bd_terminal.merchantNo FROM t_file_upload 
            LEFT JOIN t_file_upload_plan ON t_file_upload.uploadPlanId = t_file_upload_plan.id 
            LEFT JOIN t_file_upload_planentry ON t_file_upload_planentry.uploadPlanId = t_file_upload_plan.id 
            LEFT JOIN t_bd_terminal ON t_bd_terminal.id = t_file_upload_planentry.terminalId 
            WHERE t_file_upload.machineNo = t_bd_terminal.machineId ";
        $sql .= " and (t_bd_terminal.useridalias like '{$_SESSION['rbac']['idAlias']}.%' or 
            t_bd_terminal.useridalias = '{$_SESSION['rbac']['idAlias']}') ";
        if(!empty($post['param'])){
            if($post['param']['machineId'] != '')
                $sql .= " and t_file_upload.machineNo like '%{$post['param']['machineId']}%' ";
            if($post['param']['beginTime'] != '')
                $sql .= " and t_file_upload_plan.beginTime >= '{$post['param']['beginTime']}' ";
            if($post['param']['endTime'] != '')
                $sql .= " and t_file_upload_plan.endTime <= '{$post['param']['endTime']}' ";
        }
        $count_sql = "SELECT COUNT(1) AS nrows FROM ({$sql}) tmp_count;";
        
        $count = $this->db->fetchOne($count_sql);
        if(!empty($post)){
            $sql .= " ORDER BY {$this->qfield($post['order']['field'])} {$post['order']['direction']}";
            $offset = (intval($post['page']['pageNum'])-1)*intval($post['page']['pageSize']);
            $sql .= " limit {$offset},{$post['page']['pageSize']}";
        }
        $rowset = $this->db->fetchAll($sql, 1);
        return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
    }
    
    Public function detail($post){
        //print_r($post);die;
        $sql = "select * from t_file_upload_detail where fileUploadId = {$post['fileUploadId']} ";
        $count_sql = "SELECT COUNT(1) AS nrows FROM t_file_upload_detail where fileUploadId = {$post['fileUploadId']};";        
        $count = $this->db->fetchOne($count_sql);
        if(!empty($post)){
            $sql .= " ORDER BY id desc ";
            $offset = (intval($post['pageNum'])-1)*intval($post['pageSize']);
            $sql .= " limit {$offset},{$post['pageSize']}";
        }
        $rowset = $this->db->fetchAll($sql, 1);
        //return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
        return array('totalRows' => $count['nrows'], 'data' => $rowset, 'success' => 1);
    }
    
    public function index2($post){
        //print_r($post);die;
        if($post['groupid'] === 'null' || $post['groupid'] === 'all')
            $post['groupid'] = '';
        
        $sql = "SELECT T_BD_terminal.*,t_auth_user.name as username FROM T_BD_terminal ";
        $count_sql = "SELECT COUNT(1) AS nrows FROM T_BD_terminal ";
        $condition = " INNER JOIN t_auth_user ON t_bd_terminal.useridalias = t_auth_user.useridalias WHERE T_BD_terminal.status = 1 ";
        if($post['modelId'] != '')
            $condition .= " and t_bd_terminal.modelId = {$post['modelId']} ";
        if($post['communicateWay'] != '')
            $condition .= " and T_BD_terminal.communicateWay = {$post['communicateWay']} ";
        if($post['appTempId'] != '')
            $condition .= " and T_BD_terminal.appTempId = {$post['appTempId']} ";
        if($post['baseId'] != '')
            $condition .= " and T_BD_terminal.basePackageVer = (select t.version from t_app_package t where t.id = {$post['appTempId']}) ";
        if($post['middleId'] != '')
            $condition .= " and T_BD_terminal.middlePackageVer = (select t.version from t_app_package t where t.id = {$post['middleId']}) ";
        if($post['sdkId'] != '')
            $condition .= " and T_BD_terminal.sdkVer = (select t.version from t_app_package t where t.id = {$post['sdkId']}) ";
        if($post['groupid'] != '') {
            $groupId = $this->getGroupChild($post['groupid']);
            $condition .= " and T_BD_terminal.groupid in({$groupId}) ";
        }
        if($post['regionId'] != ''){
            if(substr($post['regionId'], -4) == '0000'){
                $paramReg = substr($post['regionId'],0, 2);
                $condition .= " and T_BD_terminal.regionId like '{$paramReg}%' ";
            } elseif(substr($post['regionId'], -2) == '00'){
                $paramReg = substr($post['regionId'],0, 4);
                $condition .= " and T_BD_terminal.regionId like '{$paramReg}%' ";
            } else{
                $condition .= " and T_BD_terminal.regionId = '{$post['regionId']}' ";
            }
        }
        if(!empty($post['machineId']))
            $condition .= " and t_bd_terminal.machineId like '%{$post['machineId']}%' ";
        $condition .= " and (T_BD_terminal.useridalias like '{$_SESSION['rbac']['idAlias']}.%' 
            or T_BD_terminal.useridalias = '{$_SESSION['rbac']['idAlias']}') ";
        $sql .= $condition;
        $count_sql .= $condition;
        $count = $this->db->fetchOne($count_sql);
        $sql .= " ORDER BY T_BD_terminal.createTime {$post['orderDirection']}";
        //echo $sql;die;
        $offset = (intval($post['pageNum'])-1)*intval($post['numPerPage']);
        $sql .= " limit {$offset},{$post['numPerPage']}";
        $rowset = $this->db->fetchAll($sql, 1);
        return array('totalRows' => $count['nrows'], 'data' => $rowset, 'success' => 1);
    }
    
    public function save($post) {
        //print_r($post);die;
        if('add' === $post['act']) {
            $res = $this->insertByPost($post);
            if($res['success']) {
                $result = array('success' => true,'error' => 'Add Success!');
                $this->_afterCreateDb($this->getData($post));
            } else {
                $result = array('success' => false,'error' => $res['message'],'errorCode' => 0);
            }
        } elseif('upd' === $post['act']) {
            if($this->updateByPost($this->getData($post))) {
                $result = array('status' => array('success' => 1,'message' => 'Update Success!'));
                $this->_afterUpdateDb($this->getData($post));
            } else {
                $result = array('status' => array('success' => 0,'message' => 'Update Failed!','errorCode' => 0));
            }
        } else {
            $result = array('status' => array('success' => 0,'message' => 'Error!','errorCode' => 1));
        }
        return $result;
    }
    
    public function insertByPost($post) {
        $qty = count($post['terminal'], 0);
        $zero = date("y-m-d H:i:s");
        $terminal = implode(",",$post['terminal']);
        if(strtotime($post['beginTime']) > strtotime($post['endTime'])){
            return array('success' => 0, 'message' => 'Start time must not be greater than the end time');
        }
        $sql2 = "SELECT t_bd_terminal.machineId FROM t_file_upload_planentry LEFT JOIN t_bd_terminal ON t_bd_terminal.id = 
            t_file_upload_planentry.terminalID where t_file_upload_planentry.terminalID IN({$terminal}) 
            AND t_file_upload_planentry.status < 2;";
        $res = $this->db->fetchOne($sql2, 1);
        if(!empty($res))
            return array('success' => 0, 'message' => 'The following terminal is unable to create a delivery task that may exist in other plans! SN ='.$res['machineid']);
        
        $sql = "insert into t_file_upload_plan(qty,beginTime,endTime,description,creator,useridalias,planType) values";
        foreach ($post['uploadtype'] as $val) {
            $sql .= "({$qty},'{$post['beginTime']}','{$post['endTime']}','{$post['description']}','{$_SESSION['rbac']['id']}',
                '{$_SESSION['rbac']['idAlias']}',{$val});";
            $this->db->begin();
            if(!$this->db->execute($sql)) {
                $this->db->rollback();
                return array('success' => 0, 'message' => 'Add to t_file_upload_plan error!');
            }
            $getID = $this->db->lastInsertId();
            $sql1 = 'insert t_file_upload_planentry(uploadPlanId,terminalID,description) values';
            foreach ($post['terminal'] as $val1) {
                $sql1 .= "({$getID},{$val1},'{$post['description']}'),";
            }
            $sql1 = rtrim($sql1, ",").';';
            if(!$this->db->execute($sql1)) {
                $this->db->rollback();
                return array('success' => 0, 'message' => 'Add to  t_file_upload_planentry error!');
            }
            $this->db->commit();
        }
        return array('success' => 1);
    }
    
    public function getGroupChild($id){
        //f_queryChildren是在mysql里写的一个函数，其返回值类似‘$,2,55,33’
        $sql = "SELECT f_queryChildren({$id}) as aa;";
        $res = $this->db->fetchOne($sql, 1);
        $res = $res['aa'];
        $res = str_replace('$,', '', $res);
        return $res;
    }
}