<?php

class InitkeySoa extends ModelSoa
{
    //public $primaryKey = 'id';
    public $order = array('field'=>'createTime','direction'=>'desc');
    public $method=array(
        'index'		=> 'initkey/getinitkey',
        'get'          => 'initkey/saveinitkey',
        'update'	=> 'initkey/modifyinitkey',
        'getbybatchno'  => 'initkey/queryinitkey'
    );
    public function checkfile($batchno)
    {
    	$result = array();
    	$key = $this->execute(array('batchNo'=>intval($batchno),'pagesize'=>1000),'getbybatchno');
    	if(empty($key['data']))
    	{
            $result['flg'] = false;
            $result['value'] = 1;
    	}
    	else 
    	{
            $result['flg'] = true;
            $result['value'] = $key['data'];
    	}
    	return $result;
    }
}

/*class InitkeyServ extends ModelServ{
	var $serv = 'serv_device';
	var $primaryKey = 'batchno';
	var $method=array(
			'index'		=> 'xgd.system.InitKeyMain.query',
			'get'		=> 'xgd.system.InitKeyMain.get',
			'update'	=> 'xgd.system.InitKeyMain.update',
			'getbybatchno' => 'xgd.system.initkey.query'
		);
	var $order = array('field'=>'createdate','direction'=>'desc');
	
	public function checkfile($batchno)
    {
    	$result = array();
    	$key = $this->execute(array('batchno'=>intval($batchno),'pagesize'=>1000),'getbybatchno');
    	if(empty($key['data']))
    	{
    		$result['flg'] = false;
    		$result['value'] = 1;
    	}
    	else 
    	{
    		$result['flg'] = true;
    		$result['value'] = $key['data'];
    	}
    	return $result;
    }
	
}*/