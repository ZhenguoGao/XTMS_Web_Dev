<?php

/**
 * Packbase
 *  
 * @author zhaimin
 */

class PackbaseSoa extends ModelSoa2
{
    public $primaryKey = 'id';
    //public $lookupfield = array(array('packageName','名称','200'),array('version','版本','200'),array('modelName','适用机型'));
    public $lookupfield = array('packagename','version','modelname');
    public $order = array('field'=>'published','direction'=>'desc');
    /**
    public $method = array(
        'index'             =>	'package/queryPackage',
        'add'               =>	'package/addPackage',
        'get'               =>	'package/queryPackageDetail',
        'logUpload'         =>	'logUpload/queryLogUpload',
        'MaxVersion'        =>	'package/queryMaxVersionByModel',
        'AllVersion'        =>	'package/queryAllVersionByModel',
        'validateArchiveNo' =>	'package/validateArchiveNo'
    );
    **/
    public $method = array(
        'index'             => 'packbase/search',
        'add'               => 'package/addPackage',
        'update'            => 'packbase/modify',
        'delete'            => 'packbase/delete',
        'get'               => 'packbase/detail',
        'logUpload'         => 'logUpload/queryLogUpload',
        'MaxVersion'        => 'packbase/queryMaxVersionByModel',
        'AllVersion'        => 'packbase/queryAllVersionByModel',
        'validateArchiveNo' => 'packbase/validateArchiveNo'
    );

    function detail($post)
    {
        $Num = $post['pageNum']!='' ? $post['pageNum'] : 1;
        $numPer = !empty($post['numPerPage']) ? $post['numPerPage'] : 20;
        $post['pageNum']=intval($Num);
        $post['pageSize']=intval($numPer);
        return $this->execute($post,'get');
    }

    public function postSave($post)
    {
        $post['jsonStr'] = json_encode($this->formatPost($post));
        $request = new \Phalcon\Http\Request();
        $post['clientIp'] = $request->getClientAddress();
        $config = $this->config;
        $server = $this->server ? $this->server:'soa';
        $url = "{$config->$server}{$this->method['add']}";
        if(version_compare(PHP_VERSION, '5.5.0', '>=')){
            $post['file'] = new CURLFile(realpath('../'.$post['uploadfile']));
        }else{
            $post['file'] = '@'.realpath('../'.$post['uploadfile']);
        }
        $ch = curl_init();  
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        $tmpInfo = curl_exec($ch);
        if (curl_errno($ch)) {
           $msgerr = 'Call error ：'.curl_error($ch);
           curl_close($ch);
           exit(json_encode(array("statusCode"=>300,"message"=>$msgerr)));
        }
        curl_close($ch);
        //print_r(json_decode($tmpInfo,true));die;
        return json_decode($tmpInfo,true);
    }
}