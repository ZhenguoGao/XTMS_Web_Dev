<?php
/**
 * 基类
 * @author lujun
 * @version 1.0
 */

class ModelBase1
{
    protected $db;
    var $tableName = '';
    var $primaryKey = '';
    var $fields = '';
    var $externs = null;
    var $uniqueFields = null;
    var $uniqueErrorInf = 'The same information already exists!';
    protected $_logger;
    public $replacevalue = array();

    /**
     * 设置查询的字段和显示字段
     * @var array
     */
    var $pareTable = array();

    /**
     * 外键映射数组,foreignKey1为需要映射的外键,有多个。
     * tableClass 对应表的类名
     * mappingKey 对应外表的字段名称
     * displayKey 显示的字段名称
     * externKeys 附加条件数组
     * @var array
     */
    var $foreignTable = array(
        'foreignKey1' => array(
            'tableName' => '',//表别名：表自身多连接
            'mappingKey' => '',
            'displayKey' => '',
            'externKeys' => array()
        ),
    );

    protected $_externSql = '';
    protected $_searchSql = '';
    protected $_selectField = '';
    protected $_bindParams = array();
    protected $_foreignKey = array();

    function __construct()
    {
        $this->db = new \Phalcon\Db\Adapter\Pdo\Mysql(
            array(
                "adapter"	=> "mysql",
//                "host"=> '10.14.200.111',
//                "username"=> 'bcastms',
//                "password"	=> 'Paic1234@',

//                 "host"      => '10.18.8.159',
//                 "username"  => 'root',
//                 "password"  => 'Xgd_Xtms_!@#$_2017',
            		"host"      => '127.0.0.1',
            		"username"  => 'root',
            		"password"  => '123456',

                // "host"      => '172.17.2.24',
//                 "host"      => '192.168.137.167',
//                 "username"  => 'test',
//                 "password"  => '123456',

                "dbname"	=> 'xtms2',
                "charset"	=> 'utf8'
            )
        );
        //$this->_logger = new \Phalcon\Logger\Adapter\File("../app/logs/db.log");
    }

    /**
    public function _getTranslation()
    {
        //Ask browser what is the best language
        $language = $this->request->getBestLanguage();
        // 		echo $language;die;
        //Check if we have a translation file for that lang
        if (file_exists(__DIR__."/../messages/".$language.".php")) {
            require __DIR__."/../messages/".$language.".php";
        } else {
            // fallback to some default
            require __DIR__."/../messages/cn.php";
        }
        //Return a translation object
        return new \Phalcon\Translate\Adapter\NativeArray(array(
            "content" => $messages
        ));
    }
    **/

    public function search($post, $get)
    {
        return $this->findByPost($post, $get);
    }

    public function add($post)
    {
        $post = $post['param'];
        $post['act'] = 'add';
        return $this->save($post);
    }

    public function modify($post)
    {
        $post = $post['param'];
        $post['act'] = 'upd';
        return $this->save($post);
    }

    public function detail($post)
    {
        $pk = $post['param'][$this->primaryKey];
        return $this->findByPk($pk);
    }

    public function delete($post)
    {
        $pk = $post['param'][$this->primaryKey];
        return $this->remove($pk);
    }

    public function getSource()
    {
    	return $this->tableName;
    }

    public function getLookupField()
    {
    	return $this->pareTable['lookupfield'];
    }

    public function getPK()
    {
    	return $this->primaryKey;
    }

    function qstr($value)
    {
        if (is_int($value) || is_float($value)) { return $value; }
        if (is_bool($value)) { return $value ? $this->TRUE_VALUE : $this->FALSE_VALUE; }
        if (is_null($value)) { return $this->NULL_VALUE; }
        $value = str_replace("'", "''", $value);
        return  "'" . addcslashes($value, "\000\n\r\\\032") . "'";
    }

    protected function qtable($tableName, $schema = null)
    {
        return $schema != '' ? "{$schema}.{$tableName}" : $tableName;
    }

    protected function qfield($fieldName, $tableName = null, $schema = null)
    {
        return $tableName != '' ? $this->qtable($tableName, $schema) . '.' . $fieldName : $fieldName;
    }

    /**
     *
     * 根据绑定数组返回OR LIKE SQL语句
     * @param array $bind_params
     */
    protected function _getSearchSql($condition)
    {
        if (empty($condition)) {
        	$this->_bindParams = array();
        	return '';
        }
        $sql = '';
        foreach ($condition as $k => $v) {
            if ( in_array($k, $this->pareTable['getColumns']) && $v!='' ) {
                $sql .= ' AND ' . $this->qfield($k, $this->qtable($this->getSource()) ) . " LIKE '%{$v}%'" ;
            }
            if ( in_array($k, $this->_foreignKey) && $v!='' ) {
                $sql .= ' AND ' . $this->qfield($k, $this->qtable($this->foreignTable[$k]['tableName']) ) . " LIKE '%{$v}%'" ;
            }
            if ($k == 'keywords' && $v!='' && isset($this->pareTable['lookupfield'])) {
                $sql .= ' and (';
                foreach($this->pareTable['lookupfield'] as $value) {
                    $sql .= $this->qtable($this->getSource()).'.'.$value . " LIKE '%{$v}%'".' or ' ;
                }
                $sql = ' '.rtrim( trim($sql),'or ' );
                $sql .= ' ) ';
                //echo $sql;die;
            }
        }
        return $sql;
    }

    protected function _parseSql()
    {
        $fields = '';
        foreach ($this->pareTable['getColumns'] as $k) {
            if (array_key_exists($k, $this->foreignTable)) {
                if(!is_array($this->foreignTable[$k]['displayKey'])) {
                    $fields .= ','.$this->qfield($this->foreignTable[$k]['displayKey'],$this->foreignTable[$k]['tableName']);
                }	else {
                    foreach($this->foreignTable[$k]['displayKey'] as $diskey) {
                        $fields .= ','.$this->qfield($diskey, $this->foreignTable[$k]['tableName']);
                    }
                }
                $this->_externSql .= " INNER JOIN {$this->qtable($this->foreignTable[$k]['tableName'])} ON
                    {$this->qfield( $k,$this->qtable($this->getSource()) )} =
                    {$this->qfield($this->foreignTable[$k]['mappingKey'],$this->foreignTable[$k]['tableName'])}";
                if (!is_null($this->foreignTable[$k]['externKeys'])) {
                    foreach ($this->foreignTable[$k]['externKeys'] as $k1 => $v1) {
                        $this->_externSql .= " AND {$this->qfield($k1, $this->foreignTable[$k]['tableName'])}=:{$k1}";
                        $this->_bindParams[$k1] = $v1;
                    }
                }
                $this->_foreignKey[] = $this->foreignTable[$k]['displayKey'];
            }
            $fields .= ','.$this->qfield($k, $this->qtable($this->getSource()));
        }
        $this->_selectField .= $fields;
    }

    public function findByPk($pk)
    {
        $this->_parseSql();
        $fields = ltrim($this->_selectField,',');
        $sql = "SELECT {$fields} FROM {$this->qtable($this->getSource())} {$this->_externSql} WHERE {$this->qfield($this->getPK(), $this->qtable($this->getSource()))}={$pk}";
        //return $this->db->fetchOne($sql);

        //$sql = "SELECT {$fields} FROM {$this->qtable($this->getSource())} {$this->_externSql} WHERE {$this->qfield($this->getPK(), $this->qtable($this->getSource()))}=:name";
        $sql .= $this->param(true);
        //echo($sql);die;
        //return $this->db->fetchOne($sql, Phalcon\Db::FETCH_ASSOC, array('name' => $pk));
        $result= $this->db->fetchOne($sql, 1);
        if(!empty($result)){
            return array('status' => array('success' => true),'result' => $result);
        } else{
            return array('status' => array('success' => false, 'errorCode' => 0, 'message' => 'The result is null!'));
        }
    }
    /**
     * 查询所有结果集合
     * @param unknown $sql
     */
    public function queryAll($sql){
    
    	return      $res=	$this->db->fetchAll($sql);
    
    }
    /**
     * 查询一条记录
     * @param unknown $value
     * @return unknown|string
     */
    public function queryOne($sql){
    	 
    	return	$count = $this->db->fetchOne($sql);
    }

    /**
     *
     * 利用前端传过来的参数查询记录
     * @param array $post
     * @param array $get
     * @return array('nrows', 'rowset')
     */
    public function findByPost($post, $get)
    {
        $this->_parseSql();
        $fields = ltrim($this->_selectField,',');
        $sql = "SELECT {$fields} FROM {$this->qtable($this->getSource())} {$this->_externSql} WHERE 1=1 ";
        $count_sql = "SELECT COUNT(1) AS nrows FROM {$this->qtable($this->getSource())} {$this->_externSql} WHERE 1=1 ";
        if (is_array($get) && !empty($get)) {
            foreach ($get as $k => $v) {
                if (in_array($k, $this->pareTable['getColumns'])) {
                    $this->_bindParams[$k] = $v;
                    $sql .= " AND {$this->qfield($k, $this->qtable($this->getSource()))} = {$this->_bindParams[$k]}";
                    $count_sql .= " AND {$this->qfield($k, $this->qtable($this->getSource()))} = {$this->_bindParams[$k]}";
                }
            }
        }
        $sql .= $this->_getSearchSql($post['param']);
        $count_sql .= $this->_getSearchSql($post['param']);
        $sql .= $this->param(true);
        $count_sql .= $this->param(true);
        //echo $count_sql;die;
        $count = $this->db->fetchOne($count_sql);
        if(!empty($post)){
            $sql .= " ORDER BY {$this->qfield($post['order']['field'])} {$post['order']['direction']}";
            $offset = (intval($post['page']['pageNum'])-1)*intval($post['page']['pageSize']);
            $sql .= " limit {$offset},{$post['page']['pageSize']}";
        }
        //echo $sql;die;
        $rowset = $this->db->fetchAll($sql, 1);
        return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
    }

    public function validation($post)
    {
        if(is_array($this->uniqueFields) && count($this->uniqueFields)>=0) {
            $post = array_change_key_case($post, CASE_LOWER);
            $bindParams = array();
            $sql = "SELECT * FROM {$this->qtable($this->getSource())} WHERE ";

            $sqla = array();
            foreach($this->uniqueFields as $field) {
                $fieds = explode(':', $field);
                if( is_array($fieds) && count($fieds)>1 ) {
                    $sqlb = array();
                    foreach($fieds as $fied) {
                        $sqlb[] = "{$this->qfield($fied, $this->qtable($this->getSource()))}=:{$fied}";
                        $bindParams[$fied] = $post[$fied];
                    }
                    $sqla[] = "( ".implode(' AND ', $sqlb)." )";
                } else {
                    $sqla[] = "( {$this->qfield($field, $this->qtable($this->getSource()))}=:{$field} )";
                    $bindParams[$field] = $post[$field];
                }
            }
            $sql .= '( '.implode(' OR ', $sqla).' )';
            if(!empty($post[$this->getPK()])) {
                $sql .= " AND {$this->getSource()}.{$this->getPK()} != {$post[$this->getPK()]}";
            }
            //$this->_logger->log($sql, \Phalcon\Logger::INFO);
            if(count($this->db->fetchAll($sql, Phalcon\Db::FETCH_ASSOC, $bindParams))>0){
                return false;
            }
            return true;
        }
        return true;
    }

    public function insertByPost($post)
    {
        $table = $this->qtable($this->getSource());
        $fields = array();
        $holders = array();
        $params = array();
        if ('t_auth_user' == $table) {
            if (strtotime($post['validtimestart']) > strtotime($post['validtimeend'])) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'The account valid cycle does not conform to the specification'
                    )
                );
                exit();
            }
            $f_sql = "select username from {$table} where username='{$post['username']}'";
            $ret = $this->db->fetchOne($f_sql, 1);
            if ($ret) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'User account already exists'
                    )
                );
                exit();
            }
        }
        if ('t_bd_group' == $table) {
            $f_sql = "select name from {$table} where name='{$post['name']}' and useridalias='{$post['useridalias']}'";
            $ret = $this->db->fetchOne($f_sql, 1);
            if ($ret) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'There is already a grouping of the same name'
                    )
                );
                exit();
            }
        }
        // 机型校验
        if ('t_bd_model' == $table) {
//            $f_sql = "select name,modeltype from {$table} where name='{$post['name']}' and modeltype='{$post['modeltype']}'";
            $f_sql = "select name,modeltype from {$table} where name='{$post['name']}'";
            $ret = $this->db->fetchOne($f_sql, 1);
            if ($ret) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'There are already namesake models'
                    )
                );
                exit();
            }
        }
        if ('t_param_param' == $table) {
            $f_name = "select name from {$table} where name='{$post['name']}' and useridalias='{$post['useridalias']}'";
            $ret_name = $this->db->fetchOne($f_name, 1);
            $f_number = "select number from {$table} where number='{$post['number']}' and useridalias='{$post['useridalias']}'";
            $ret_number = $this->db->fetchOne($f_number, 1);
            if ($ret_name) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'The current user has created the name of the parameter of the same name'
                    )
                );
                exit();
            }
            if ($ret_number) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'The current user has created the same parameter numbering project'
                    )
                );
                exit();
            }
            $post['description'] = str_replace(array("\r\n", "\r", "\n"), ' ', $post['description']);
        }
        unset($post[$this->getPK()]);
        foreach($post as $k => $dat) {
            $fields[] = $this->qfield($k, $table);
            $holders[] = ":{$k}";
            $param['name'] = $k;
            $param['value'] = $dat;
            //$param['length'] = -1;
            $params[] = $param;
        }
        $fields = implode(', ', $fields);
        $holders = implode(', ', $holders);
        //$sql = "INSERT INTO {$table} ({$this->qfield($this->getPK(), $table)}, {$fields}) VALUES (SEQ_{$this->pareTable['sequence']}.nextval, {$holders})";
        $sql = "INSERT INTO {$table} ({$fields}) VALUES ({$holders})";
        //$this->_logger->log($sql, \Phalcon\Logger::INFO);
        return $this->db->execute($sql, $post);
    }

    public function updateByPost($post)
    {
        $table = $this->qtable($this->getSource());
        $pkv = $post[$this->getPK()];
        $d_sql = "select * from {$table} where {$this->qfield($this->getPK(), $table)} = $pkv";
        $d_ret = $this->db->fetchOne($d_sql, 1);
        if ('t_auth_user' == $table) {
            $f_user = "select * from {$table} where id={$post['id']}";
            $d_user = $this->db->fetchOne($f_user, 1);
            if (!isset($post['roleid']) && isset($d_user['roleid'])) {
                $post['roleid'] = $d_user['roleid'];
            }
            if (strtotime($post['validtimestart']) > strtotime($post['validtimeend'])) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'The account valid cycle does not conform to the specification'
                    )
                );
                exit();
            }
            if ($d_ret['username'] != $post['username']) {
                $f_sql = "select username from {$table} where username='{$post['username']}'";
                $ret = $this->db->fetchOne($f_sql, 1);
                if ($ret) {
                    echo json_encode(
                        array(
                            'statusCode' => 300,
                            'message' => 'User account already exists'
                        )
                    );
                    exit();
                }
            }
        }
        if ('t_bd_group' == $table) {
            if ($d_ret['name'] != $post['name']) {
                $f_sql = "select name from {$table} where name='{$post['name']}' and useridalias='{$post['useridalias']}'";
                $ret = $this->db->fetchOne($f_sql, 1);
                if ($ret) {
                    echo json_encode(
                        array(
                            'statusCode' => 300,
                            'message' => 'There is already a grouping of the same name'
                        )
                    );
                    exit();
                }
            }
        }
        // 机型校验
        if ('t_bd_model' == $table) {
            if ($d_ret['name'] != $post['name'] || $d_ret['modeltype'] != $post['modeltype']) {
                $f_sql = "select name,modeltype from {$table} where name='{$post['name']}' and modeltype='{$post['modeltype']}'";
                $ret = $this->db->fetchOne($f_sql, 1);
                if ($ret) {
                    echo json_encode(
                        array(
                            'statusCode' => 300,
                            'message' => 'There are already similar models of the same name'
                        )
                    );
                    exit();
                }
            }
        }
        if ('t_param_param' == $table) {
            if ($d_ret['name'] != $post['name']) {
                $f_name = "select name from {$table} where name='{$post['name']}' and useridalias='{$post['useridalias']}'";
                $ret_name = $this->db->fetchOne($f_name, 1);
                if ($ret_name) {
                    echo json_encode(
                        array(
                            'statusCode' => 300,
                            'message' => 'A parameter name of the same name already exists'
                        )
                    );
                    exit();
                }
            }
            if ($d_ret['number'] != $post['number']) {
                $f_number = "select number from {$table} where number='{$post['number']}' and useridalias='{$post['useridalias']}'";
                $ret_number = $this->db->fetchOne($f_number, 1);
                if ($ret_number) {
                    echo json_encode(
                        array(
                            'statusCode' => 300,
                            'message' => 'The current user already exists with the parameter numbering project'
                        )
                    );
                    exit();
                }
            }
            $post['description'] = str_replace(array("\r\n", "\r", "\n"), ' ', $post['description']);
        }
        if ('T_MERCHANT' == $table) {
            $f_merchant = "select * from {$table} where mersid={$post['mersid']}";
            $d_merchant = $this->db->fetchOne($f_merchant, 1);
            $post['useridalias'] = $d_merchant['useridalias'];
        }
        if ('T_L_TERMINAL' == $table) {
            $f_l_terminal = "select * from {$table} where ltermid={$post['ltermid']}";
            $d_l_terminal = $this->db->fetchOne($f_l_terminal, 1);
            $post['useridalias'] = $d_l_terminal['useridalias'];
        }
        unset($post[$this->getPK()]);
        $pairs = array();
        $params = array();
        foreach($post as $k => $dat) {
            $param['name'] = $k;
            $param['value'] = $dat;
            $param['length'] = -1;
            $params[] = $param;
            $pairs[] = "{$this->qfield($k, $table)}=:{$k}";
        }
        $pairs = implode(', ', $pairs);
        $sql = "UPDATE {$table} SET {$pairs} WHERE {$this->qfield($this->getPK(), $table)} = " . $pkv;
        //$this->_logger->log($sql, \Phalcon\Logger::INFO);
        return $this->db->execute($sql, $post);
    }

    public function remove($ids)
    {
        $sql = "DELETE FROM {$this->qtable($this->getSource())} WHERE {$this->qfield($this->getPK(), $this->qtable($this->getSource()))} IN({$ids})";
        $sql .= $this->param();
        if ('t_auth_user' == $this->getSource()) {
            $ret = $this->findByPk($ids);
            $flag_user_sql = "select * from t_auth_user where useridAlias like '{$ret['result']['useridalias']}.%'";
            $flag_user = $this->db->fetchAll($flag_user_sql, 1);
            $flag_terminal_sql = "select * from t_bd_terminal where useridAlias='{$ret['result']['useridalias']}'";
            $flag_terminal = $this->db->fetchAll($flag_terminal_sql, 1);
            if ($flag_user) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'The user has sublevel users and cannot be deleted'
                    )
                );
                exit();
            }
            if ($flag_terminal) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'This user associated terminal machine cannot be deleted'
                    )
                );
                exit();
            }
        }
        if ('t_param_param' == $this->getSource()) {
            $f_sql = "select id from t_param_paramtemp where paramId='{$ids}'";
            $f_ret = $this->db->fetchOne($f_sql, 1);
            if ($f_ret) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'The parameter item has been associated with the parameter template and cannot be deleted'
                    )
                );
                exit();
            }
        }

        if ('T_VENDORS' == $this->getSource()) {
            $f_sql = "select id from t_bd_model where supplierId='{$ids}'";
            $f_ret = $this->db->fetchOne($f_sql, 1);
            if ($f_ret) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'The manufacturer has created a model that cannot be removed'
                    )
                );
                exit();
            }
        }
        //$this->_logger->log($sql, \Phalcon\Logger::INFO);
        if($this->db->execute($sql)){
            $this->_afterRemoveDbByPkv($ids);
            return array('status' => array('success' => 1));
        } else{
            return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => '0'));
        }
    }

    public function save($post)
    {
        // $t = $this->_getTranslation();
        $result = array();
        if(!$this->validation($post)) {
        	//$result['statusCode'] = '300';
        	//$result['message'] = $this->uniqueErrorInf;
        	$result = array('status' => array('success' => 0,'message' => $this->uniqueErrorInf,'errorCode' => 0));
        } else {
            if('add' === $post['act']) {
                if($this->insertByPost($this->getData($post))) {
                    $result = array('status' => array('success' => 1,'message' => 'Add Success!'));
                    $this->_afterCreateDb($this->getData($post));
                } else {
                    $result = array('status' => array('success' => 0,'message' => 'Add Failed!','errorCode' => 0));
                }
            } elseif('upd' === $post['act']) {
                if($this->updateByPost($this->getData($post))) {
                    $result = array('status' => array('success' => 1,'message' => 'Update Success'));
                    $this->_afterUpdateDb($this->getData($post));
                } else {
                    $result = array('status' => array('success' => 0,'message' => 'pdate Failed','errorCode' => 0));
                }
            } else {
                $result = array('status' => array('success' => 0,'message' => 'Error!','errorCode' => 1));
            }
        }
        return $result;
    }

    /**
     *
     * 将POST上来数据通过fields过滤
     * @param array
     * @return array
     */
    public function getData($post)
    {
        $data = array();
        $post = array_change_key_case($post, CASE_LOWER);
        $fields = array_change_key_case($this->pareTable['getColumns'], CASE_LOWER);
        foreach($fields as $key) {
            if(array_key_exists(strtolower($key), $post)) {
                $data[strtolower($key)] = $post[strtolower($key)];
            }
        }
        return $data;
    }

    public function findByField($field, $value, $fields = '*')
    {
        $sql = "SELECT {$fields} FROM {$this->qtable($this->getSource())} WHERE {$field}='{$value}'";
        return $this->db->fetchOne($sql);
    }

    public function findAllByField($field, $value, $fields = '*')
    {
        $sql = "SELECT {$fields} FROM {$this->qtable($this->getSource())} WHERE {$field}='{$value}'";
        return $this->db->fetchAll($sql, 1);
    }

    public function execute($sql, $bind)
    {
        $params = array();
        foreach($bind as $k => $v) {
            $param['name'] = $k;
            $param['value'] = $v;
            $param['length'] = -1;
            $params[] = $param;
        }
        return $this->db->execute($sql, $bind);
    }

    public function getNextval($sequence)
    {
        $sql = "select {$sequence}.nextval from dual";
        $res = $this->db->fetchOne($sql);
        return $res['nextval'];
    }

    public function stringToHex($asc)
    {
        $r = '';
        $hexes = array ("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F");
        for ($i=0; $i<strlen($asc); $i++) {$r .= ($hexes [(ord($asc{$i}) >> 4)] . $hexes [(ord($asc{$i}) & 0xf)]);}
        return $r;
    }

    function hexToString($h)
    {
        $r = "";
        for ($i= (substr($h, 0, 2)=="0x")?2:0; $i<strlen($h); $i+=2) {$r .= chr (base_convert (substr ($h, $i, 2), 16, 10));}
        return $r;
    }

    public function findBySql($sql)
    {
        return $this->db->fetchOne($sql);
    }

    public function getMenu($sql)
    {
        return $this->db->fetchAll($sql, 1);
    }

    public function removeDept($ids)
    {
        $sql = "DELETE FROM T_DEPARTMENT WHERE T_DEPARTMENT.dept_code IN({$ids})";
        return $this->db->execute($sql);
    }

    public function log($str)
    {
        //$this->_logger->log($str, \Phalcon\Logger::INFO);
    }

    /**
     *
     * 产生32位唯一序列号
     * @return string
     */
    protected function _guid()
    {
        $charid = strtoupper(md5(uniqid(mt_rand(), true)));
        $guid = substr($charid, 0, 8)
        .substr($charid, 8, 4)
        .substr($charid,12, 4)
        .substr($charid,16, 4)
        .substr($charid,20,12);
        return $guid;
    }

    function _afterCreateDb($row)
    {
        $log = new Log;
        $str = $this->arr_encode($row);
        $log->createLog($str,$this->qtable($this->getSource()),'0');
    }

    function _afterUpdateDb($row)
    {
        $log = new Log;
        $str = $this->arr_encode($row);
        $log->createLog($str,$this->qtable($this->getSource()),'1');
    }

    function _afterRemoveDbByPkv($pkv)
    {
        $log = new Log;
        $str = $this->arr_encode(array($this->primaryKey=>$pkv));
        $log->createLog($str,$this->qtable($this->getSource()),'2');
    }

    function _afterLoad($row)
    {
        $log = new Log;
        $str = $this->arr_encode($row);
        $log->createLog($str,$this->qtable($this->getSource()),'3');
    }

    function arr_encode($row)
    {
        if (empty($row))
            return '';
        /**
        $str = '{';
        foreach ($row as $key => $value) {
            $str .= '"'.$key.'":"'.$value.'";';
        }
        $str .= '}';
        return $str;
        **/
        return json_encode($row);
    }

    public function isExist($field, $post)
    {
        $sql = "SELECT {$this->primaryKey} FROM {$this->getSource()} WHERE {$field}='{$post[$field]}' ";
        if('upd' === $post['act']) {
            $sql .= "and {$this->primaryKey} != '{$post[$this->primaryKey]}'";
        }
        $res = $this->db->fetchOne($sql);
        if(!empty($res)){
            return true;
        } else{
            return false;
        }
    }

    public function getReplaceValue()
    {
        return $this->replacevalue;
    }

    public function param($source = false)
    {
        if($this->qtable($this->getSource()) == 't_auth_menu' || $this->qtable($this->getSource()) == 'T_VENDORS' || $this->qtable($this->getSource()) == 't_bd_model')
            return '';
        if ($this->qtable($this->getSource()) == 't_bd_cpuexception' || $this->qtable($this->getSource()) == 't_log_terminalexception') {
            return " and (t_bd_terminal.useridalias like '{$_SESSION['rbac']['idAlias']}.%' or t_bd_terminal.useridalias = '{$_SESSION['rbac']['idAlias']}') ";
        }
        if(!$source){
            return " and ({$this->qtable($this->getSource())}.useridalias like '{$_SESSION['rbac']['idAlias']}.%' or {$this->qtable($this->getSource())}.useridalias = '{$_SESSION['rbac']['idAlias']}') ";
        }
        return " and ({$this->qtable($this->getSource())}.useridalias like '{$_SESSION['rbac']['idAlias']}.%' or {$this->qtable($this->getSource())}.useridalias = '{$_SESSION['rbac']['idAlias']}') ";
    }
}
