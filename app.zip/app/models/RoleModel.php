<?php
/**
 * 角色接口
 *  
 * @author zhaimin
 */

class RoleModel extends ModelSoa2
{
    public $primaryKey = 'id';
    public $order = array('field'=>'id','direction'=>'desc');
    public $method = array(
    	'index'	=> 'role/search',
        'add'   => 'role/add',
    	'update'=> 'role/modify',
    	'delete'=> 'role/delete',
    	'get'	=> 'role/detail'
    );
}

