<?php

/**
 * Spos
 *  
 * @author lujun
 */

class ApkfileNew extends ModelBase1
{
    var $tableName = 't_app_apkfile';
    var $pareTable = array(
        'getColumns'=>array('id','name','nickname','versionname','md5','package','createtime','filepath','modelid','useridalias','versioncode','desc',
            'filename','upgradelevel'),
        'lookupfield'=>array('filename','package','nickname')
    );
    
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
        'modelid' => array(
            'tableName' => 't_bd_model',
            'mappingKey' => 'id',
            'displayKey' => array('name as modelname'),
            'externKeys' => array()
        ),
    );
    var $primaryKey = 'id';
    
    public function edit($post){
        $sql = "update t_app_apkfile set modelid = {$post['model_id']} where id = {$post['id']};";
        if($this->db->execute($sql)){
            return array('success' => true);
        } else{
            return array('success' => false, 'errorCode' => 0, 'message' => '0');
        }
    }
    
    protected function _getSearchSql($condition)
    {
    	if (empty($condition)) {
    		$this->_bindParams = array();
    		return '';
    	}
    	$sql = '';
    	foreach ($condition as $k => $v) {
    		if ( in_array($k, $this->pareTable['getColumns']) && $v!='' ) {
    			if($k == 'filename'){
    			$sql .= ' AND (' . $this->qfield($k, $this->qtable($this->getSource()) ) . " LIKE '%{$v}%' or ".$this->qfield('nickname', $this->qtable($this->getSource()) )." LIKE '%{$v}%')" ;
    			}else{
    			$sql .= ' AND ' . $this->qfield($k, $this->qtable($this->getSource()) ) . " LIKE '%{$v}%'" ;
    			}
    		}
    		if ( in_array($k, $this->_foreignKey) && $v!='' ) {
    			$sql .= ' AND ' . $this->qfield($k, $this->qtable($this->foreignTable[$k]['tableName']) ) . " LIKE '%{$v}%'" ;
    		}
    		if ($k == 'keywords' && $v!='' && isset($this->pareTable['lookupfield'])) {
    			$sql .= ' and (';
    			foreach($this->pareTable['lookupfield'] as $value) {
    				$sql .= $this->qtable($this->getSource()).'.'.$value . " LIKE '%{$v}%'".' or ' ;
    			}
    			$sql = ' '.rtrim( trim($sql),'or ' );
    			$sql .= ' ) ';
    			//echo $sql;die;
    		}
    	}
    	return $sql;
    }
}