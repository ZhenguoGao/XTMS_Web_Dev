<?php

/**
 * paramitem
 *  
 * @author zhaimin
 */

//class ParamitemSoa extends ModelSoa
class ParamitemSoa extends ModelSoa2
{
    //var $lookupfield = array('machinesid','machineno','model_id','status');
    public $primaryKey = 'id';
    public $order = array('field'=>'number','direction'=>'desc');
    /**
    public $method = array(
    	'index'	=> 'param/getParam',
        'add'   => 'param/addParam',
    	'update'=> 'param/modifyParam',
    	'delete'=> 'param/removeParam',
    	'get'	=> 'param/getParamById'
    );
    **/
    public $method = array(
        'index'	=> 'param/search',
        'add'   => 'param/add',
        'update'=> 'param/modify',
        'delete'=> 'param/delete',
        'get'	=> 'param/detail'
    );
}