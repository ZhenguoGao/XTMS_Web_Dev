<?php

/**
 * Fitting
 *  
 * @author zhaimin
 */

class DeviceSoa extends ModelSoa2
{
    public $order = array('field'=>'T_BD_terminal.createTime','direction'=>'desc');
    public $primaryKey = 'id';
    public $lookupfield = array('machineid');

    /**
    public $method = array(
    	'index'             =>	'terminal/getByPage',
        'index2'            =>	'terminal/upgrade/getByPage',
    	'updplangetid'      =>	'terminal/upgrade/getAllId',
        'getMerchantInfo'   =>	'terminal/getMerchantInfo',
    	'addPwdboard'       =>	'fitting/addPwdboard',
    	'addTablet'         =>	'fitting/addTablet',
    	'seton'             =>	'terminal/start',
    	'setoff'            =>	'terminal/stop',
        'import'            =>  'terminal/importTerminal'
    );
    **/
    public $method = array(
        'index'             =>	'device/search',
        'index2'            =>	'device/index2',
    	'index3'            =>	'device/index3',
        'updplangetid'      =>	'terminal/upgrade/getAllId',
        'getMerchantInfo'   =>	'terminal/getMerchantInfo',
        'addPwdboard'       =>	'fitting/addPwdboard',
        'addTablet'         =>	'fitting/addTablet',
        'seton'             =>	'terminal/start',
        'setoff'            =>	'terminal/stop',
        'import'            =>  'device/importTerminal',
        'getGroup'          =>  'device/group',
        'merchantInfo'      =>  'device/merchantInfo',
        'add'               =>	'device/add',
        'update'               =>	'device/modify',
        'apkinfo'               =>	'device/apkinfo',
        'reportInfo'=>'device/reportInfo'
    );
    
    function findByPost2($post)
    {
    	$Num = $post['pageNum']!='' ? $post['pageNum'] : 1;
        $numPer = !empty($post['numPerPage']) ? $post['numPerPage'] : 20;
        $post['pageNum']=intval($Num);
        $post['pageSize']=intval($numPer);
        return $this->execute($post,'index2');
    }
    
    function findByPost3($post)
    {
    	$Num = $post['pageNum']!='' ? $post['pageNum'] : 1;
    	$numPer = !empty($post['numPerPage']) ? $post['numPerPage'] : 20;
    	$post['pageNum']=intval($Num);
    	$post['pageSize']=intval($numPer);
    	return $this->execute($post,'index3');
    }
    
    public function findByPk($pk) {
        $model = new DeviceNew;
        return $model->findByPk($pk);
    }
}