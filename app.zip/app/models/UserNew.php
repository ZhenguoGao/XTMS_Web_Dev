<?php
/**
 * 用户类接口
 *  
 * @author lujun
 */


class UserNew extends ModelBase1
{
    var $tableName = 't_auth_user';
    var $pareTable = array(
       	'getColumns'=>array('id','username','password','name','roleId','locked','remark','validTimeStart','validTimeEnd',
       	    'createTime','userLerver','isAdmin','userType','parentid','userIdAlias','lastLoginTime'
       	),
        'lookupfield'=>array('username','name')
    );
    var $foreignTable = array(
        'roleId' => array(
            'tableName' => 't_auth_role',
            'mappingKey' => 'id',
            'displayKey' => array('name as rolename'),
            'externKeys' => array()
        ),
    );
    var $primaryKey = 'id';
    var $order = array('field'=>'id','direction'=>'desc');
    public function getRoute($post){
    	  $pageNum=$post['pageNum']-1;
    	  $numPerPage=20;
    	  $firtpage=$pageNum*$numPerPage;
    	  $search=" where ";
    	  if(!empty($post['name'])){ $search.=" t_auth_user.name like '%{$post['name']}%' and "; }
    	  if(!empty($post['username'])){ $search.=" t_auth_user.username like '%{$post['username']}%' and "; }
    	  if(!empty($post['roleId'])){ $search.=" t_auth_user.roleId={$post['roleId']} and "; }
    	  if(!empty($post['locked'])){ $search.=" t_auth_user.locked={$post['locked']} and "; }
//     	  if(!empty())
    	  $search.=" 1=1";
   	  $sql=" SELECT t_auth_user.id,t_auth_user.username,t_auth_user.password,t_auth_user.name,t_auth_role.name AS 
   	      rolename,t_auth_user.roleId,t_auth_user.locked,t_auth_user.remark,t_auth_user.validTimeStart,t_auth_user.validTimeEnd,
   	      t_auth_user.createTime,t_auth_user.userLerver,t_auth_user.isAdmin,t_auth_user.userType,t_auth_user.parentid,
   	      t_auth_user.userIdAlias,t_auth_user.lastLoginTime FROM t_auth_user  INNER JOIN t_auth_role ON
                    t_auth_user.roleId =
                    t_auth_role.id {$search}
                     ORDER BY id DESC LIMIT $firtpage,$numPerPage";
    	$rowset= $this->queryAll($sql, 1);
    	$sql_count=" select count(t_auth_user.id) as nrows from  t_auth_user  INNER JOIN t_auth_role ON
                    t_auth_user.roleId =
                    t_auth_role.id {$search} ";
    	$count=$this->queryOne($sql_count);
    	
    return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
//    return 
    
    }
    
    public function login($post)
    {

        ini_set('date.timezone','Asia/Shanghai');
        //验证用户
        $userno = $post['param']['username'];
        $password = md5($post['param']['password']);
        $sql = "select u.*, r.name roleName from t_auth_user u left join t_auth_role r on u.roleId=r.id where u.username = '{$userno}';";
        $user = $this->findBySql($sql);
        if(empty($user)){
            return array('status' => array('success' => 0, 'message' => 'User name does not exist!'));
        } elseif($password != $user['password']){
            return array('status' => array('success' => 0, 'message' => 'Password Error!'));
        } elseif($user['locked'] == 1){
            return array('status' => array('success' => 0, 'message' => 'The user is locked!'));
        } elseif($user['rolename'] == ''){
            return array('status' => array('success' => 0, 'message' => 'The user does not assign roles!'));
        }
        $zero = date("Y-m-d");
        $format = 'Y-m-d';
        $obj = new DateTime($zero);
        $obj1 = new DateTime($user['validtimestart']);
        $obj2 = new DateTime($user['validtimeend']);
        /**
        if((strtotime($zero) < strtotime($user['validtimestart'])) || (strtotime($zero) > strtotime($user['validtimeend']))){
            return array('status' => array('success' => 0, 'message' => 'The user has been used within the validity period!'));
        }
        **/
        if(($obj->format($format) < $obj1->format($format)) || ($obj->format($format) > $obj2->format($format))){
            return array('status' => array('success' => 0, 'message' => 'The user has been in use of the validity period!'));
        }
        $result = array('id' => $user['id'], 'username' => $user['username'], 'userLerver' => $user['userlerver'], 
            'userType' => $user['usertype'], 'idAlias' => $user['useridalias'], 'password' => $user['password']
        );
        $sql_update = "update t_auth_user set lastlogintime = '{$zero}' where id = {$user['id']};";
        $this->db->execute($sql_update);
        return array('status' => array('success' => 1, 'message' => ''), 'result' => $result);
    }

    public function menu($post)
    {
        $sql = "select m.* from t_auth_menu m inner join t_auth_menu_rel r on m.id = r.menuId inner join t_auth_user u on r.roleId = u.roleId 
            where u.id = {$post['param']['id']} and m.locked = false;";
        //echo $sql;die;
        $result =  $this->getMenu($sql);
        $ctrl = array('login','board','lookup','chgpwd');
        foreach ($result as $re) {
            if(!empty($re['link']) && $re['link'] != 'null' )
                $ctrl[] = strtolower( substr($re['link'], 0, stripos($re['link'],'/')) );
        }
        $ctrl_re = implode($ctrl, ',').',';
        //print_r(implode($ctrl, ','));die;
        $_SESSION['rbac']['grants'] = $ctrl_re;
        $result =  $this->list_to_tree($result);
        return $result[0];
    }
    
    /**
     * 节点遍历
     * @param $list
     * @param string $pk
     * @param string $pid
     * @param string $child
     * @param int $root
     * @return array
     */
    private function list_to_tree($list, $pk = 'id', $pid = 'parentid', $child = 'subMenu', $root = 0)
    {
        $tree = [];
        if (is_array($list)) {
            // 创建基于主键的数组引用
            $refer = [];
            foreach ($list as $key => $data) {
                $refer[$data[$pk]] =& $list[$key];
            }
            foreach ($list as $key => $data) {
                // 判断是否存在parent
                $parentId = $data[$pid];
                if ($root == $parentId) {
                    $tree[] =& $list[$key];
                } else {
                    if (isset($refer[$parentId])) {
                        $parent =& $refer[$parentId];
                        $parent[$child][] =& $list[$key];
                    } else{
                        $parent =& $refer[$parentId];
                        $parent[$child][] = array();
                    }
                }
            }
        }
        return $tree;
    }
    
    public function getRole()
    {
        //print_r($_SESSION['rbac']['user']['idAlias']);die;
        $sql = "select id,name from t_auth_role where useridalias = '{$_SESSION['rbac']['user']['idAlias']}';";
        return $this->db->fetchAll($sql, 1);
    }
    
    public function reset($post)
    {
        $post = $post['param'];
        $post['password'] = md5('88888888');
        $post['act'] = 'upd';
        return parent::save($post);
    }
    
    public function getSub()
    {
    	//        $sql = "select max(useridalias) as useridalias from {$this->tableName} where userIdAlias like '{$_SESSION['rbac']['idAlias']}.%';";
    	//        $res = $this->db->fetchOne($sql, 1);
    
    	$userIdAlias = $_SESSION['rbac']['idAlias'];
    	$sql = "select userIdAlias from {$this->tableName} where userIdAlias like '{$_SESSION['rbac']['idAlias']}.%';";
    	$response = $this->db->fetchAll($sql, 1);
    	$len = count(explode('.', $userIdAlias));
    	foreach ($response as $key => $value) {
    		$data = explode('.', $value['useridalias']);
    		if (array_key_exists($len, $data)) {
    			$tmp[] = $data[$len];
    		}
    	}
    	rsort($tmp);
    	$id = $tmp['0'];
    	//        if (empty($res)){
    	if(empty($response)){
    		return 1;
    	} else{
    		//            $len = strlen($_SESSION['rbac']['idAlias']) + 1;
    		$result = $id + 1;
    		//            $result = substr($res['useridalias'], $len) + 1;
    		return $result;
    	}
    }
//     public function getUser($post)
//     {
//         $sql = "select id,name,useridalias,parentid from {$this->tableName}  INNER JOIN t_auth_role ON t_auth_user.roleId = t_auth_role.id where 1 = 1 ";
//         if($post['onlyParent'])
//             $sql .= ' and parentId = 0';
//         if($post['useridalias'] != ''){
//             $sql .= " and useridalias = '{$post['useridalias']}' ";
//         } else {
//             $sql .= $this->param();
//         }
// //        $sql .= $this->param();
//         $sql .= ' order by id asc;';
//         $res = $this->db->fetchAll($sql, 1);
//         return array('data' => $res, 'success' => 1);
//     }

	public function getUser($post)
	{
		$sql = "select t_auth_user.id,t_auth_user.name,t_auth_user.useridalias,t_auth_user.parentid from {$this->tableName} INNER JOIN t_auth_role ON t_auth_user.roleId = t_auth_role.id where 1 = 1 ";
		if($post['onlyParent'])
			$sql .= ' and t_auth_user.parentId = 0';
		if($post['useridalias'] != ''){
			$sql .= " and t_auth_user.useridalias = '{$post['useridalias']}' ";
		} else {
			$sql .= $this->param();
		}
		//        $sql .= $this->param();
		$sql .= ' order by t_auth_user.id asc;';
		$res = $this->db->fetchAll($sql, 1);
		return array('data' => $res, 'success' => 1);
	}

    public function getInfo($pk)
    {
        $sql = "select u.id,u.name,u.roleId,r.name from t_auth_user u left join t_auth_role r on r.id = u.roleId where u.id={$pk}";
        $ret = $this->db->fetchOne($sql, 1);

        return $ret;
    }
}