<?php

/**
 * Machine
 *  
 * @author zhaimin
 */

class MachineSoa extends ModelSoa
{
    //public $lookupfield = array('machinesid','machineno','model_id','status');
    //public $primaryKey = '';
    public $order = array('field'=>'T_BD_machine.id','direction'=>'desc');
    public $method = array(
    	'index'	=> 'machine/getByPage',
        'add'   => 'machine/add'
    );
}