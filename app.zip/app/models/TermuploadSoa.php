<?php

/**
 * 终端信息上送
 *  
 * @author zhaimin
 */

class TermuploadSoa extends ModelSoa2
{
    public $primaryKey = 'id';
    public $order = array('field'=>'beginTime','direction'=>'desc');
    /**
    public $method = array(
    	'index'	=> 'statistic/query',
    	'index2'=> 'statistic/getByPage',
        'add'   => 'statistic/add',
    	'get'	=> 'statistic/detail'
    );
    **/
    public $method = array(
        'index'	=> 'termupload/search',
        'index2'=> 'termupload/index2',
        'add'   => 'termupload/add',
        'get'	=> 'termupload/detail'
    );

    public function findByPost2($post)
    {
    	$Num = $post['pageNum']!='' ? $post['pageNum'] : 1;
        $numPer = !empty($post['numPerPage']) ? $post['numPerPage'] : 20;
        $post['pageNum']=intval($Num);
        $post['pageSize']=intval($numPer);
        return $this->execute($post,'index2');
    }
    
    function finddetail($post)
    {
    	$Num = $post['pageNum']!='' ? $post['pageNum'] : 1;
        $numPer = !empty($post['numPerPage']) ? $post['numPerPage'] : 20;
        $post['pageNum']=intval($Num);
        $post['pageSize']=intval($numPer);
        return $this->execute($post,'get');
    }
}