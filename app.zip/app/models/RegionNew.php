<?php

/**
 * RegionNew
 *  
 * @author lujun
 */

class RegionNew extends ModelBase1
{
    var $tableName = 't_bd_region';
    var $pareTable = array(
        'getColumns'=>array('id','regionName','regionGrade','parentId','phoneticTranscription','telAreaCode','completeName'),
        'lookupfield'=>array('regionName')
    );
    var $primaryKey = 'id';
    var $order = array('field'=>'id','direction'=>'desc');
    
    public function getPK()
    {
        return 'id';
    }
    
    public function getAll($post){
        $sql = "select id, regionName,regionGrade,parentId from {$this->tableName} where 1 = 1";
        if($post['parentId'] == 'all'){
            return array('data' => '', 'success' => 1);
        }else {
            if($post['regionGrade'] != '')
                $sql .= " and regionGrade = {$post['regionGrade']}";
            if($post['parentId'] != '')
                $sql .= " and parentId = {$post['parentId']}";
        }
        $sql .= ' order by id;';
        //echo $sql;die;
        $rowset = $this->db->fetchAll($sql, 1);
        return array('data' => $rowset, 'success' => 1);
    }
    
    public function getArea($post){
        $id = $post['id'];
        $sql = "SELECT regionname FROM t_bd_region WHERE id = $id;";
        $res = $this->db->fetchOne($sql);
        return $res['regionname'];
    }
}