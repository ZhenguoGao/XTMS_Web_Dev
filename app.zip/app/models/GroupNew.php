<?php

/**
 * GroupNew
 *  
 * @author lujun
 */

class GroupNew extends ModelBase1
{
    var $tableName = 't_bd_group';
    var $pareTable = array(
        'getColumns'=>array('id','name','description','creator','createTime','modifier','updateTime','parentId','useridalias'),
        'lookupfield'=>array('name')
    );
    
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
    );
    var $primaryKey = 'id';
    var $order = array('field'=>'id','direction'=>'desc');
    
    public function getPK()
    {
        return 'id';
    }
    
    public function getAll($post){
        $sql = "select id, name,parentid from {$this->tableName} where 1 = 1";
        if($post['onlyParent'])
            $sql .= ' and parentId = 0';
        //$sql .= $this->param();
         $sql .= " and useridalias = '{$_SESSION['rbac']['idAlias']}' ";
        $sql .= ' order by id;';
        //echo $sql;die;
        $rowset = $this->db->fetchAll($sql, 1);
        return array('data' => $rowset, 'success' => 1);
    }
    
    public function remove($id)
    {
        $sql = "DELETE FROM {$this->tableName} WHERE parentid = {$id};";
        $sql .= "DELETE FROM {$this->tableName} WHERE id = {$id}";
        $sql .= $this->param();
        //echo $sql;die;
        //$this->_logger->log($sql, \Phalcon\Logger::INFO);
        if($this->db->execute($sql)){
            $this->_afterRemoveDbByPkv($id);
            return array('status' => array('success' => 1));
        } else{
            return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => '0'));
        }
    }
    
    /**
     * 判断该分类是不是第四级分类（最多只允许四级）
     */
    public function isLast($id){
        $sql = "SELECT parentid FROM {$this->tableName} WHERE id = (SELECT parentid FROM {$this->tableName} WHERE id = 
            (SELECT parentid FROM {$this->tableName} WHERE id = (SELECT parentid FROM {$this->tableName} WHERE id = {$id})))";
        $rowset = $this->db->fetchOne($sql, 1);
        if(empty($rowset))
            return false;
        return true;
    }
    
    public function getGroupByUser($post){
        $sql = "select id, name,parentid from {$this->tableName} where 1 = 1";
        if($post['onlyParent'])
            $sql .= ' and parentId = 0';
        if($post['useridalias'] != ''){
            $sql .= " and useridalias = '{$post['useridalias']}' ";
        } else {
            $sql .= $this->param();
        }
        $sql .= ' order by id;';
        //echo $sql;die;
        $rowset = $this->db->fetchAll($sql, 1);
        return array('data' => $rowset, 'success' => 1);
    }
}