<?php

/**
 * Apkfile
 *  
 * @author lujun
 */

class PosmonitorSoa extends ModelSoa2
{
    //public $lookupfield = array(array('name','名称'),array('type','类型','50'),array('version','版本'),array('description','描述'));
    public $lookupfield = array('machineId');
    public $primaryKey = 'id';
    public $order = array('field'=>'id','direction'=>'desc');
    public $method = array(
        'index'     =>  'Posmonitor/search',
    );
}