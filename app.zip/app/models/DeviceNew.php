<?php

/**
 * Fitting
 *  
 * @author lujun
 */

class DeviceNew extends ModelBase1
{
    var $tableName = 't_bd_terminal';
    var $pareTable = array(
        'getColumns' => array('id','machineId','merchantNo','terminalNo','installAddress','regionId','modelId','modelName','mcc','ratesId','bankAccountId','longitude','latitude','operateBeginTime','operateEndTime','communicateWay','status','hardwareId','advertisementId','updateSwitch','paramUpdateSwitch','isAtmPos','modifier','posUpateTime','updateTime','createTime','nextCheckinTime','supplyType','contactsId','buyerId','buyerName','buyerRole','developerId','developerRole','deviceId','subOrderId','appTempId','sdkVer','middlePackageVer','basePackageVer','terminalId','unbindInfoId','cycleTime','useridalias','otaversion','apkinfo'),
        'lookupfield' => array('machineId')
    );
    
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
    );
    
    var $primaryKey = 'id';
    var $uniqueFields = array('machineId');
    
    public function findByPost($post, $get)
    {
        //print_r($post['param']);die;
        if($post['param']['groupid'] === 'null' || $post['param']['groupid'] === 'all')
            $post['param']['groupid'] = '';
        if($post['param']['useridalias'] == 0)
            $post['param']['useridalias'] = '';
        $this->_parseSql();
        $fields = ltrim($this->_selectField,',');
//         $fields .= ',aa.createTime as cytime,t_bd_group.name as groupname';
        $fields .= ',t_bd_group.name as groupname';
//         $aaTable = "SELECT id,machineId,createTime FROM (SELECT id,machineId,createTime FROM t_log_terminalexception ORDER BY createtime DESC) 
//             AS a  GROUP BY machineId ORDER BY createtime DESC";
//         $source = " FROM t_bd_terminal INNER JOIN t_auth_user ON t_bd_terminal.useridalias = t_auth_user.useridalias LEFT JOIN ({$aaTable}) 
//             as aa ON aa.machineId = t_bd_terminal.machineId left join t_bd_group on t_bd_group.id = t_bd_terminal.groupid ";
        $source = " FROM t_bd_terminal INNER JOIN t_auth_user ON t_bd_terminal.useridalias = t_auth_user.useridalias  left join t_bd_group on t_bd_group.id = t_bd_terminal.groupid ";
        $source_count = " FROM t_bd_terminal INNER JOIN t_auth_user ON t_bd_terminal.useridalias = t_auth_user.useridalias";
        $condition = " where 1 = 1 ";/* and T_BD_terminal.status = 1 ";*/
        if(isset($post['param'])){
            if($post['param']['modelId'] != '')
                $condition .= " and T_BD_terminal.modelId = {$post['param']['modelId']} ";
            if($post['param']['communicateWay'] != '')
                $condition .= " and T_BD_terminal.communicateWay = {$post['param']['communicateWay']} ";
            if($post['param']['groupid'] != '') {
                $groupId = $this->getGroupChild($post['param']['groupid']);
                $condition .= " and T_BD_terminal.groupid in({$groupId}) ";
            }
            if($post['param']['regionId'] != '') {
                if(substr($post['param']['regionId'], -4) == '0000'){
                    $paramReg = substr($post['param']['regionId'],0, 2);
                    $condition .= " and T_BD_terminal.regionId like '{$paramReg}%' ";
                } elseif(substr($post['param']['regionId'], -2) == '00'){
                    $paramReg = substr($post['param']['regionId'],0, 4);
                    $condition .= " and T_BD_terminal.regionId like '{$paramReg}%' ";
                } else{
                    $condition .= " and T_BD_terminal.regionId = '{$post['param']['regionId']}' ";
                }
            }
            if($post['param']['machineId'] != '')
                $condition .= " and T_BD_terminal.machineId like '%{$post['param']['machineId']}%' ";
        }
        
        $sql = "SELECT {$fields} {$source} {$condition} ";
      
        $count_sql = "SELECT COUNT(1) AS nrows {$source_count} {$condition} ";
      
        if($post['param']['useridalias'] != '') {
            $sql .= " and T_BD_terminal.useridalias = '{$post['param']['useridalias']}' ";
            $count_sql .= " and T_BD_terminal.useridalias = '{$post['param']['useridalias']}' ";
        } else {
            $sql .= $this->param(true);
            $count_sql .= $this->param(true);
        }
        //print_r($count_sql);die;
        /**
        $this->_parseSql();
        $fields = ltrim($this->_selectField,',');
        $sql = "SELECT {$fields} FROM {$this->qtable($this->getSource())} {$this->_externSql} WHERE 1=1 ";
        $count_sql = "SELECT COUNT(1) AS nrows FROM {$this->qtable($this->getSource())} {$this->_externSql} WHERE 1=1 ";
        //print_r();die;
        if (is_array($get) && !empty($get)) {
            foreach ($get as $k => $v) {
                if (in_array($k, $this->pareTable['getColumns']) ) {
                    $this->_bindParams[$k] = $v;
                    $sql .= " AND {$this->qfield($k, $this->qtable($this->getSource()))} = {$this->_bindParams[$k]}";
                    $count_sql .= " AND {$this->qfield($k, $this->qtable($this->getSource()))} = {$this->_bindParams[$k]}";
                }
            }
        }
        $sql .= $this->_getSearchSql($post['param']);
        $count_sql .= $this->_getSearchSql($post['param']);
        //print_r($sql);die;
        $sql .= $this->param(true);
        $count_sql .= $this->param(true);
        //print_r($count_sql);die;
        //$this->_logger->log($count_sql, \Phalcon\Logger::INFO);
        
        **/
        $count = $this->db->fetchOne($count_sql);
        if(!empty($post)){
            $sql .= " ORDER BY {$this->qfield($post['order']['field'])} {$post['order']['direction']}";
            //echo $sql;die;
            $offset = (intval($post['page']['pageNum'])-1)*intval($post['page']['pageSize']);
            $sql .= " limit {$offset},{$post['page']['pageSize']}";
        }
        //print_r($sql);
        //$this->_logger->log($sql, \Phalcon\Logger::INFO);
        $rowset = $this->db->fetchAll($sql, 1);
        //print_r($rowset);die;
        return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
    }
    
    public function group($post)
    {
        $sql = "select id, name,parentid from t_bd_group where 1 = 1";
        if($post['parentId'] === 'all') {
            return array('data' => '', 'success' => 1);
        }
        if($post['parentId'] != '') {
            $sql .= " and parentId = {$post['parentId']}";
        }
        if($post['regionGrade'] == 1){
            if($post['useridalias'] != '') {
                $sql .= " and useridalias = '{$post['useridalias']}' ";
            } else {
                $sql .= " and useridalias = '{$_SESSION['rbac']['idAlias']}' ";
            }
        }
        $sql .= " order by id;";
        //echo $sql;die;
        $rowset = $this->db->fetchAll($sql, 1);
        return array('data' => $rowset, 'success' => true);
    }
    
    public function getGroupChild($id){
        //f_queryChildren是在mysql里写的一个函数，其返回值类似‘$,2,55,33’
        $sql = "SELECT f_queryChildren({$id}) as aa;";
        $res = $this->db->fetchOne($sql, 1);
        $res = $res['aa'];
        $res = str_replace('$,', '', $res);
        return $res;
    }
    
    public function importTerminal($post)
    {
        if (PHP_SAPI == 'fpm-fcgi'){
            $data = json_decode($post['jsonStr'], true);
            $filename = str_replace('@', '', $data['filename']);
        } else {
            $filename = str_replace('@', '', $post['file']);
        }
        $fileExt = explode(".", $filename)[1];
        $res = $this->readExcel($filename, $fileExt);
        if(!$res['success']) {
            return array('success' => false, 'error' => 'Failed to read Excel file!');
        }
        if(empty($res['data'])) {
            return array('success' => false, 'error' => 'The Excel file is empty!');
        }
        $result = $this->insertTerminal($res['data'], $post['useridalias'], $post['groupid']);
        if(!$result['success']) {
            return array('success' => false, 'error' => 'Failed to write data to database!');
        } else {
            return array('success' => true, 'data' => $result['data']);
//            if($result['message'] != 0) {
//                return array('success' => true, 'error' => '但有'.$result['message'].'条存在的机身号没有被导入！');
//            }
//            return array('success' => true);
        }
    }
    
    public function index2($post)
    {
        header("Content-Type:text/html; charset=utf-8");
        //print_r($post);die;
        if($post['groupid'] === 'null' || $post['groupid'] === 'all') {
            $post['groupid'] = '';
        }
        if($post['modelId'] == "")
            $post['modelId'] = '0';
        if($post['communicateWay'] == "")
            $post['communicateWay'] = '0';
        $fields = 't_bd_terminal.id,t_bd_terminal.machineId,t_bd_terminal.merchantNo,t_bd_terminal.terminalNo,t_bd_terminal.installAddress,t_bd_terminal.regionId,t_bd_terminal.modelId,t_bd_terminal.modelName,t_bd_terminal.mcc,t_bd_terminal.ratesId,t_bd_terminal.bankAccountId,t_bd_terminal.longitude,t_bd_terminal.latitude,t_bd_terminal.operateBeginTime,t_bd_terminal.operateEndTime,t_bd_terminal.communicateWay,t_bd_terminal.status,t_bd_terminal.hardwareId,t_bd_terminal.advertisementId,t_bd_terminal.updateSwitch,t_bd_terminal.paramUpdateSwitch,t_bd_terminal.isAtmPos,t_bd_terminal.modifier,t_bd_terminal.posUpateTime,t_bd_terminal.updateTime,t_bd_terminal.createTime,t_bd_terminal.nextCheckinTime,t_bd_terminal.supplyType,t_bd_terminal.contactsId,t_bd_terminal.buyerId,t_bd_terminal.buyerName,t_bd_terminal.buyerRole,t_bd_terminal.developerId,t_bd_terminal.developerRole,t_bd_terminal.deviceId,t_bd_terminal.subOrderId,t_bd_terminal.appTempId,t_bd_terminal.sdkVer,t_bd_terminal.middlePackageVer,t_bd_terminal.basePackageVer,t_bd_terminal.terminalId,t_bd_terminal.unbindInfoId,t_bd_terminal.cycleTime,t_bd_terminal.useridalias,t_bd_terminal.otaversion,t_bd_terminal.apkinfo';
        $sql = ' select '.$fields.', t_auth_user.name as username from t_bd_terminal as t_bd_terminal ';
        $count_sql = ' select COUNT(1) AS nrows from t_bd_terminal ';
        $sql .= " left join t_bd_model on t_bd_model.id = t_bd_terminal.modelid ";
        $count_sql .= " left join t_bd_model on t_bd_model.id = t_bd_terminal.modelid ";
        $condition = " INNER JOIN t_auth_user ON t_bd_terminal.useridalias = t_auth_user.useridalias where t_bd_terminal.status = 1 ";
        $condition .= " and t_bd_model.modeltype = '{$post['modeltype']}' ";
        
        if($post['modelId'] != '0')
            $condition .= " and t_bd_terminal.modelId = '{$post['modelId']}' ";        
        if($post['communicateWay'] != '0')
            $condition .= " and t_bd_terminal.communicateWay = '{$post['communicateWay']}' ";
        if($post['modeltype'] != '1'){
            if($post['appTempId'] != NULL)
                $condition .= " and t_bd_terminal.appTempId = '{$post['appTempId']}' ";
            if($post['baseId'] != NULL)
                $condition .= " and t_bd_terminal.basePackageVer = (select t.version from t_app_package t where t.id = '{$post['appTempId']}') ";
            if($post['middleId'] != NULL)
                $condition .= " and t_bd_terminal.middlePackageVer = (select t.version from t_app_package t where t.id = '{$post['middleId']}') ";
            if($post['sdkId'] != NULL)
                $condition .= " and t_bd_terminal.sdkVer = (select t.version from t_app_package t where t.id = '{$post['sdkId']}') ";
        }
        if($post['groupid'] != '') {
            $groupId = $this->getGroupChild($post['groupid']);
            $condition .= " and t_bd_terminal.groupid in({$groupId}) ";
        }        
        
        if($post['regionId'] != ''){
            if(substr($post['regionId'], -4) == '0000'){
                $paramReg = substr($post['regionId'],0, 2);
                $condition .= " and T_BD_terminal.regionId like '{$paramReg}%' ";
            } elseif(substr($post['regionId'], -2) == '00'){
                $paramReg = substr($post['regionId'],0, 4);
                $condition .= " and T_BD_terminal.regionId like '{$paramReg}%' ";
            } else{
                $condition .= " and T_BD_terminal.regionId = '{$post['regionId']}' ";
            }
        }
        
        
        if(!empty($post['machineId2']))
            $condition .= " and t_bd_terminal.machineId like '%{$post['machineId2']}%' ";

        $userIdAlias = $_SESSION['rbac']['idAlias'];
        $userIdAlias_sql = "select userIdAlias from t_auth_user where userIdAlias like '{$userIdAlias}.%'";
        $userIdAlias_result = $this->db->fetchAll($userIdAlias_sql, 1);
        $ids = '';
        foreach ($userIdAlias_result as $key => $value) {
            $ids .= ",'" . $value['useridalias'] . "'";
        }
        $ids = $ids . ",'" . $userIdAlias . "'";
        $ids = substr($ids, 1);

        $condition .= " and t_bd_terminal.useridalias in ({$ids})";
        $sql .= $condition.$this->param(true);
        $count_sql .= $condition.$this->param(true);
        
        //echo $count_sql;die;
        $count = $this->db->fetchOne($count_sql);
        $sql .= "  ORDER BY {$post['orderField']} {$post['orderDirection']} ";
        //echo $sql;die;
        $offset = (intval($post['pageNum'])-1)*intval($post['numPerPage']);
        $sql .= " limit {$offset},{$post['numPerPage']}";
        //echo $sql;die;
        $rowset = $this->db->fetchAll($sql, 1);
        return array('totalRows' => $count['nrows'], 'data' => $rowset, 'success' => 1);
    }
    
    public function index3($post)
    {
    	//print_r($post['param']);die;
    	if($post['groupid'] === 'null' || $post['groupid'] === 'all')
    		$post['groupid'] = '';
    	if($post['useridalias'] == 0)
    		$post['useridalias'] = '';
    	$this->_parseSql();
//     	$fields = ltrim($this->_selectField,',');
    	$fields .= 't_bd_terminal.id,t_bd_terminal.machineId,t_bd_terminal.modelName,t_bd_terminal.buyerName,t_bd_terminal.cycleTime,t_auth_user.name as username,t_bd_group.name as groupname,t_l_terminal.termnoname as merterminalname,t_merchant.merchname as merchname';
    	$source = " FROM t_bd_terminal INNER JOIN t_auth_user ON t_bd_terminal.useridalias = t_auth_user.useridalias left join t_bd_group on t_bd_group.id = t_bd_terminal.groupid left join t_bd_model on t_bd_model.id = t_bd_terminal.modelid left join t_l_terminal on t_l_terminal.termno = t_bd_terminal.terminalNo left join t_merchant on t_merchant.merchno = t_bd_terminal.merchantNo ";
    	$source_count = " FROM t_bd_terminal INNER JOIN t_auth_user ON t_bd_terminal.useridalias = t_auth_user.useridalias";
    	$condition = " where 1 = 1 ";/* and T_BD_terminal.status = 1 ";*/
    	
    	if($post['keywords'] != '')
    		$condition .= " and T_BD_terminal.machineId like '%{$post['keywords']}%' ";
    	
    	
    	$sql = "SELECT {$fields} {$source} {$condition} ";
    	
    	$count_sql = "SELECT COUNT(1) AS nrows {$source_count} {$condition} ";
    	
    	if($post['useridalias'] != '') {
    		$sql .= " and T_BD_terminal.useridalias = '{$post['useridalias']}' ";
    		$count_sql .= " and T_BD_terminal.useridalias = '{$post['useridalias']}' ";
    	} else {
    		$sql .= $this->param(true);
    		$count_sql .= $this->param(true);
    	}
    	//print_r($count_sql);die;

    	$count = $this->db->fetchOne($count_sql);
    	if(!empty($post)){
    		$sql .= " ORDER BY {$post['orderField']} {$post['orderDirection']}";
    		//echo $sql;die;
    		$offset = (intval($post['pageNum'])-1)*intval($post['pageSize']);
    		$sql .= " limit {$offset},{$post['numPerPage']}";
    	}
    	//print_r($sql);die;
    	//$this->_logger->log($sql, \Phalcon\Logger::INFO);
    	$rowset = $this->db->fetchAll($sql, 1);
    	//print_r($rowset);die;
    	return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	//print_r($post);die;
//     	if($post['groupid'] === 'null' || $post['groupid'] === 'all') {
//     		$post['groupid'] = '';
//     	}
//     	if($post['modelId'] == "")
//     		$post['modelId'] = '0';
//     	if($post['communicateWay'] == "")
//     		$post['communicateWay'] = '0';
//     	$fields = 't_bd_terminal.id,t_bd_terminal.machineId,t_bd_terminal.modelName,t_bd_terminal.buyerName,t_bd_terminal.cycleTime,t_auth_user.name as username,t_bd_group.name as groupname,t_l_terminal.termnoname as merterminalname,t_merchant.merchname as merchname';
//     	$sql = ' select '.$fields.' from t_bd_terminal as t_bd_terminal ';
//     	$count_sql = ' select COUNT(1) AS nrows from t_bd_terminal ';
//     	$sql .= " left join t_bd_model on t_bd_model.id = t_bd_terminal.modelid ";
//     	$sql .= " left join t_bd_group on t_bd_group.id = t_bd_terminal.groupid ";
//     	$sql .= " left join t_l_terminal on t_l_terminal.termno = t_bd_terminal.terminalNo ";
//     	$sql .= " left join t_merchant on t_merchant.merchno = t_bd_terminal.merchantNo ";
//     	$count_sql .= " left join t_bd_model on t_bd_model.id = t_bd_terminal.modelid ";
//     	$count_sql .= " left join t_bd_group on t_bd_group.id = t_bd_terminal.groupid ";
//     	$count_sql .= " left join t_l_terminal on t_l_terminal.termno = t_bd_terminal.terminalNo ";
//     	$count_sql .= " left join t_merchant on t_merchant.merchno = t_bd_terminal.merchantNo ";
//     	$condition = " INNER JOIN t_auth_user ON t_bd_terminal.useridalias = t_auth_user.useridalias where t_bd_terminal.status = 1 ";
//     	$condition .= " and t_bd_model.modeltype = '{$post['modeltype']}' ";
    
//     	if($post['modelId'] != '0')
//     		$condition .= " and t_bd_terminal.modelId = '{$post['modelId']}' ";
//     	if($post['communicateWay'] != '0')
//     		$condition .= " and t_bd_terminal.communicateWay = '{$post['communicateWay']}' ";
//         if($post['modeltype'] != '1'){
//             		if($post['appTempId'] != NULL)
//             				$condition .= " and t_bd_terminal.appTempId = '{$post['appTempId']}' ";
//     		if($post['baseId'] != NULL)
//     	$condition .= " and t_bd_terminal.basePackageVer = (select t.version from t_app_package t where t.id = '{$post['appTempId']}') ";
//     			if($post['middleId'] != NULL)
//     					$condition .= " and t_bd_terminal.middlePackageVer = (select t.version from t_app_package t where t.id = '{$post['middleId']}') ";
//     							if($post['sdkId'] != NULL)
//     							$condition .= " and t_bd_terminal.sdkVer = (select t.version from t_app_package t where t.id = '{$post['sdkId']}') ";
//     	}
//     									if($post['groupid'] != '') {
//     									$groupId = $this->getGroupChild($post['groupid']);
//     									$condition .= " and t_bd_terminal.groupid in({$groupId}) ";
//     							}
    
//     									if($post['regionId'] != ''){
//     									if(substr($post['regionId'], -4) == '0000'){
//     	$paramReg = substr($post['regionId'],0, 2);
//     	$condition .= " and T_BD_terminal.regionId like '{$paramReg}%' ";
//     	} elseif(substr($post['regionId'], -2) == '00'){
//     	$paramReg = substr($post['regionId'],0, 4);
//     	$condition .= " and T_BD_terminal.regionId like '{$paramReg}%' ";
//     	} else{
//     	$condition .= " and T_BD_terminal.regionId = '{$post['regionId']}' ";
//     	}
//     	}
    
    
//     	if(!empty($post['machineId2']))
//     		$condition .= " and t_bd_terminal.machineId like '%{$post['machineId2']}%' ";
    
//     		$userIdAlias = $_SESSION['rbac']['idAlias'];
//     		$userIdAlias_sql = "select userIdAlias from t_auth_user where userIdAlias like '{$userIdAlias}.%'";
//     		$userIdAlias_result = $this->db->fetchAll($userIdAlias_sql, 1);
//     		$ids = '';
//     		foreach ($userIdAlias_result as $key => $value) {
//     		$ids .= ",'" . $value['useridalias'] . "'";
//     }
//     $ids = $ids . ",'" . $userIdAlias . "'";
//     $ids = substr($ids, 1);
    
//     $condition .= " and t_bd_terminal.useridalias in ({$ids})";
//     $sql .= $condition.$this->param(true);
//     $count_sql .= $condition.$this->param(true);
    
// //     echo $count_sql;die;
//     		$count = $this->db->fetchOne($count_sql);
//     				$sql .= "  ORDER BY {$post['orderField']} {$post['orderDirection']} ";
//     		//echo $sql;die;
//     		$offset = (intval($post['pageNum'])-1)*intval($post['numPerPage']);
//     		$sql .= " limit {$offset},{$post['numPerPage']}";
//     		//echo $sql;die;
//     		$rowset = $this->db->fetchAll($sql, 1);
//     		return array('totalRows' => $count['nrows'], 'data' => $rowset, 'success' => 1);
    }
    
    private function readExcel($filename, $exts = 'xls')
    {
        if ($exts == 'xls') {
            $PHPReader = new PHPExcel_Reader_Excel5();
        } else if ($exts == 'xlsx') {
            $PHPReader = new PHPExcel_Reader_Excel2007();
        }
        if (!$PHPReader->canRead($filename)){
            return array('success' => false, 'message' => 'Failed to read Excel file!');
        }
        $PHPExcel = $PHPReader->load($filename);
        $currentSheet = $PHPExcel->getSheet(0); //读取excel文件中的第一个工作表
        $allColumn = $currentSheet->getHighestColumn();//取得所有列
        $allRow = $currentSheet->getHighestRow();//取得一共有多少行
        if ($allRow > 101) {
            $ret = array('statusCode'=>'300', 'message'=>'Batch import data over 100');
            echo json_encode($ret);
            exit();
        }
//        $arr = array(1=>'A',2=>'B',3=>'C',4=>'D',5=>'E',6=>'F',7=>'G',8=>'H',9=>'I',10=>'J',11=>'K',12=>'L',13=>'M', 14=>'N',15=>'O',16=>'P',17=>'Q',18=>'R',19=>'S',20=>'T',21=>'U',22=>'V',23=>'W',24=>'X',25=>'Y',26=>'Z',27=>'AA',28=>'AB',29=>'AC',30=>'AD',31=>'AE',32=>'AF',33=>'AG',34=>'AH',35=>'AI',36=>'AJ',37=>'AK',38=>'AL',39=>'AM',40=>'AN',41=>'AO',42=>'AP',43=>'AQ');
//        $arr = array(
//            1 => 'A',       // 机身号
//            2 => 'B',       // 机型名称
//            3 => 'C',       // 所属用户ID
//            4 => 'D',       // 所属用户自定义组ID
//            5 => 'E',       // 终端号
//            6 => 'F',       // 商户终端名称
//            7 => 'G',       // 商户号
//            8 => 'H',       // 商户名称
//            9 => 'I',       // 商户拓展机构
//            10 => 'J',      // 报到周期
//            11 => 'K',      // 终端购买者名称
//            12 => 'L',      // 通信
//            13 => 'M'       // 状态
//            14 => 'N'       // 处理结果
//        );
        $arr = array(1 => 'A', 2 => 'B', 3 => 'C', 4 => 'D', 5 => 'E', 6 => 'F', 7 => 'G', 8 => 'H', 9 => 'I', 10 => 'J', 11 => 'K',12 => 'L', 13 => 'M', 14 => 'N');
        $iCount = array_keys($arr, $allColumn);
        $iCount = $iCount[0];
        $s = '';
        for($k='A';$k<='Z';$k++){
            $s .= $k.' ';
        }
        $arr = explode(' ',$s);
        for ($currentRow = 2; $currentRow <= $allRow; $currentRow++) {
            //从哪列开始，A表示第一列
             for ($currentColumn = 0; $currentColumn < $iCount; $currentColumn++) {
                 //数据坐标
                 $address = $arr[$currentColumn] . $currentRow;
                 //读取到的数据，保存到数组$arr中
                 $data[$currentRow][$arr[$currentColumn]] = $currentSheet->getCell($address)->getValue();
             }
        }
        return array('success' => true, 'data' => $data);
    }
    
    private function insertTerminal($post,$useridalias,$groupid)
    {
        $c_userIdAlias = $_SESSION['rbac']['idAlias'];
        $message = " ";
        foreach ($post as $key => $val) {
            $f_merchant_exist = true;
            $f_terminal_merchant_exist1 = true;
            // 机身号，必填
            if ($val['A'] == '') {
                $message = "The SN can't be empty";
                $a_result[$key] = array(
                    'status' => 'false',
                    'message' => $message
                );
                continue;
            } elseif (strlen($val['A']) != 11){
            	$message = "The SN invalid";
            	$a_result[$key] = array(
            			'status' => 'false',
            			'message' => $message
            	);
            	continue;
            }
            $f_machine = "select machineId from t_bd_terminal where machineId='{$val['A']}'";
            $ret_machine = $this->db->fetchOne($f_machine, 1);
            if ($ret_machine) {
                $message = "SN repeated";
                $a_result[$key] = array(
                    'status' => 'false',
                    'message' => $message
                );
                continue;
            }
            $i_machineId = $val['A'];

            // 机型，必填
            if ($val['B'] == '') {
                $message = "The machine type cannot be empty";
                $a_result[$key] = array(
                    'status' => 'false',
                    'message' => $message
                );
                continue;
            }
            $f_devicetype = "select id,name from t_bd_model where name='{$val['B']}'";
            $ret_devicetype = $this->db->fetchOne($f_devicetype, 1);
            if (!$ret_devicetype) {
                $message = "The machine type doesn't exist";
                $a_result[$key] = array(
                    'status' => 'false',
                    'message' => $message
                );
                continue;
            }
            $i_modelId = $ret_devicetype['id'];
            $s_modelName = $ret_devicetype['name'];

            // 所属用户ID, 选填，必须存在 t_auth_user 且为当前导入用户或其子级用户
            if ($val['C'] != '') {
                $f_user = "select id,userIdAlias from t_auth_user where userIdAlias='{$c_userIdAlias}' or userIdAlias like '%{$c_userIdAlias}.%'";
                $ret_user = $this->db->fetchAll($f_user, 1);
                foreach ($ret_user as  $value) {
                    $user['id'][] = $value['id'];
                    $user['useridAlias'][] = $value['useridalias'];
                }
                if (!in_array($val['C'], $user['id'])) {
                    $message = "User ID error, please enter current user ID or sublevel user";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                }

                $d_user = "select userIdAlias from t_auth_user where id={$val['C']}";
                $ret_user = $this->db->fetchOne($d_user, 1);
                $s_useridalias = $ret_user['useridalias'];
            } else {
                $s_useridalias = $c_userIdAlias;
            }

            // 所属用户自定义用户组ID,选填，必须存在 t_bd_group 且为当前用户或为其子级用户创建
            if ($val['D'] != '') {
                $f_group = "select id from t_bd_group where id={$val['D']} and (useridalias='{$c_userIdAlias}' or useridalias like '%{$c_userIdAlias}.')";
                $ret_group = $this->db->fetchOne($f_group, 1);
                if (!$ret_group) {
                    $message = "The user that belongs to the user group defines the user group ID error, please enter the user group ID created by the current user or sublevel user";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                }
                $i_groupid = $val['D'];
            } else {
                $i_groupid = 0;
            }

            // 终端号，选填，数字
            if ($val['E'] != '') {
                if ($val['F'] == '') {
                    $message = "The merchant terminal name cannot be empty";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                } elseif ($val['G'] == '') {
                    $message = "Merchant Number cannot be empty";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                } elseif ($val['H'] == '') {
                    $message = "Merchant name cannot be empty";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                }
                $s_terminalNo = (string)$val['E'];
            } else {
                $s_terminalNo = '';
            }

            // 终端名称，选填
            if ($val['F'] != '') {
                if ($val['E'] == '') {
                    $message = "Terminal number cannot be empty";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                } elseif ($val['G'] == '') {
                    $message = "Merchant Number cannot be empty";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                } elseif ($val['H'] == '') {
                    $message = "Merchant name cannot be empty";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                }
                $s_terminalName = (string)$val['F'];
            } else {
                $s_terminalName = '';
            }

            // 商户号，选填，数字
            if ($val['G'] != '') {
                if ($val['E'] == '') {
                    $message = "Terminal number cannot be empty";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                } elseif ($val['F'] == '') {
                    $message = "The merchant terminal name cannot be empty";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                } elseif ($val['H'] == '') {
                    $message = "Merchant name cannot be empty";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                }
                $s_merchantNo = (string)$val['G'];
            } else {
                $s_merchantNo = '';
            }

            // 商户名称, 选填
            if ($val['H'] != '') {
                if ($val['E'] == '') {
                    $message = "Terminal number cannot be empty";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                } elseif ($val['F'] == '') {
                    $message = "The merchant terminal name cannot be empty";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                } elseif ($val['G'] == '') {
                    $message = "Merchant Number cannot be empty";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                }
                $s_merchantName = (string)$val['H'];
            } else {
                $s_merchantName = '';
            }
            // 商户拓展机构，选填，不严格校验
            $s_organization = $val['I'] ? (string)$val['I'] : '';

            // 终端号、终端名称、商户号、商户名称联合校验,数据同时存在或同时不存在
            if ($val['E'] != '') {
                $f_machine_ter_merchant = "select merchantNo,terminalNo from t_bd_terminal where merchantNo='{$s_merchantNo}' and terminalNo='{$s_terminalNo}';";
                $d_machine_ter_merchant = $this->db->fetchOne($f_machine_ter_merchant, 1);
                if ($d_machine_ter_merchant) {
                    $message = "The terminal under the merchant number is associated with the fuselage";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                }

//                $f_terminalNo = "select terminalNo from t_bd_terminal where terminalNo='{$val['E']}'";
//                $ret_terminalNo = $this->db->fetchOne($f_terminalNo, 1);
//                if ($ret_terminalNo) {
//                    $message = "商户终端号不能重复，终端号已关联设备";
//                    $a_result[$key] = array(
//                        'status' => 'false',
//                        'message' => $message
//                    );
//                    continue;
//                }
                $f_merchant = "select mersid,merchno,merchname from t_merchant where merchno='{$s_merchantNo}'";
                $ret_merchant = $this->db->fetchOne($f_merchant, 1);
                if (!$ret_merchant) {
                    // 商户信息不存在
                    $f_merchant_exist = false;
                    // 商户和终端关联关系不存在
                    $f_terminal_merchant_exist1 = false;
                } else {
                    $s_mersid = $ret_merchant['mersid'];
                    $f_terminal_merchant = "select termno,mersid,termnoname from t_l_terminal where termno='{$s_terminalNo}' and mersid={$s_mersid}";
                    $ret_terminal_merchant = $this->db->fetchOne($f_terminal_merchant, 1);
                    // 商户信息校验
                    if ($ret_merchant['merchname'] != $s_merchantName) {
                        $message = "Merchant number and merchant name do not match";
                        $a_result[$key] = array(
                            'status' => 'false',
                            'message' => $message
                        );
                        continue;
                    }
                    // 商户终端信息校验
                    if ($ret_terminal_merchant) {
                        if ($ret_terminal_merchant['termnoname'] != $s_terminalName) {
                            $message = "Terminal number and merchant terminal name do not match";
                            $a_result[$key] = array(
                                'status' => 'false',
                                'message' => $message
                            );
                            continue;
                        }
//                        if ($ret_terminal_merchant['mersid'] != $ret_merchant['mersid']) {
//                            $message = "终端号不能关联多个商户";
//                            $a_result[$key] = array(
//                                'status' => 'false',
//                                'message' => $message
//                            );
//                            continue;
//                        }
                    } else {
                        // 商户和终端关联关系不存在
                        $f_terminal_merchant_exist1 = false;
                    }
                }
            }

            // 报到周期，选填，默认 1440 分钟，大于等于 60 分钟
            if ($val['J'] != '') {
                if (!is_numeric($val['J'])) {
                    $message = "Report cycle error, please enter an integer";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                }
                if ($val['J'] < 60) {
                    $message = "Report cycle error, please enter more than 60 minutes";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                }
                $i_cycleTime = (int)$val['J'];
            } else {
                $i_cycleTime = 1440;
            }

            // 终端购买者名称，选填
            if ($val['K'] != '') {
                $s_buyerName = (string)$val['K'];
            } else {
                $s_buyerName = '';
            }

            // 通信，选填，默认不限
            if ($val['L'] != '') {
                if (!is_numeric($val['L']) || !in_array((int)$val['L'], array(1, 2, 3, 4, 5), true)) {
                    $message = "Communication mode error, state: 1: Telephone, 2: Mobile, 3: Network, 4: Unicom, 5: Telecom";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                }
                $i_communicateWay = (int)$val['L'];
            } else {
                $i_communicateWay = 0;
            }

            // 状态，选填，默认启动
            if ($val['M'] != '') {
                if (!is_numeric($val['M']) || !in_array((int)$val['M'], array(0, 1), true)) {
                    $message = "Device status error, status: 0: Eeactivated, 1: Enabled";
                    $a_result[$key] = array(
                        'status' => 'false',
                        'message' => $message
                    );
                    continue;
                }
                $i_status = (int)$val['M'];
            } else {
                $i_status = 1;
            }

            /**
             ****************************************************************************
             *      数据校验
             * 1. 导入机身号必须在 t_bd_terminal 表不存在
             * 2. 导入的机型必须在 t_bd_model 存在
             * 3. 如果导入数据存在商户号，必须存在 t_merchant 表中
             * 4. 如果导入数据存在终端号，必须在 t_l_terminal 表不存在
             * 5. 如果数据都验证通过，需要在 t_bd_terminal 插入数据，如果商户号和终端号也验证
             * 通过，需要在 t_l_terminal 也插入一条数据
             * 6. 所属用户ID 必须有效，数据有效而且是当前导入用户或子级用户 否则无法导入
             * 7. 所属用户自定组 必须有效，数据有效而且是当前用户创建
             *
             * **************************************************************************
             */
            $s_time = date('Y-m-d H:i:s');
            // 商户信息不存在
            if (!$f_merchant_exist && $val['G'] != '') {
                $f_merchant_exist_sql = "insert into t_merchant(merchno,merchname,merchanttype,modifydate,userIdAlias,organization) values('{$s_merchantNo}', '{$s_merchantName}', '0001', '{$s_time}', '{$s_useridalias}', '{$s_organization}')";
                $this->db->execute($f_merchant_exist_sql);
                $s_mersid = $this->db->lastInsertId();
            }
            // 商户和终端信息不存在
            if (!$f_terminal_merchant_exist1 && $val['G'] != '' && $val['E'] != '') {
                $f_terminal_merchant_exist1_sql = "insert into t_l_terminal(termno,modifydate,mersid,termnoname,userIdAlias) values('{$s_terminalNo}', '{$s_time}', '{$s_mersid}', '{$s_terminalName}', '{$s_useridalias}')";
                $this->db->execute($f_terminal_merchant_exist1_sql);
            }
            // 商户信息存在但终端信息不存在
//            if (!$f_terminal_merchant_exist2 && $val['E'] != '') {
//                $f_terminal_merchant_exist_sql = "insert into t_l_terminal(termno,modifydate,mersid,termnoname,userIdAlias) values('{$s_terminalNo}', '{$s_time}', '{$s_mersid}', '{$s_terminalName}', '{$s_useridalias}')";
//                $this->db->execute($f_terminal_merchant_exist_sql);
//            }
            $f_terminal_sql = "insert into t_bd_terminal(machineId,merchantNo,terminalNo,modelId,modelName,communicateWay,status,posUpateTime,updateTime,createTime,buyerName,cycleTime,useridalias,groupid) values('{$i_machineId}', '{$s_merchantNo}', '{$s_terminalNo}', {$i_modelId}, '{$s_modelName}', {$i_communicateWay}, {$i_status}, '0000-00-00 00:00:00', '0000-00-00 00:00:00','{$s_time}', '{$s_buyerName}', {$i_cycleTime}, '{$s_useridalias}', {$i_groupid})";
            $this->db->execute($f_terminal_sql);
            $a_result[$key] = array(
                'status' => 'true',
                'message' => 'Import success'
            );
        }

        return array('success' => true, 'message' => 0, 'data' => $a_result);
    }
    
    public function hasTerminal($sn,$act,$id)
    {
        if($act == 'add')
            $sql = "select machineId from {$this->tableName} where machineId = '{$sn}';";
        if($act == 'upd')
            $sql = "select machineId from {$this->tableName} where machineId = '{$sn}' and id != {$id};";
        //echo $sql;die;
        $res = $this->db->fetchAll($sql,1);
        if(empty($res))
            return false;
        return true;
    }
    
    public function getModelId($modelName)
    {
        $sql = "select id from t_bd_model where name = '{$modelName}';";
        $sql .= $this->param();
        $res = $this->db->fetchOne($sql);
        if(empty($res))
            return '';
        return $res['id'];
    }
    
    public function getModelName($modelId)
    {
        $sql = "select name from t_bd_model where id = {$modelId};";
        $res = $this->db->fetchOne($sql);
        if(empty($res))
            return '';
        return $res['name'];
    }
    
    public function merchantInfo($post)
    {
        $sql = "SELECT t_merchant.merchno,t_merchant.merchname,t_merchant.merchanttype,t_merchant.address,t_merchant.phoneno,t_l_terminal.termno,t_l_terminal.termnoname FROM t_bd_terminal LEFT JOIN t_merchant ON t_bd_terminal.merchantno = t_merchant.merchno LEFT JOIN t_l_terminal ON t_l_terminal.termno = t_bd_terminal.terminalNo WHERE t_bd_terminal.machineId = '{$post['machineId']}';";
        $res = $this->db->fetchOne($sql);
        return array('success' => true, 'data' => $res);
    }
    
    public function save($post)
    {
        if($this->hasTerminal($post['machineId'],$post['act'],$post['id'])) {
            return array("status" => array('success' => false, 'message' => 'SN:'.$post['machineId'].' data already exists'));
        } else {
            if('add' === $post['act']) {
                if($this->insertByPost($post)) {
                    $result = array('status' => array('success' => true,'message' => 'Add Success!'));
                    $this->_afterCreateDb($post);
                } else {
                    $result = array('status' => array('success' => false,'message' => 'Add Failed!','errorCode' => 0));
                }
            } elseif('upd' === $post['act']) {
                if($this->updateByPost($post)) {
                    $result = array('status' => array('success' => true,'message' => 'Update Success !'));
                    $this->_afterUpdateDb($this->getData($post));
                } else {
                    $result = array('status' => array('success' => false,'message' => 'Update Failed !','errorCode' => 0));
                }
            } else {
                $result = array('status' => array('success' => 0,'message' => 'Error!','errorCode' => 1));
            }
        }
        return $result;
    }
    
    public function insertByPost($post)
    {
        $sql = "insert into {$this->tableName}(machineId,merchantNo,terminalNo,installAddress,regionId,modelId,modelName,mcc,ratesId,bankAccountId,longitude,latitude,operateBeginTime,operateEndTime,communicateWay,status,hardwareId,advertisementId,updateSwitch,paramUpdateSwitch,isAtmPos,modifier,posUpateTime,updateTime,createTime,nextCheckinTime,supplyType,contactsId,buyerId,buyerName,buyerRole,developerId,developerRole,deviceId,subOrderId,appTempId,sdkVer,middlePackageVer,basePackageVer,terminalId,unbindInfoId,cycleTime,groupid,useridalias) values ";
        $post['modelName'] = $this->getModelName($post['modelId']);
        if($post['cycleTime'] == '') {
            $post['cycleTime'] = '1440';
        } elseif($post['cycleTime'] > 99999999) {
            $post['cycleTime'] = '99999999';
        } elseif($post['cycleTime'] < 60){
            $post['cycleTime'] = '60';
        }
        if ($post['user_id'] == '') {
            $s_useridAlias = $post['useridalias'];
        } else {
            $f_user = "select userIdAlias from t_auth_user where id={$post['user_id']}";
            $d_user = $this->db->fetchOne($f_user, 1);
            $s_useridAlias = $d_user['useridalias'];
        }
        $post['merchantNo'] = $post['model1_merchno'];
        $post['terminalNo'] = $post['model1_termno'];
        $post['groupid'] = $post['model_groupid'];
        $post['updateSwitch'] = $post['status'];
        $sql .= "('{$post['machineId']}','{$post['merchantNo']}','{$post['terminalNo']}','{$post['installAddress']}','{$post['regionId']}','{$post['modelId']}','{$post['modelName']}','{$post['mcc']}','{$post['ratesId']}','{$post['bankAccountId']}','{$post['longitude']}','{$post['latitude']}','{$post['operateBeginTime']}','{$post['operateEndTime']}','{$post['communicateWay']}','{$post['status']}','{$post['hardwareId']}','{$post['advertisementId']}','{$post['updateSwitch']}','{$post['paramUpdateSwitch']}','{$post['isAtmPos']}','{$post['modifier']}','{$post['posUpateTime']}','{$post['updateTime']}','{$post['createTime']}','{$post['nextCheckinTime']}','{$post['supplyType']}','{$post['contactsId']}','{$post['buyerId']}','{$post['buyerName']}','{$post['buyerRole']}','{$post['developerId']}','{$post['developerRole']}','{$post['deviceId']}','{$post['subOrderId']}','{$post['appTempId']}','{$post['sdkVer']}','{$post['middlePackageVer']}','{$post['basePackageVer']}','{$post['terminalId']}','{$post['unbindInfoId']}','{$post['cycleTime']}','{$post['groupid']}','{$s_useridAlias}');";
        return $this->db->execute($sql);
    }
    
    public function findByPk($pk)
    {
        $sql = "select t.id,t.machineId,t.merchantNo,t.terminalNo,t.modelId,t.useridalias,t.groupid,t.buyerName,t.communicateWay,t.status,t.cycleTime,t1.name as groupname,m.merchname,t2.termnoname,u.id as userid,u.name as username from t_bd_terminal t left join t_bd_group t1 on t.groupid = t1.id left join t_merchant m on t.merchantNo = m.merchno left join t_l_terminal t2 on t.terminalNo = t2.termno left join t_auth_user u on u.userIdAlias = t.useridalias where t.id = {$pk} ";
        //echo $sql;die;
        $result= $this->db->fetchOne($sql, 1);
        if(!empty($result)){
            return array('status' => array('success' => true),'result' => $result);
        } else{
            return array('status' => array('success' => false, 'errorCode' => 0, 'message' => 'The result is null!'));
        }
    }
    
    public function updateByPost($post)
    {
        $f_terminal = "select * from t_bd_terminal where id={$post['id']}";
        $d_terminal = $this->db->fetchOne($f_terminal, 1);
        $modelName = $this->getModelName($post['modelId']);
        if ($post['user_id'] == '') {
            if ($f_terminal['useridalias'] == '') {
                $s_useridAlias = $post['useridalias'];
            } else {
                $s_useridAlias = $d_terminal['useridalias'];
            }
        } else {
            $f_user = "select userIdAlias from t_auth_user where id={$post['user_id']}";
            $d_user = $this->db->fetchOne($f_user, 1);
            $s_useridAlias = $d_user['useridalias'];
        }
        $sql = "update t_bd_terminal set machineId = '{$post['machineId']}',merchantNo = '{$post['model1_merchno']}',terminalNo = '{$post['model1_termno']}',modelId = '{$post['modelId']}',useridalias = '{$s_useridAlias}',groupid = '{$post['model_groupid']}',buyerName = '{$post['buyerName']}',communicateWay = '{$post['communicateWay']}',status = '{$post['status']}',updateSwitch = '{$post['status']}',cycleTime = '{$post['cycleTime']}',modelName = '{$modelName}' where id = {$post['id']} ";
        //error_log($sql."\r\n",3,"../log/xtms.log");  
        return $this->db->execute($sql);
    }
    
    public function apkinfo($post)
    {
        $sql = "select apkinfo from t_bd_terminal where machineid = '{$post['machineId']}';";
        $result= $this->db->fetchOne($sql, 1);
        return $result['apkinfo'];
    }
}