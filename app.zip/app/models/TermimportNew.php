<?php

/**
 * merchant Termimport
 *  
 * @author lujun
 */

class TermimportNew extends ModelBase1
{
    var $tableName = 'T_L_TERMINAL';
    var $pareTable = array(
        'getColumns'=>array('ltermid','termno','termnoname','status','opruser','modifydate','mersid','userIdAlias'),
        'lookupfield'=>array('termno','termnoname')
    );
    var $foreignTable = array(
        'mersid' => array(
            'tableName' => 't_merchant',
            'mappingKey' => 'mersid',
            'displayKey' => array('merchname','merchno'),
            'externKeys' => array()
        ),
    );
    
    var $primaryKey = 'ltermid';
    var $order = array('field'=>'ltermid','direction'=>'desc');
    
    public function getSource()
    {
        return 'T_L_TERMINAL';
    }
    
    public function getPK()
    {
        return 'ltermid';
    }
}