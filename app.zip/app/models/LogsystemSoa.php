<?php

/**
 * Logsystem
 *  
 * @author zhaimin
 * @version 1.0
 */

class LogsystemSoa extends ModelSoa
{
    public $primaryKey = 'id';
    public $order = array('field'=>'transactionTime','direction'=>'desc');
    public $method = array(
    	'index'	=> 'logmanage/getSysLog'
    );
}

