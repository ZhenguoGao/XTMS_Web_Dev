<?php

/**
* 终端上送状态
* lujun
*/
class TerminalexceptionNew extends ModelBase1
{
    var $tableName = 't_log_terminalexception';
    var $pareTable = array(
        'getColumns'=>array('id','machineId','exceptionFlag','exceptionInfo','isSolved','planId','createTime'),
        'lookupfield'=>array('machineId'),
    );
    
    var $foreignTable = array(
        'machineId' => array(
            'tableName' => 't_bd_terminal',
            'mappingKey' => 'machineId',
            'displayKey' => array('machineId as aaa'),
        ),
    );
    
    var $primaryKey = 'id';
    var $order = array('field'=>'id','direction'=>'desc');
}