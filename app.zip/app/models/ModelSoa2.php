<?php

class ModelSoa2 extends ModelSoa {
    public $method =array();
    public $primaryKey = '';
    public $lookupSearchfield = array();


    public function getLookupSearchField()
    {
        return $this->lookupSearchfield;
    }


    //根据POST过来的数据提取查询条件查询记录
    function findByPost($post)
    {
        $Num = $post['pageNum']!='' ? $post['pageNum'] : 1;
        $numPer = !empty($post['numPerPage']) ? $post['numPerPage'] : 20;
        $data['page']['pageNum']=intval($Num);
        $data['page']['pageSize']=intval($numPer);
        $data['order']['field']=$post['orderField'];
        $data['order']['direction']=$post['orderDirection'];
        unset($post['pageNum'],$post['numPerPage'],$post['orderField'],$post['orderDirection']);
        if(!empty($post)) {
            foreach($post as $k=>$v) {
                $v = trim($v);
                if($v!=='' && $v!==null) {
                    $data['param'][$k] = $v;
                }
            }
        }
        return $this->execute($data,'index');
    }

    //根据主键获取信息
    function findByPk($pk)
    {
        return $this->execute(array('param'=>array($this->primaryKey=>$pk)),'get');
    }

    //根据主键删除信息
    function remove($pk)
    {
        return $this->execute(array('param'=>array($this->primaryKey=>$pk)),'delete');
    }

    //保存添加或者编辑
    function postSave($post)
    {
        $method = '';
        if($post['act']=='add')
            $method = 'add';
        elseif($post['act']=='upd')
            $method = 'update';
        else
            die(json_encode(array('statusCode'=>300,'message'=>'Error!')));
        unset($post['act']);
        return $this->execute(array('param'=>$post),$method);
    }
}