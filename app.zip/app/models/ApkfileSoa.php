<?php

/**
 * Apkfile
 *  
 * @author lujun
 */

class ApkfileSoa extends ModelSoa2
{
    //public $lookupfield = array(array('name','名称'),array('type','类型','50'),array('version','版本'),array('description','描述'));
	public $lookupfield = array('filename','nickname','package','modelname','versionname');
	public $replacevalue = array(
        'type' => array('1'=>'ota','2'=>'apk')
    );
    public $primaryKey = 'id';
    public $order = array('field'=>'id','direction'=>'desc');
    /**
    public $method = array(
        'index'     =>	'spos/getApp',
        'add'       =>	'spos/addApp',
        'update'    =>	'spos/modifyApp',
        'delete'    =>	'spos/removeApp',
        'get'       =>	'spos/getAppById'
    );
    **/
    public $method = array(
        'index'     =>	'Apkfile/search',
        'add'       =>	'apk/add',
        'update'    =>	'Apkfile/modify',
        'delete'    =>	'apk/remove',
        'get'       =>	'Apkfile/detail'
    );
    
    public function postSave($post)
    {
        $post['jsonStr'] = json_encode($this->formatPost($post));
        $request = new \Phalcon\Http\Request();
        $post['clientIp'] = $request->getClientAddress();
        $config = $this->config;
        $server = $this->server ? $this->server:'soa';
        $url = "{$config->$server}{$this->method['add']}";
        if(version_compare(PHP_VERSION, '5.5.0', '>=')){
            $post['file'] = new CURLFile(realpath('../'.$post['uploadfile']));
            if ($post['filelogo'] != '')
                $post['file1'] = new CURLFile(realpath('../'.$post['uploadfilelogo']));
            else
                $post['file1'] = '';
        }else{
            $post['file'] = '@'.realpath('../'.$post['uploadfile']);
            if ($post['filelogo'] != '')
                $post['file1'] = '@'.realpath('../'.$post['uploadfilelogo']);
            else
                $post['file1'] = '';
        }
        
        //print_r($post);die;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $tmpInfo = curl_exec($ch);
        //var_dump(curl_error($ch));die;
        if ($tmpInfo === false) {
            $msgerr = 'Error：'.curl_error($ch);
            curl_close($ch);
            
            exit(json_encode(array("statusCode"=>300,"message"=>$msgerr)));
        }
        curl_close($ch);
        //print_r(json_decode($tmpInfo,true));die;
        return json_decode($tmpInfo,true);
    }
    
    public function remove($pk){
        $post = array('param'=>array('id'=>$pk));
        $method = $this->method['delete'];
        $post_string = 'clientIp='.$_SERVER["REMOTE_ADDR"].'&jsonStr='.urlencode(json_encode($this->formatPost($post)));
        //print_r($method);die;
        $server = $this->server? $this->server:'soa';
        $url = "{$this->config->$server}{$method}";
        $curl = curl_init();  // 启动一个CURL会话
        curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
        // curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1); // 从证书中检查SSL加密算法是否存在，已废弃
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2); // 从证书中检查SSL加密算法是否存在
        curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转
        curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer
        curl_setopt($curl, CURLOPT_POST, 1); // 发送一个常规的Post请求
        curl_setopt($curl, CURLOPT_POSTFIELDS, $post_string); // Post提交的数据包
        curl_setopt($curl, CURLOPT_TIMEOUT, 30); // 设置超时限制防止死循环
        curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回
        $tmpInfo = curl_exec($curl); // 执行操作
        if (curl_errno($curl)) {
            $data = array('status'=>false, 'data'=>array("statusCode"=>300,"message"=>'Error：'.curl_error($curl), "error"=>curl_error($curl)));
        }else{
            //过滤非法字符
            $data = array('status'=>true, 'data'=>json_decode(strtr($tmpInfo,array("\r"=>' ',"\t"=>' ')), true));
        }
        curl_close($curl); // 关闭CURL会话
        //return $data; // 返回数据
        //print_r($data);die;
        if(false === $data['status']){
            exit(json_encode($data['data'], true));
        }
        return $data['data'];
    }
}