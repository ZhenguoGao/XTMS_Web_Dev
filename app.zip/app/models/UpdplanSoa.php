<?php

/**
 * UpdplanSoa
 *  
 * @author zhaimin
 */

class UpdplanSoa extends ModelSoa2
{
    public $primaryKey = 'id';
    public $order = array('field'=>'beginTime','direction'=>'desc');
    /**
    public $method = array(
    	'index'             =>	'plan/get',
        'add'               =>	'plan/add',
    	'delete'            =>	'plan/del',
    	'get'               =>	'planEntry/getPlanID',
    	'statistics'        =>	'planEntry/total',
    	'canceldetail'      =>	'planEntry/modify',
    	'getTerminalInfos'  =>	'plan/getTerminalInfos',
    	'exportdetail'      =>	'planEntry/exportPlan'
    );
    **/
    public $method = array(
        'index'             =>	'updplan/search',
        'add'               =>	'updplan/add',
    	'addDevice'         =>  'updplan/addDevice',
        'delete'            =>	'updplan/remove',
        'get'               =>	'updplan/getPlanID',
        'statistics'        =>	'updplan/total',
        'canceldetail'      =>	'updplan/cancel',
        'getTerminalInfos'  =>	'updplan/getTerminalInfos',
        'exportdetail'      =>	'updplan/exportPlan',
    );

    public function detail($post)
    {
    	$Num = $post['pageNum']!='' ? $post['pageNum'] : 1;
        $numPer = !empty($post['numPerPage']) ? $post['numPerPage'] : 20;
        $post['pageNum']=intval($Num);
        $post['pageSize']=intval($numPer);
        return $this->execute($post,'get');
    }
}