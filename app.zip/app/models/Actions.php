<?php

/**
 * Actions
 *  
 * @author huanggz
 * @version 1.0
 */

class Actions extends Phalcon\Mvc\Model
{
	/**
	 * define table name 
	 */
    public function getSource() 
    {
    	return 'actions';
    }
    
}