<?php

/**
 * LogupdateSoa
 *  
 * @author lujun
 * @version 1.0
 */

class LogupdateNew extends ModelBase1
{
    var $tableName = 't_log_terminalupgrade';
    var $pareTable = array(
        'getColumns'=>array('id','machineId','startTime','endTime','fileSize','totalTime','filenames','upgradeTime',
            'planID','flux','downNum','ignoreNum','needNum','time as downTimes','status as downStatus','terminalId'),
        'lookupfield'=>array('name')
    );
    
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
    );
    var $primaryKey = 'id';
    
    public function findByPost($post, $get)
    {
        $sql = "SELECT upd.id, upd.startTime, upd.endTime, upd.fileSize, upd.totalTime, upd.filenames, upd.upgradeTime, upd.planID, upd.flux, upd.downNum, upd.ignoreNum, upd.needNum, upd.time as downTimes, upd.status as downStatus, upd.terminalId, ter.machineId, ter.merchantNo, ter.terminalNo, ter.communicateWay, ter.modelName, upd.planName as planName FROM t_log_terminalupgrade upd INNER JOIN t_bd_terminal ter on upd.terminalId = ter.id LEFT JOIN t_upd_plan plan on plan.id = upd.planID WHERE 1 = 1 ";
        $sql .= " and (ter.useridalias like '{$_SESSION['rbac']['idAlias']}.%' or ter.useridalias = '{$_SESSION['rbac']['idAlias']}') ";
        if(!empty($post['param'])){
            if($post['param']['machineId'] != '')
                $sql .= " and ter.machineId LIKE '%{$post['param']['machineId']}%' ";
            if($post['param']['planName'] != '')
                $sql .= " and plan.name LIKE '%{$post['param']['planName']}%' ";
            if($post['param']['planEntryStatus'] != '')
                $sql .= " and upd.status = {$post['param']['planEntryStatus']} ";
            if($post['param']['communicateWay'] != '')
                $sql .= " and ter.communicateWay = {$post['param']['communicateWay']} ";
        }
        $sql .= " group by upd.planID,ter.machineId ";
        $count_sql = "SELECT COUNT(1) AS nrows FROM ({$sql}) tmp_count;";
    
        $count = $this->db->fetchOne($count_sql);
        if(!empty($post)) {
            $sql .= " ORDER BY {$this->qfield($post['order']['field'])} {$post['order']['direction']}";
            $offset = (intval($post['page']['pageNum'])-1)*intval($post['page']['pageSize']);
            $sql .= " limit {$offset},{$post['page']['pageSize']}";
        }
        $rowset = $this->db->fetchAll($sql, 1);
        return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
    }
    
    public function findByPk($pk)
    {
        $sql = "SELECT id, parentId, appName, fileName, size0, size1, size2,flux, time, status, createTime, updateTime 
            FROM t_log_terminalupgradedetail WHERE parentId = {$pk};";
        $result= $this->db->fetchAll($sql, 1);
        if(!empty($result)){
            return array('status' => array('success' => 1),'data' => $result);
        } else{
            return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => 'The result is null!'));
        }
    }
    
    public function getUpgradeLogByMachineId($post)
    {
        $sql = "SELECT id, machineId, merchantNo, terminalNo,startTime,IF(endTime = '0000-00-00 00:00:00', '', endTime) AS endTime, 
            fileSize, flux, STATUS FROM t_log_terminalupgrade WHERE t_log_terminalupgrade.machineId = '{$post['machineId']}' ORDER BY id DESC 
            LIMIT 0, 20";
        $result = $this->db->fetchAll($sql, 1);
        if(empty($result))
            return array('success' => 1, 'data' => array());
        foreach ($result as $val) {
            //array_merge($data, $val);
            $sql1 = "SELECT id, parentId, appName, fileName, size0, size1, size2, flux, TIME AS reqNum, STATUS, createTime, updateTime 
                FROM t_log_terminalupgradedetail WHERE parentId = {$val['id']} AND TIME = 1 ORDER BY appName, fileName ASC";
            $res = $this->db->fetchAll($sql1, 1);
            if(!empty($res)) {
                $size0 = 0;
                foreach ($res as $val1) {
                    $size0 = $size0 + $val1['size0'];
                }
                $data1 = array('app' => array($res[0]['appname'] => array('files' => $res, 'name' => $res[0]['appname'], 
                    'size0' => $size0)));
                $data[] = array_merge($data1, $val);
            }
            //$result[] = array_merge($val, $data);
        }
        //print_r($data);die;
        return array('success' => 1, 'data' => $data);
    }
}