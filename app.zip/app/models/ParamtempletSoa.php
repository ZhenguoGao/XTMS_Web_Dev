<?php

/**
 * paramtemplet
 *  
 * @author zhaimin
 */
class ParamtempletSoa extends ModelSoa2
{
    //public $lookupfield = array(array('name','名称'),array('version','版本'),array('description','描述'));
    public $lookupfield = array('name','version','description');
    public $primaryKey = 'id';
    public $order = array('field'=>'createTime','direction'=>'desc');
    /**
    public $method = array(
    	'index'     => 'paramtemp/getParamTemp',
        'add'       => 'paramtemp/addParamTemp',
    	'update'    => 'paramtemp/modifyParamTemp',
    	'delete'    => 'paramtemp/removeParamTemp',
    	'get'       => 'paramtemp/getParamTempById',
    	'getbymid'  => 'paramModelTemp/queryByModelId',
    	'savebymid' => 'paramModelTemp/merge'
    );
    **/
    public $method = array(
        'index'     => 'paramtemplet/search',
        'add'       => 'paramtemplet/add',
        'update'    => 'paramtemplet/modify',
        'delete'    => 'paramtemplet/delete',
        'get'       => 'paramtemplet/detail',
        'getbymid'  => 'paramtemplet/queryByModelId',
        'savebymid' => 'paramtemplet/merge',
        'copy'      => 'paramtemplet/copy',
    );
}