<?php

/**
 * Log
 *  
 * @author lujun
 */

class Log extends ModelBase
{
    var $pareTable = array(
        'getColumns'=>array('id','ip','action','actionUri','actionTime','operate','opCode','userid','useridalias'),
        'sequence'=>'t_log_sysoperate',
        'lookupfield'=>array('action','actionUri')
    );
    
    var $primaryKey = 'id';
    var $order = array('field'=>'id','direction'=>'desc');
    
    public function getSource() {
        return 't_log_sysoperate';
    }
    
    public function createLog($str, $module, $opr)
    {
        $row = array();
        $row['userid']		= $_SESSION['rbac']['id'];
        $row['opCode']		= $opr;
        $row['action']		= $str;
        $row['ip']        = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
        $row['actionUri'] = $module;
        $row['useridalias'] = $_SESSION['rbac']['idAlias'];
        $this->insertByPost($row);
    }
}