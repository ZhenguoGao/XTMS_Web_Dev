<?php
/**
 * 用户类接口
 *  
 * @author zhaimin
 */


class UserModel extends ModelSoa2
{
    public $primaryKey = 'id';
    public $order = array('field'=>'id','direction'=>'desc');
    public $method = array(
    	'index'     =>	'user/search',
        'add'       =>	'user/add',
    	'update'    =>	'user/modify',
    	'delete'    =>	'user/delete',
    	'get'       =>	'user/detail',
    	'lock'      =>	'user/lock',
    	'reset'     =>	'user/reset',
    	'login'     =>	'user/login',
    	'getmenu'   =>	'user/menu',
    	'getRoute'=>'usr/getRoute'
    );
    
    public function findUser($userno, $password)
    {
        //验证用户
//         if($userno !='tmsadmin'){
//             if($this->loginUM($userno, $password) == 'false' || $this->loginUM($userno, $password) == false) {
//                 return array('result'=>0,'error'=>'um账号或密码错误');
//             }
//         }
        $post['param']['username']=$userno;
        $post['param']['password']=$password;
        $array = $this->execute($post, 'login');
        if(!$array['status']['success'])
            return array('result'=>0,'error'=>$array['status']['message']);
        else
            return array('result'=>1,'user'=>$array['result']);
    }
public  function SearchRoute($data){

	$model = new UserNew();
	return  $res = $model->getRoute($data);
	
	
}
    
    
    public function makeMenu($user)
    {
        return $this->execute(array('param'=>array('id'=>$user['id'])), 'getmenu');
    }
    
    public function loginUM($username, $password)
    {
        $post['username'] = $username;
        $post['password'] = $password;
        $post_string = 'clientIp='.$_SERVER["REMOTE_ADDR"].'&jsonStr='.urlencode(json_encode($post));
        $url = "http://10.14.18.122:8080/xtms/user/loginUM";
        $curl = curl_init();  // 启动一个CURL会话
        curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
        // curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1); // 从证书中检查SSL加密算法是否存在，已废弃
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2); // 从证书中检查SSL加密算法是否存在
        curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转
        curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer
        curl_setopt($curl, CURLOPT_POST, 1); // 发送一个常规的Post请求
        curl_setopt($curl, CURLOPT_POSTFIELDS, $post_string); // Post提交的数据包
        curl_setopt($curl, CURLOPT_TIMEOUT, 30); // 设置超时限制防止死循环
        curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回
        $tmpInfo = curl_exec($curl); // 执行操作
        
        if (curl_errno($curl)) 
            $res = false;
        else
            $res = $tmpInfo;
        curl_close($curl);
        return $res;
    }
}