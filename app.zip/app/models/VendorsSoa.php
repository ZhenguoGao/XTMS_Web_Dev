<?php

/**
 * merchant
 *  
 * @author lujun
 */

class VendorsSoa extends ModelSoa2
{
    public $primaryKey = 'id';
    public $order = array('field'=>'id','direction'=>'desc');
    public $lookupfield = array('vendor_name','vendor_code');
    public $method = array(
        'index'     =>	'vendors/search',
        'add'       =>	'vendors/add',
        'update'    =>	'vendors/modify',
        'delete'    =>	'vendors/delete',
        'get'       =>	'vendors/detail',
    );
}