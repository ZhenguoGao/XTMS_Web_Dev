<?php
/**
 * 菜单接口
 *  
 * @author zhaimin
 */


class MenuModel extends ModelSoa2
{
    public $primaryKey = 'id';
    public $order = array('field'=>'id','direction'=>'desc');
    public $method = array(
        'index'     => 'menu/search',
        'add'       => 'menu/add',
        'update'    => 'menu/modify',
        'delete'    => 'menu/delete',
        'get'       => 'menu/detail',
        'index1'    => 'menu/search1',
    );
}

