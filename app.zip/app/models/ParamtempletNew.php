<?php

/**
 * paramtemplet
 *  
 * @author lujun
 */
class ParamtempletNew extends ModelBase1
{
    var $tableName = 't_param_temp';
    var $pareTable = array(
        'getColumns'=>array('id','name','number','version','description','creator','createTime','modifier','updateTime',
            'useridalias','paramtype'),
        'lookupfield'=>array('name')
    );
    
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
    );
    var $primaryKey = 'id';
    var $order = array('field'=>'id','direction'=>'desc');
    
    public function copy($post){
        $id = $post['param']['id'];
        $sql1 = "select name,number,version,description,paramtype from {$this->tableName} where id = {$id};";
        $res1 = $this->db->fetchOne($sql1, 1);
        if(strpos($res1['name'],"_copy"))
            return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => '0'));
        
        $zero = date("y-m-d H:i:s");
        $sql2 = "insert into {$this->tableName}(name,number,version,description,paramtype,createtime,creator,updateTime, useridalias) values(
            '{$res1['name']}', '{$res1['number']}','{$res1['version']}','{$res1['description']}','{$res1['paramtype']}',
            '{$zero}','{$_SESSION['rbac']['id']}','{$zero}','{$_SESSION['rbac']['idAlias']}');";
        $this->db->begin();
        if(!$this->db->execute($sql2)) {
            $this->db->rollback();
            return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => '0'));
        }
        $getID = $this->db->lastInsertId();
        $sql3 = "select paramId, paramCode, value from t_param_paramtemp where paramTempId = {$id};";
        $res3 = $this->db->fetchAll($sql3, 1);
        if(!empty($res3)){
            $sql4 = 'INSERT INTO t_param_paramtemp(paramId, paramCode, value, paramTempId) VALUES';
            foreach ($res3 as $val) {
                $sql4 .= "({$val['paramid']},'{$val['paramcode']}','{$val['value']}',{$getID}),";
            }
            $sql4 = rtrim($sql4, ",").';';
            if(!$this->db->execute($sql4)) {
                $this->db->rollback();
                return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => '0'));
            }
        }
        $this->db->commit();
        return array('status' => array('success' => 1));
    }
    
    public function findByPk($pk) {
        $sql1 = "select id,name,number,version,description,paramtype,creator from {$this->tableName} where id = {$pk};";
        $sql2 = "SELECT t1.id,t1.name,t1.number,t1.type,t1.min,t1.max,t1.encryption, t1.description,t1.creator,t1.createTime,
            t.value AS defaultValue	FROM t_param_paramtemp t LEFT JOIN t_param_param t1 ON t.paramId = t1.id WHERE t.paramTempId = {$pk};";
        $res1 = $this->db->fetchOne($sql1, 1);
        $res2 = $this->db->fetchAll($sql2, 1);
        if(!empty($res1)){
            return array('status' => array('success' => 1),'result' => array('paramTemp' => $res1, 'paramList' => $res2));
        } else{
            return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => 'The result is null!'));
        }
    }
    
    public function remove($id)
    {
        $f_sql = "select * from t_app_apptemp where paramTempId={$id}";
        $f_ret = $this->db->fetchOne($f_sql, 1);
        if ($f_ret) {
            $ret = array('statusCode'=>300,'message'=>'This parameter template is associated with the application template and cannot be deleted');
            echo json_encode($ret);
            exit();
        }
        $sql = "DELETE FROM {$this->tableName} WHERE id = {$id}";
        $sql .= $this->param();
        $sql .= ";DELETE FROM t_param_paramtemp WHERE paramTempId = {$id};";
        //echo $sql;die;
        //$this->_logger->log($sql, \Phalcon\Logger::INFO);
        if($this->db->execute($sql)){
            $this->_afterRemoveDbByPkv($ids);
            return array('status' => array('success' => 1));
        } else{
            return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => '0'));
        }
    }
    
    public function save($post)
    {
        if($post['act'] == 'add'){
            if($this->insertByPost($post)) {
                $result = array('status' => array('success' => 1,'message' => 'Add Success!'));
                $this->_afterUpdateDb($post);
            } else {
                $result = array('status' => array('success' => 0,'message' => 'Add Failed!','errorCode' => 0));
            }
        } else if($post['act'] == 'upd') {
            if($this->updateByPost($post)) {
                $result = array('status' => array('success' => 1,'message' => 'Update Success'));
                $this->_afterUpdateDb($post);
            } else {
                $result = array('status' => array('success' => 0,'message' => 'Update Failed','errorCode' => 0));
            }
        } else{
            $result = array('status' => array('success' => 0,'message' => 'Error!','errorCode' => 1));
        }
        return $result;
    }
    
    public function updateByPost($post)
    {
        $d_sql = "select * from {$this->tableName} where id={$post['paramTemp']['id']}";
        $d_ret = $this->db->fetchOne($d_sql, 1);
        if ($d_ret['name'] != $post['paramTemp']['name']) {
            $f_name = "select name from {$this->tableName} where name='{$post['paramTemp']['name']}' and useridalias='{$_SESSION['rbac']['idAlias']}'";
            $ret_name = $this->db->fetchOne($f_name, 1);
            if ($ret_name) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'The current user has created the same name parameter template'
                    )
                );
                exit();
            }
        }
        if ($d_ret['number'] != $post['paramTemp']['number']) {
            $f_number = "select number from {$this->tableName} where number='{$post['paramTemp']['number']}' and useridalias='{$_SESSION['rbac']['idAlias']}'";
            $ret_number = $this->db->fetchOne($f_number, 1);
            if ($ret_number) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'The current user has created the same number parameter template'
                    )
                );
                exit();
            }
        }
        $zero = date("y-m-d H:i:s");
        $post['paramTemp']['description'] = str_replace(array("\r\n", "\r", "\n"), ' ', $post['paramTemp']['description']);
        $sql = "update t_param_temp set number = '{$post['paramTemp']['number']}', name = '{$post['paramTemp']['name']}',
            version = '{$post['paramTemp']['version']}',description = '{$post['paramTemp']['description']}', 
            paramtype = {$post['paramTemp']['paramtype']},modifier = '{$_SESSION['rbac']['id']}',
            updateTime = '$zero' where id = {$post['paramTemp']['id']};";
        //删掉t_param_paramtemp表中paramTempId的数据
        $sql .= "delete from t_param_paramtemp where paramTempId = {$post['paramTemp']['id']};";
        if(!empty($post['param'])) {
            $sql .= "insert into t_param_paramtemp(paramid,value,paramtempid) values";
            foreach ($post['param'] as $val) {
                $sql .= "({$val['id']},'{$val['defaultValue']}',{$post['paramTemp']['id']}),";
            }
        }
        $sql = rtrim($sql, ",").';';
        //echo $sql;die;
        return $this->db->execute($sql);
    }
    
    public function insertByPost($post)
    {
        $f_name = "select name from {$this->tableName} where name='{$post['paramTemp']['name']}' and useridalias='{$_SESSION['rbac']['idAlias']}'";
        $ret_name = $this->db->fetchOne($f_name, 1);
        if ($ret_name) {
            echo json_encode(
                array(
                    'statusCode' => 300,
                    'message' => 'The current user has created the same name parameter template'
                )
            );
            exit();
        }
        $f_number = "select number from {$this->tableName} where number='{$post['paramTemp']['number']}' and useridalias='{$_SESSION['rbac']['idAlias']}'";
        $ret_number = $this->db->fetchOne($f_number, 1);
        if ($ret_number) {
            echo json_encode(
                array(
                    'statusCode' => 300,
                    'message' => 'The current user has created the same number parameter template'
                )
            );
            exit();
        }
        $zero = date("y-m-d H:i:s");
        $post['paramTemp']['description'] = str_replace(array("\r\n", "\r", "\n"), ' ', $post['paramTemp']['description']);
        $sql = "insert into {$this->tableName}(name,number,version,description,creator,createtime,paramtype,useridalias) values(
            '{$post['paramTemp']['name']}','{$post['paramTemp']['number']}','{$post['paramTemp']['version']}',
            '{$post['paramTemp']['description']}','{$_SESSION['rbac']['id']}','{$zero}',{$post['paramTemp']['paramtype']},
            '{$_SESSION['rbac']['idAlias']}');";
        $this->db->begin();
        if(!$this->db->execute($sql)) {
            $this->db->rollback();
            return false;
        }
        $getID = $this->db->lastInsertId();
        if(!empty($post['param'])) {
            $sql1 = 'insert t_param_paramtemp(paramid,value,paramtempid) values';
            foreach ($post['param'] as $val) {
                $sql1 .= "({$val['id']},'{$val['defaultValue']}',{$getID}),";
            }
            $sql1 = rtrim($sql1, ",").';';
            if(!$this->db->execute($sql1)) {
                $this->db->rollback();
                return false;
            }
        }
        $this->db->commit();
        return true;
    }
    
    public function queryByModelId($post){
        $sql1 = "SELECT id,modelId,NAME,number,VERSION,description FROM t_param_modeltemp WHERE modelId = {$post['modelId']};";
        $res1 = $this->db->fetchOne($sql1, 1);
        if(!empty($res1)){
            $sql2 = "SELECT t1.id,t1.name,t1.number,t1.type,t1.min,t1.max,t1.encryption, t1.description,t1.creator,t1.createTime,
                t.value AS defaultValue	FROM t_param_r_modeltemp t LEFT JOIN t_param_param t1 ON t.paramId = t1.id WHERE 1 = 1
                and t.modeltempId = {$res1['id']};";
            $res2 = $this->db->fetchAll($sql2, 1);
            return array('status' => array('success' => 1),'result' => array('paramTemp' => $res1, 'paramList' => $res2));
        } else{
            return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => 'The result is null!'));
        }
    }
    
    public function merge($post){
        $zero = date("y-m-d H:i:s");
        //先删除
        $sql = "delete from t_param_modeltemp WHERE modelId = {$post['paramTemp']['modelId']}; ";
        $sql .= "delete FROM t_param_r_modeltemp t LEFT JOIN t_param_modeltemp t1 ON t.modeltempid = t1.id WHERE 
             t1.modelId = {$post['paramTemp']['modelId']};";
        $this->db->begin();
        if(!$this->db->execute($sql)) {
            $this->db->rollback();
            return array('success' => 0);
        }
        $sql1 .= "insert into t_param_modeltemp(number,name,version,description,modelId,creator,createtime) values(
        '{$post['paramTemp']['number']}','{$post['paramTemp']['name']}','{$post['paramTemp']['version']}',
            '{$post['paramTemp']['description']}',{$post['paramTemp']['modelId']},'{$_SESSION['rbac']['id']}','{$zero}');";
        if(!$this->db->execute($sql1)) {
            $this->db->rollback();
            return array('success' => 0);
        }
        $getID = $this->db->lastInsertId();
        if(!empty($post['param'])) {
            $sql2 .= "insert t_param_r_modeltemp(paramid,value,modeltempid) values";
            foreach ($post['param'] as $val) {
                $sql2 .= "({$val['id']},'{$val['defaultValue']}',{$getID}),";
            }
            $sql2 = rtrim($sql2, ",").';';
            if(!$this->db->execute($sql2)) {
                $this->db->rollback();
                return array('success' => 0);
            }
        }
        $this->db->commit();
        return array('success' => 1);
    }
}