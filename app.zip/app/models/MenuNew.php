<?php
/**
 * 菜单接口
 *  
 * @author lujun
 */


class MenuNew extends ModelBase1
{
    var $tableName = 't_auth_menu';
    var $pareTable = array(
        'getColumns'=>array('id','parentid','type','showorder','name','link','locked','remark','st'),
        'lookupfield'=>array('name')
    );
    
    var $primaryKey = 'id';
    
    public function findByPost($post, $get)
    {
        //print_r($post);die;
        $this->_parseSql();
        $fields = ltrim($this->_selectField,',');
        $sql = "SELECT {$fields} FROM {$this->qtable($this->getSource())} {$this->_externSql} WHERE 1=1 ";
        $count_sql = "SELECT COUNT(1) AS nrows FROM {$this->qtable($this->getSource())} {$this->_externSql} WHERE 1=1 ";
        //print_r();die;
        if (is_array($get) && !empty($get)) {
            foreach ($get as $k => $v) {
                if (in_array($k, $this->pareTable['getColumns']) ) {
                    $this->_bindParams[$k] = $v;
                    $sql .= " AND {$this->qfield($k, $this->qtable($this->getSource()))} = {$this->_bindParams[$k]}";
                    $count_sql .= " AND {$this->qfield($k, $this->qtable($this->getSource()))} = {$this->_bindParams[$k]}";
                }
            }
        }
        $sql .= $this->_getSearchSql($post['param']);
        $count_sql .= $this->_getSearchSql($post['param']);
        
        //print_r($sql);die;
        //$sql .= $this->param(true);
        //$count_sql .= $this->param(true);
        //print_r($count_sql);die;
        //$this->_logger->log($count_sql, \Phalcon\Logger::INFO);
        $count = $this->db->fetchOne($count_sql);
        /**
        if(!empty($post)){
            $sql .= " ORDER BY {$this->qfield($post['order']['field'])} {$post['order']['direction']}";
            //echo $sql;die;
            $offset = (intval($post['page']['pageNum'])-1)*intval($post['page']['pageSize']);
            $sql .= " limit {$offset},{$post['page']['pageSize']}";
        }
        **/
        //print_r($sql);die;
        //$this->_logger->log($sql, \Phalcon\Logger::INFO);
        $rowset = $this->db->fetchAll($sql, 1);
        //print_r($rowset);die;
        return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
    }
    
    public function search1($post, $get)
    {
        $sql = "SELECT t.id,t.parentid,t.type,t.showorder,t.name,t.link,t.locked,t.remark,t.st FROM t_auth_menu t WHERE 1=1 ";
        $count_sql = "SELECT COUNT(1) AS nrows FROM t_auth_menu t WHERE 1=1 ";
        if ($_SESSION['rbac']['idAlias'] == '1') {
            $condition = " and t.link <> 'menu/index' AND t.id in (SELECT m.id FROM t_auth_menu m) ";
        } else {
            $condition = " and t.link <> 'menu/index' AND t.id IN(SELECT r.menuid FROM t_auth_menu_rel r LEFT JOIN t_auth_user u 
            ON r.roleid =  u.roleid WHERE u.id=".$_SESSION['rbac']['id'].")";
        }
        $sql .= $condition;
        $count_sql .= $condition;
        $count = $this->db->fetchOne($count_sql);
        $rowset = $this->db->fetchAll($sql, 1);
        //print_r($rowset);die;
        return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
    }
}

