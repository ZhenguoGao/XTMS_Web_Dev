<?php
/**
 * 执行sql接口
 *  
 * @author zhaimin
 */


class DosqlModel extends ModelSoa
{
    public $method = array(
    	'dosql'	=> 'XXX/XXX',
    );
}

