<?php

/**
 * ApptempletSoa
 *  
 * @author zhaimin
 */

class ApptempletSoa extends ModelSoa2
{
    public $lookupfield = array('name','version');
    public $primaryKey = 'id';
    public $order = array('field'=>'name','direction'=>'desc');
    /**
    public $method = array(
    	'index'     =>	'apptemp/getAppTemp',
        'add'       =>	'apptemp/addAppTemp',
    	'update'    =>	'apptemp/modifyAppTemp',
    	'delete'    =>	'apptemp/removeAppTemp',
    	'get'       =>	'apptemp/getAppTempById'
    );
    **/
    public $method = array(
        'index'     =>	'apptemp/search',
        'add'       =>	'apptemp/add',
        'update'    =>	'apptemp/modify',
        'delete'    =>	'apptemp/remove',
        'get'       =>	'apptemp/detail'
    );
}