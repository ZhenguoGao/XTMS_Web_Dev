<?php

/**
 * merchant Termimport
 *  
 * @author lujun
 */

class Termimport extends ModelSoa2
{
    public $primaryKey = 'ltermid';
    public $order = array('field'=>'ltermid','direction'=>'desc');
    public $lookupfield = array('termno','termnoname','merchname','merchno');
    public $method = array(
        'index'     =>	'termimport/search',
        'add'       =>	'termimport/add',
        'update'    =>	'termimport/modify',
        'delete'    =>	'termimport/delete',
        'get'       =>	'termimport/detail',
    );
}