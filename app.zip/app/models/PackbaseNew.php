<?php

/**
 * Packbase
 *  
 * @author lujun
 */

class PackbaseNew extends ModelBase1
{
    var $tableName = 't_app_package';
    var $pareTable = array(
        'getColumns'=>array('id','number','packagename','packageType','version','filesize','filenum','filepath',
            'modelId','description','publisher','published','app','display','status','archiveno','useridalias'),
        'lookupfield'=>array('packageType','packagename','modelId'),
    );
    
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
        'modelId' => array(
            'tableName' => 't_bd_model',
            'mappingKey' => 'id',
            'displayKey' => array('name as modelname'),
            'externKeys' => array()
        ),
    );
    var $primaryKey = 'id';
    var $order = array('field'=>'id','direction'=>'desc');
    
    public function detail($post)
    {
        $sql = "SELECT fileName,fileSize,filePath,version,description FROM t_app_packagedetail WHERE 1=1 ";
        $count_sql = "SELECT COUNT(1) AS nrows FROM t_app_packagedetail WHERE 1=1 ";
        $condition = "and packageId = {$post['id']} AND compressType = 0";
        if($post['fileName'] != ''){
            $condition .= " and filename like '%{$post['fileName']}%'";
        }
        $offset = (intval($post['pageNum'])-1)*intval($post['pageSize']);
        $sql .= $condition ." order by id desc limit {$offset},{$post['pageSize']}";
        $count_sql .= $condition;
        $count = $this->db->fetchOne($count_sql);
        $rowset = $this->db->fetchAll($sql, 1);
        return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
    }

    public function findByPost($post, $get)
    {
        $this->_parseSql();
        $fields = ltrim($this->_selectField,',');
        $sql = "SELECT {$fields} FROM {$this->qtable($this->getSource())} {$this->_externSql} WHERE 1=1 ";
        $count_sql = "SELECT COUNT(1) AS nrows FROM {$this->qtable($this->getSource())} {$this->_externSql} WHERE 1=1 ";
        if ($post['param']['resource'] == 'updplan') {
            $sql = "SELECT {$fields} FROM {$this->qtable($this->getSource())} {$this->_externSql} WHERE 1=1 AND status='1' ";
            $count_sql = "SELECT COUNT(1) AS nrows FROM {$this->qtable($this->getSource())} {$this->_externSql} WHERE 1=1 AND status='1'";
        }
        if (is_array($get) && !empty($get)) {
            foreach ($get as $k => $v) {
                if (in_array($k, $this->pareTable['getColumns'])) {
                    $this->_bindParams[$k] = $v;
                    $sql .= " AND {$this->qfield($k, $this->qtable($this->getSource()))} = {$this->_bindParams[$k]}";
                    $count_sql .= " AND {$this->qfield($k, $this->qtable($this->getSource()))} = {$this->_bindParams[$k]}";
                }
            }
        }
        $sql .= $this->_getSearchSql($post['param']);
        $count_sql .= $this->_getSearchSql($post['param']);
        $sql .= $this->param(true);
        $count_sql .= $this->param(true);
        $count = $this->db->fetchOne($count_sql);
        if(!empty($post)){
            $sql .= " ORDER BY {$this->qfield($post['order']['field'])} {$post['order']['direction']}";
            $offset = (intval($post['page']['pageNum'])-1)*intval($post['page']['pageSize']);
            $sql .= " limit {$offset},{$post['page']['pageSize']}";
        }
        $rowset = $this->db->fetchAll($sql, 1);
        return array('page' => array('total' => $count['nrows']), 'result' => $rowset, 'success' => 1);
    }
}