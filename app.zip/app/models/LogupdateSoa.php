<?php

/**
 * LogupdateSoa
 *  
 * @author zhaimin
 * @version 1.0
 */

class LogupdateSoa extends ModelSoa2
{
    public $primaryKey = 'id';
    public $order = array('field'=>'upgradeTime','direction'=>'desc');
    /**
    public $method = array(
    	'index'             =>	'logmanage/getUpgradeLog',
    	'LogByMachineId'    =>	'logmanage/getUpgradeLogByMachineId',
    	'get'               =>	'logmanage/getUpgradeDetatilLog'
    );
    **/
    public $method = array(
        'index'             =>	'logupdate/search',
        'LogByMachineId'    =>	'logupdate/getUpgradeLogByMachineId',
        'get'               =>	'logupdate/detail'
    );
}