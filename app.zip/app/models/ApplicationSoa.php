<?php

/**
 * Application
 *  
 * @author zhaimin
 */

class ApplicationSoa extends ModelSoa2
{
    //public $lookupfield = array(array('name','名称'),array('type','类型','50'),array('version','版本'),array('description','描述'));
    public $lookupfield = array('name','type','version','description');
    public $replacevalue = array(
        'type' => array('1'=>'Host','2'=>'Sub application')
    );
    public $primaryKey = 'id';
    public $order = array('field'=>'name','direction'=>'desc');
    /**
    public $method = array(
        'index'     =>	'app/getApp',
        'add'       =>	'app/addApp',
        'update'    =>	'app/modifyApp',
        'delete'    =>	'app/removeApp',
        'get'       =>	'app/getAppById'
    );
    **/
    public $method = array(
        'index'     =>	'application/search',
        'add'       =>	'application/add',
        'update'    =>	'application/modify',
        'delete'    =>	'application/remove',
        'get'       =>	'application/detail'
    );
}