<?php

/**
* 终端信息触发查询
*/
class TerminalTriggerSoa extends ModelSoa2
{
    public $order = array('field'=>'id','direction'=>'desc');
    public $method = array(
        //'index'	=> 'terminaltrigger/getTerminalTriggerInfos',
        'index'	=> 'terminaltrigger/search',
    );
}