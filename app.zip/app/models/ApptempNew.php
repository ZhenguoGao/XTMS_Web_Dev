<?php

/**
 * ApptempletNew
 *  
 * @author lujun
 */

class ApptempNew extends ModelBase1
{
    var $tableName = 't_app_temp';
    var $pareTable = array(
        'getColumns'=>array('id','name','number','modifier','updateTime','createTime','creator','description','useridalias'),
        'lookupfield'=>array('name')
    );
    
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
    );
    var $primaryKey = 'id';
    
    public function findByPk($pk) {
        $sql1 = "select id,name,number,description from {$this->tableName} where id = {$pk};";
        $sql2 = "SELECT a.id,a.appTempId,a.appId,a.paramTempId,a.appUpdateMode,a.paramTempUpdateMode,a.serialNo,a.status, b.name AS appName,
            b.version AS appVersion,c.name AS paramTempName,c.version AS paramTempVersion FROM t_app_apptemp a LEFT JOIN T_APP_APP b 
            ON a.appId=b.id LEFT JOIN T_PARAM_TEMP c ON a.paramTempId=c.id WHERE a.appTempId = {$pk};";
        //echo $sql1;die;
        $res1 = $this->db->fetchOne($sql1, 1);
        if(!empty($res1)){
            $res2 = $this->db->fetchAll($sql2, 1);
            return array('status' => array('success' => 1),'data' => array('appTemp' => $res1, 'appParamTemp' => $res2));
        } else{
            return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => 'The result is null!'));
        }
    }
    
    public function save($post){
        if($post['act'] == 'add'){
            if($this->insertByPost($post)) {
                $result = array('status' => array('success' => 1,'message' => 'Update Success'));
                $this->_afterUpdateDb($post);
            } else {
                $result = array('status' => array('success' => 0,'message' => 'Update Failed','errorCode' => 0));
            }
        } else if($post['act'] == 'upd') {
            if($this->updateByPost($post)) {
                $result = array('status' => array('success' => 1,'message' => 'Update Success'));
                $this->_afterUpdateDb($post);
            } else {
                $result = array('status' => array('success' => 0,'message' => 'Update Failed','errorCode' => 0));
            }
        } else{
            $result = array('status' => array('success' => 0,'message' => 'Update Failed','errorCode' => 1));
        }
        return $result;
    }
    
    public function insertByPost($post)
    {
        $f_name = "select name from {$this->tableName} where name='{$post['appTemp']['name']}' and useridalias='{$_SESSION['rbac']['idAlias']}'";
        $ret_name = $this->db->fetchOne($f_name, 1);
        if ($ret_name) {
            echo json_encode(
                array(
                    'statusCode' => 300,
                    'message' => 'The current user has created the same name application template'
                )
            );
            exit();
        }
        $f_number = "select number from {$this->tableName} where number='{$post['appTemp']['number']}' and useridalias='{$_SESSION['rbac']['idAlias']}'";
        $ret_number = $this->db->fetchOne($f_number, 1);
        if ($ret_number) {
            echo json_encode(
                array(
                    'statusCode' => 300,
                    'message' => 'The current user has created the same numbering application template'
                )
            );
            exit();
        }
        $zero = date("y-m-d H:i:s");
        $post['appTemp']['description'] = str_replace(array("\r\n", "\r", "\n"), ' ', $post['appTemp']['description']);
        $sql = "insert into {$this->tableName}(name,number,description,createtime,creator,useridalias) values(
            '{$post['appTemp']['name']}','{$post['appTemp']['number']}','{$post['appTemp']['description']}','{$zero}',
            '{$_SESSION['rbac']['id']}','{$_SESSION['rbac']['idAlias']}');";
        $this->db->begin();
        if(!$this->db->execute($sql)) {
            $this->db->rollback();
            return false;
        }
        $getID = $this->db->lastInsertId();
        if(!empty($post['appParamTemp'])) {
            $sql1 = 'insert into t_app_apptemp(apptempid,appid,appUpdateMode,paramTempId,paramTempUpdateMode) values';
            foreach ($post['appParamTemp'] as $val) {
                $sql1 .= "({$getID},{$val['appId']},{$val['appUpdateMode']},{$val['paramTempId']},{$val['paramTempUpdateMode']}),";
            }
            $sql1 = rtrim($sql1, ",").';';
            if(!$this->db->execute($sql1)) {
                $this->db->rollback();
                return false;
            }
        }
        $this->db->commit();
        return true;
    }
    
    public function updateByPost($post)
    {
        $d_sql = "select * from {$this->tableName} where id={$post['appTemp']['id']}";
        $d_ret = $this->db->fetchOne($d_sql, 1);
        if ($d_ret['name'] != $post['appTemp']['name']) {
            $f_name = "select name from {$this->tableName} where name='{$post['appTemp']['name']}' and useridalias='{$_SESSION['rbac']['idAlias']}'";
            $ret_name = $this->db->fetchOne($f_name, 1);
            if ($ret_name) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'The current user has created the same name application template'
                    )
                );
                exit();
            }
        }
        if ($d_ret['number'] != $post['appTemp']['number']) {
            $f_number = "select number from {$this->tableName} where number='{$post['appTemp']['number']}' and useridalias='{$_SESSION['rbac']['idAlias']}'";
            $ret_number = $this->db->fetchOne($f_number, 1);
            if ($ret_number) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'The current user has created the same numbering application template'
                    )
                );
                exit();
            }
        }
        $zero = date("y-m-d H:i:s");
        $post['appTemp']['description'] = str_replace(array("\r\n", "\r", "\n"), ' ', $post['appTemp']['description']);
        $sql = "update {$this->tableName} set number = '{$post['appTemp']['number']}', `name` = '{$post['appTemp']['name']}',
            description = '{$post['appTemp']['description']}',`modifier` = '{$_SESSION['rbac']['id']}',
            updateTime = '$zero' where id = {$post['appTemp']['id']};";
        $this->db->begin();
        if(!$this->db->execute($sql)) {
            $this->db->rollback();
            return false;
        }
        //删掉t_param_paramtemp表中paramTempId的数据
        $sql = "delete from t_app_apptemp where appTempId = {$post['appTemp']['id']};";
        if(!$this->db->execute($sql)) {
            $this->db->rollback();
            return false;
        }
        if(!empty($post['appParamTemp'])) {
            $sql = 'insert into t_app_apptemp(apptempid,appid,appUpdateMode,paramTempId,paramTempUpdateMode) values';
            foreach ($post['appParamTemp'] as $val) {
                $sql .= "({$post['appTemp']['id']},{$val['appId']},{$val['appUpdateMode']},{$val['paramTempId']},{$val['paramTempUpdateMode']}),";
            }
            $sql = rtrim($sql, ",").';';
            if(!$this->db->execute($sql)) {
                $this->db->rollback();
                return false;
            }
        }
        $this->db->commit();
        return true;
    }
    
    public function remove($id)
    {
        $id = $id['param'][id];
        $f_sql = "select * from t_upd_plan where appTempID='{$id}'";
        $f_ret = $this->db->fetchAll($f_sql, 1);
        if ($f_ret) {
            foreach ($f_ret as $set) {
                if (strtotime($set['endtime']) > time()) {
                    $ret = array('statusCode'=>300,'message'=>"The planned task added by the application template is not finished and cannot be deleted");
                    echo json_encode($ret);
                    exit();
                }
            }
        }
        $sql = "DELETE FROM {$this->tableName} WHERE id = {$id}";
        $sql .= $this->param();
        $sql .= ";DELETE FROM t_app_appprogram WHERE apptempid = {$id};";
        //echo $sql;die;
        //$this->_logger->log($sql, \Phalcon\Logger::INFO);
        if($this->db->execute($sql)){
            $this->_afterRemoveDbByPkv($id);
           return array('status' => array('success' => 1));
        } else{
            return array('status' => array('success' => 0,'message' => 'Delete Failed !','errorCode' => 1));
        }
    }
}