<?php

/**
 * paramitem
 *  
 * @author lujun
 */

class ParamNew extends ModelBase1
{
    var $pareTable = array(
        'getColumns'=>array('id','name','number','type','min','max','encryption','defaultValue','description',
            'creator','createTime','modifier','updateTime','useridalias'),
        'sequence'=>'t_param_param',
        'lookupfield'=>array('name','number')
    );
    
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
    );
    
    var $primaryKey = 'id';
    var $order = array('field'=>'number','direction'=>'desc');
//    var $uniqueFields = array('number');
    
    public function getSource()
    {
        return 't_param_param';
    }
    
    public function getPK()
    {
        return 'id';
    }
}