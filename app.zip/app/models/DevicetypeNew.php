<?php

/**
 * DevicetypeNew
 *  
 * @author lujun
 */

class DevicetypeNew extends ModelBase1
{
    var $tableName = 't_bd_model';
    var $pareTable = array(
        'getColumns'=>array('id','name','description','creator','createTime','modifier','updateTime','supplierId',
            'parentId','modeltype','vendorsid'),
        'lookupfield'=>array('name')
    );
    
    /**
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
    );
    **/
    var $foreignTable = array(
        'vendorsid' => array(
            'tableName' => 't_vendors',
            'mappingKey' => 'id',
            'displayKey' => array('vendor_name'),
            'externKeys' => array()
        ),
    );
    
    var $primaryKey = 'id';
    var $order = array('field'=>'id','direction'=>'desc');
    
    public function getPK()
    {
        return 'id';
    }
    
    public function getAll($post)
    {
        /**
        $sql = "select id, `name`,parentid from {$this->tableName} t where 1 = 1";
        if($post['onlyParent'])
            $sql .= ' and parentId = 0 ';
        if($post['modeltype'] != ''){
            $sql .= " and modeltype = {$post['modeltype']} ";
        }
        $sql .= $this->param();
        //$sql .= " and useridalias = '{$_SESSION['rbac']['idAlias']}'";
        $sql .= ' order by id;';
        **/
        /**
         * 只允许最高用户添加机型，其他用户可以查看所有机型
         
        $sql = "select t.id, t.`name`,t.parentid,t1.name as username from {$this->tableName} t inner join t_auth_user t1 
            on t.useridalias = t1.useridalias where 1 = 1";
        if($post['onlyParent'])
            $sql .= ' and t.parentId = 0 ';
        if($post['modeltype'] != '')
            $sql .= " and t.modeltype = {$post['modeltype']} ";
        $sql .= " and (t.useridalias like '{$_SESSION['rbac']['idAlias']}.%' or t.useridalias = '{$_SESSION['rbac']['idAlias']}')";
        $sql .= ' order by t.id;';
        */
        $sql = "select t.id, t.`name`,t.parentid from {$this->tableName} t where 1 = 1";
        if($post['onlyParent'])
            $sql .= ' and t.parentId = 0 ';
        if(isset($post['modeltype']))
            $sql .= " and t.modeltype = {$post['modeltype']} ";
        //$sql .= " and (t.useridalias like '{$_SESSION['rbac']['idAlias']}.%' or t.useridalias = '{$_SESSION['rbac']['idAlias']}')";
        $sql .= ' order by t.id;';
        $rowset = $this->db->fetchAll($sql, 1);
        return array('data' => $rowset, 'success' => 1);
    }
    
    public function remove($id)
    {
        $f_sql = "select id from t_bd_terminal where modelId={$id}";
        $f_ret = $this->db->fetchOne($f_sql, 1);
        if ($f_ret) {
            echo json_encode(
                array(
                    'statusCode' => 300,
                    'message' => 'This machine is connected to terminal equipment and cannot be deleted'
                )
            );
            exit();
        }
        $sql = "DELETE FROM {$this->tableName} WHERE parentid = {$id};";
        $sql .= "DELETE FROM {$this->tableName} WHERE id = {$id}";
        $sql .= $this->param();
        //echo $sql;die;
        //$this->_logger->log($sql, \Phalcon\Logger::INFO);
        if($this->db->execute($sql)){
            $this->_afterRemoveDbByPkv($id);
            return array('status' => array('success' => 1));
        } else{
            return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => '0'));
        }
    }
}