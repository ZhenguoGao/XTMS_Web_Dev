<?php

/**
 * merchant
 *  
 * @author lujun
 */

class MerchantSoa extends ModelSoa2
{
    public $primaryKey = 'mersid';
    public $order = array('field'=>'mersid','direction'=>'desc');
    public $lookupfield = array('merchno','merchname');
    public $method = array(
        'index'     =>	'merchant/search',
        'add'       =>	'merchant/add',
        'update'    =>	'merchant/modify',
        'delete'    =>	'merchant/delete',
        'get'       =>	'merchant/detail',
    );
}