<?php

/**
 * Spos
 *  
 * @author lujun
 */

class SposNew extends ModelBase1
{
    var $tableName = 't_app_android';
    var $pareTable = array(
        'getColumns'=>array('id','name','version','md5','desc','createtime','filepath','modelid','useridalias','supportversion','upgradelevel'),
        'lookupfield'=>array('name')
    );
    
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
        'modelid' => array(
            'tableName' => 't_bd_model',
            'mappingKey' => 'id',
            'displayKey' => array('name as modelname'),
            'externKeys' => array()
        ),
    );
    var $primaryKey = 'id';
    
    public function edit($post){
        $sql = "update {$this->tableName} set modelid = {$post['model_id']} where id = {$post['id']};";
        if($this->db->execute($sql)){
            return array('success' => true);
        } else{
            return array('success' => false, 'errorCode' => 0, 'message' => '0');
        }
    }
    
    public function getModelName($modelId){
        $sql = "select `name` as modelname from t_bd_model where id = {$modelId}";
        $res = $this->db->fetchOne($sql);
        return $res['modelname'];
    }
    
    public function getmodel($useridalias){
        $sql = "select id, name,parentid from t_bd_model where 1 = 1";
        //$sql .= " and modeltype = 1 and useridalias = '{$useridalias}'";
        $sql .= " and modeltype = 1 ";
        $sql .= ' order by id;';
        $rowset = $this->db->fetchAll($sql, 1);
        return array('data' => $rowset, 'success' => 1);
    }
}