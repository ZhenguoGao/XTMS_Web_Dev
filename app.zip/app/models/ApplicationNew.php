<?php

/**
 * Application
 *  
 * @author lujun
 */

class ApplicationNew extends ModelBase1
{
    var $tableName = 't_app_app';
    var $pareTable = array(
        'getColumns'=>array('id','name','number','type','version','modifier','updateTime','createTime',
            'creator','description','appIndex','useridalias'),
        'lookupfield'=>array('name')
    );
    
    var $foreignTable = array(
        'useridalias' => array(
            'tableName' => 't_auth_user',
            'mappingKey' => 'useridalias',
            'displayKey' => array('name as username'),
            'externKeys' => array()
        ),
    );
    var $primaryKey = 'id';
    
    public function findByPk($pk) {
        $sql1 = "select id,name,number,type,version,description,appIndex from {$this->tableName} where id = {$pk};";
        $sql2 = "SELECT a.name AS modelName,a.id AS modelId,d.* FROM t_bd_model a LEFT JOIN 
            (SELECT c.* FROM t_app_appprogram b LEFT JOIN t_app_package c ON b.programId = c.id WHERE b.appId = {$pk}) d ON a.id = d.modelId;";
        $sql3 = "SELECT * FROM t_bd_model WHERE  parentId = 0 ORDER BY T_BD_model.id asc";
        //echo $sql1;die;
        $res1 = $this->db->fetchOne($sql1, 1);
        if(!empty($res1)){
            $res2 = $this->db->fetchAll($sql2, 1);
            $res3 = $this->db->fetchAll($sql3, 1);
            $arr1 = array();
            foreach ($res2 as $k=>$v){
                if($v['modelid'] != ''){
                    $arr1[$v['modelid']] = $v;
                }
            }
            return array('status' => array('success' => 1),'result' => array('app' => $res1, 'programList' => $arr1, 'machinetype' => $res3));
        } else{
            return array('status' => array('success' => 0, 'errorCode' => 0, 'message' => 'The result is null!'));
        }
    }
    
    public function save($post){
        if($post['act'] == 'add'){
            if($this->insertByPost($post)) {
                $result = array('status' => array('success' => 1,'message' => 'Update Success'));
                $this->_afterUpdateDb($post);
            } else {
                $result = array('status' => array('success' => 0,'message' => 'Update Failed','errorCode' => 0));
            }
        } else if($post['act'] == 'upd') {
            if($this->updateByPost($post)) {
                $result = array('status' => array('success' => 1,'message' => 'Update Success'));
                $this->_afterUpdateDb($post);
            } else {
                $result = array('status' => array('success' => 0,'message' => 'Update Failed','errorCode' => 0));
            }
        } else{
            $result = array('status' => array('success' => 0,'message' => 'Update Failed','errorCode' => 1));
        }
        return $result;
    }
    
    public function insertByPost($post)
    {
        $f_name = "select name from {$this->tableName} where name='{$post['app']['name']}' and useridalias='{$_SESSION['rbac']['idAlias']}'";
        $ret_name = $this->db->fetchOne($f_name, 1);
        if ($ret_name) {
            echo json_encode(
                array(
                    'statusCode' => 300,
                    'message' => 'The current user has created the same name application'
                )
            );
            exit();
        }
        $f_number = "select number from {$this->tableName} where number='{$post['app']['number']}' and useridalias='{$_SESSION['rbac']['idAlias']}'";
        $ret_number = $this->db->fetchOne($f_number, 1);
        if ($ret_number) {
            echo json_encode(
                array(
                    'statusCode' => 300,
                    'message' => 'The current user has created the same numbering application'
                )
            );
            exit();
        }
        $zero = date("y-m-d H:i:s");
        $post['app']['description'] = str_replace(array("\r\n", "\r", "\n"), ' ', $post['app']['description']);
        $sql = "insert into {$this->tableName}(name,number,type,appIndex,version,description,createtime,creator,useridalias) values(
        '{$post['app']['name']}','{$post['app']['number']}','{$post['app']['type']}','{$post['app']['appIndex']}','{$post['app']['version']}',
            '{$post['app']['description']}','{$zero}','{$_SESSION['rbac']['id']}','{$_SESSION['rbac']['idAlias']}');";
        $this->db->begin();
        if(!$this->db->execute($sql)) {
            $this->db->rollback();
            return false;
        }
        $getID = $this->db->lastInsertId();
        if(!empty($post['program'])) {
            $sql1 = 'insert t_app_appprogram(programid,modelid,appid) values';
            foreach ($post['program'] as $val) {
                $sql1 .= "({$val['id']},'{$val['modelId']}',{$getID}),";
            }
            $sql1 = rtrim($sql1, ",").';';
            if(!$this->db->execute($sql1)) {
                $this->db->rollback();
                return false;
            }
        }
        $this->db->commit();
        return true;
    }
    
    public function updateByPost($post)
    {
        $d_sql = "select * from {$this->tableName} where id={$post['app']['id']}";
        $d_ret = $this->db->fetchOne($d_sql, 1);
        if ($d_ret['name'] != $post['app']['name']) {
            $f_name = "select name from {$this->tableName} where name='{$post['app']['name']}' and useridalias='{$_SESSION['rbac']['idAlias']}'";
            $ret_name = $this->db->fetchOne($f_name, 1);
            if ($ret_name) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'The current user has created the same name application'
                    )
                );
                exit();
            }
        }
        if ($d_ret['number'] != $post['app']['number']) {
            $f_number = "select number from {$this->tableName} where number='{$post['app']['number']}' and useridalias='{$_SESSION['rbac']['idAlias']}'";
            $ret_number = $this->db->fetchOne($f_number, 1);
            if ($ret_number) {
                echo json_encode(
                    array(
                        'statusCode' => 300,
                        'message' => 'The current user has created the same numbering application'
                    )
                );
                exit();
            }
        }
        $zero = date("y-m-d H:i:s");
        $post['app']['description'] = str_replace(array("\r\n", "\r", "\n"), ' ', $post['app']['description']);
        $sql = "update {$this->tableName} set number = '{$post['app']['number']}', `name` = '{$post['app']['name']}',
            `type` = {$post['app']['type']},appIndex = {$post['app']['appIndex']},version = '{$post['app']['version']}',
            description = '{$post['app']['description']}',`modifier` = '{$_SESSION['rbac']['id']}',
            updateTime = '$zero' where id = {$post['app']['id']};";
        $this->db->begin();
        if(!$this->db->execute($sql)) {
            $this->db->rollback();
            return false;
        }
        //删掉t_param_paramtemp表中paramTempId的数据
        $sql = "delete from t_app_appprogram where appid = {$post['app']['id']};";
        if(!$this->db->execute($sql)) {
            $this->db->rollback();
            return false;
        }
        if(!empty($post['program'])) {
            $sql = 'insert into t_app_appprogram(programid,modelid,appid) values';
            foreach ($post['program'] as $val) {
                $sql .= "({$val['id']},{$val['modelId']},{$post['app']['id']}),";
            }
            $sql = rtrim($sql, ",").';';
            if(!$this->db->execute($sql)) {
                $this->db->rollback();
                return false;
            }
        }
        $this->db->commit();
        return true;
    }
    
    public function remove($id)
    {
        $id = $id['param'][id];
        $f_sql = "select id from t_app_apptemp where appId={$id}";
        $f_ret = $this->db->fetchOne($f_sql, 1);
        if ($f_ret) {
            $ret = array('statusCode'=>300,'message'=>'The application has been associated with the application template and cannot be deleted');
            echo json_encode($ret);
            exit();
        }
        $sql = "DELETE FROM {$this->tableName} WHERE id = {$id}";
        $sql .= $this->param();
        $sql .= ";DELETE FROM t_app_appprogram WHERE appid = {$id};";
        //echo $sql;die;
        //$this->_logger->log($sql, \Phalcon\Logger::INFO);
        if($this->db->execute($sql)){
            $this->_afterRemoveDbByPkv($id);
            return array('success' => 1);
        } else{
            return array('success' => 0, 'errorCode' => 0, 'message' => '0');
        }
    }
}