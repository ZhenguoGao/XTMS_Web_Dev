<?php

/**
 * 终端上送状态
 *  
 * @author zhaimin
 */

class TerminalexceptionSoa extends ModelSoa2
{
    public $order = array('field'=>'id','direction'=>'desc');
    public $method = array(
    	//'index'	=> 'terminalException/getAll',
    	'index'	=> 'terminalexception/search',
    );
}