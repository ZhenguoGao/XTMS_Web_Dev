<?php

/**
* 终端信息触发查询
* lujun
*/
class TerminaltriggerNew extends ModelBase1
{
    var $tableName = 't_bd_cpuexception';
    var $pareTable = array(
        'getColumns'=>array('id','terminalId','machineId','continuedCount','lastHappenReason','lastHappenTime','createTime'),
        'lookupfield'=>array('machineId'),
    );
    
    var $foreignTable = array(
        'machineId' => array(
            'tableName' => 't_bd_terminal',
            'mappingKey' => 'machineId',
            'displayKey' => array('machineId as aaa'),
        ),
    );
    
    var $primaryKey = 'id';
    var $order = array('field'=>'id','direction'=>'desc');
}