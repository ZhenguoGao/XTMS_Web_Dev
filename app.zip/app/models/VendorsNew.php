<?php

/**
 * merchant
 *  
 * @author lujun
 */

class VendorsNew extends ModelBase1
{
    var $pareTable = array(
        'getColumns'=>array('id','vendor_name','vendor_code','createdate'),
        'lookupfield'=>array('vendor_name','vendor_code')
    );
    
    var $primaryKey = 'id';
    var $order = array('field'=>'id','direction'=>'desc');
    var $uniqueFields = array('vendor_name');
    
    public function getSource()
    {
        return 'T_VENDORS';
    }
    
    public function getPK()
    {
        return 'id';
    }
}