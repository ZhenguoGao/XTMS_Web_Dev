<?php

/**
 * public
 *  
 * @author zhaimin
 */

class PublicSoa extends ModelSoa
{
    /**
    public $method = array(
    	'getMachineType'    =>	'model/getAll',
        'getSupplier'       =>	'supplier/getAll',
    	'getRegion'         =>	'region/getAll',
    	'getexpressCompany' =>	'expressCompany/getAll'
    );
    **/
    public $method = array(
        'getMachineType'    =>	'devicetype/getAll',
        'getSupplier'       =>	'supplier/getAll',
        'getRegion'         =>	'region/getAll',
        'getexpressCompany' =>	'expressCompany/getAll',
        'getUser'           =>  'user/getUser',
        'getArea'           =>	'region/getArea',
    );
}