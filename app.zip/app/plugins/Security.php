<?php

class Security extends Phalcon\Mvc\User\Plugin
{

    /**
     * @var Phalcon\Acl\Adapter\Memory
     */
    protected $_acl;

    public function __construct($dependencyInjector)
    {
        $this->_dependencyInjector = $dependencyInjector;
    }

    /**
     * This action is executed before execute any action in the application
     */
    public function beforeDispatch(Phalcon\Events\Event $event, Phalcon\Mvc\Dispatcher $dispatcher)
    {
        $session_name = session_name();
        if (isset($_POST[$session_name])) {
            session_id($_POST[$session_name]);
            $keys = explode(',', $_POST['session_keys']);
            $session = array();
            foreach ($keys as $key) {
                $session[$key] = null == $_POST[$key] ? "" : $_POST[$key];
            }
            $this->session->set('rbac', $session);
        }

        $auth  = $this->session->get('rbac');
        $ctrl = strtolower($dispatcher->getControllerName());
        if ( $ctrl != "login" && $ctrl != "board" ) {
            if (!isset($_SESSION['rbac']) || empty($auth)) {
                $ret = array('statusCode'=>'301');
                exit(json_encode($ret));
            }
        }
        return true;
    }

}