<?php

return new \Phalcon\Config(array(
	'application' => array(
		'controllersDir' => __DIR__ . '/../../app/controllers/',
		'modelsDir'      => __DIR__ . '/../../app/models/',
		'viewsDir'       => __DIR__ . '/../../app/views/',
		'pluginsDir'     => __DIR__ . '/../../app/plugins/',
		'libraryDir'     => __DIR__ . '/../../app/library/',
		'baseUri'        => '/',
	),
	'models' => array(
		'metadata' => array(
			'adapter' => 'Memory'
		)
	),
	'default_supplierid' => 1,	//默认厂商ID
	'productId' => '10001',
	'communicateWay' => '{"1":"Telephone", "2":"Mobile", "3":"Network", "4":"Unicom", "5":"Telecom"}',
	'communicateWay_f' => '{"1":"Telephone", "2":"GPRS", "3":"Network", "4":"GPRS", "5":"CDMA"}',
	'merchantType' => '{"1":"Direct", "2":"Deposit", "3":"Chain", "4":"Agency", "5":"Spare", "6":"Virtual level 1"}',
	'defaultLang'	=> 'en-us',
	
	/* JAVA 接口配置 */
	// 'soa'=>'http://172.20.0.16:8080/tms/', //yuwenjun
	//'soa'=>'http://172.23.0.212:8080/xtms/', // richard
	//'soa'=>'http://10.14.18.122:8080/xtms/', // richard
    //'soa'=>'http://s.inextpos.com:8080/xtms/',  // aliyun
   'soa'=>'http://127.0.0.1:8080/xtms/',
    //'soa' => 'http://123.58.32.121:12226',
	// 'soa'=>'http://172.20.0.147:8080/tms/', //lisheng
	// 'soa'=> 'http://172.18.0.72:19000/tms/'
	'amapKey' => 'fb1612d4336cb112807aa9620fa9bc16',   //高德地图接口的Key
));
