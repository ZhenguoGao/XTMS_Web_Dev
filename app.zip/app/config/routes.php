<?php

$router = new Phalcon\Mvc\Router();

//Individually
$router->setDefaultController("login");

$router->add("/set-language/{language:[a-z]+}", array(
    'controller' => 'index',
    'action' => 'setLanguage'
));
