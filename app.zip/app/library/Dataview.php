<?php
/**
 *
 * @author huanggz
 * @version 1.0
 */

/**
 * {Dataview} Libray 
 * 
 * @uses all data grid {Dataview}
 */
class Dataview extends Phalcon\Mvc\User\Component
{
    
}
