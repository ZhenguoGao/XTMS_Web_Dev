<?php

/**
 * Elements
 *
 * Helps to build UI elements for the application
 */
class Elements extends Phalcon\Mvc\User\Component
{
    /**
     * Builds left menu with items
     *
     * @return array
     */
    public function getMenu()
    {
    	$usercrm = new Usercrm;
    	$user = $this->session->get('rbac');
    	$userid = $user['userid'];
    	$userlevel = $user['userlevel'];
        
    	$result = $usercrm->makeMenu($userid, $userlevel);
    	return $result;
    	
    	$ctrl = array('login','board','lookup','chgpwd');
    	foreach ($result as $re)
    	{
    		if(!empty($re['menuurl']) && $re['menuurl']!='null' )
    			$ctrl[] = strtolower( substr($re['menuurl'], 0, stripos($re['menuurl'],'/')) );
    	}
    	$_SESSION['rbac']['grants']=implode($ctrl, ',');
        return $result;
    }
    
	/*public function getMenu()
    {
    	$user = $this->session->get('rbac');
    	$userid = $user['userid'];
    	$userlevel = $user['userlevel'];
    	
    	if($userlevel=='1')
    		$sql ="SELECT menuid,parentid,menucode,menuname,menuurl,isshow FROM tms_user2.T_MENU where status='1' ORDER BY ORDERCODE";

    	elseif($userlevel=='2')
    		$sql ="SELECT menuid,parentid,menucode,menuname,menuurl,isshow FROM tms_user2.T_MENU ORDER BY ORDERCODE";
    		
        else
        $sql = "SELECT T_MENU.menuid, T_MENU.parentid, T_MENU.menucode, T_MENU.menuname, T_MENU.menuurl FROM T_MENU 
    			LEFT JOIN T_ROLE_MENU_RIGHT ON T_ROLE_MENU_RIGHT.menuid=T_MENU.menuid
    			LEFT JOIN T_USER_ROLE_REF ON T_USER_ROLE_REF.roleid=T_ROLE_MENU_RIGHT.roleid
    			WHERE 1=1 AND T_MENU.status='1' AND isshow='1' AND T_USER_ROLE_REF.userid={$userid} ORDER BY T_MENU.ordercode";
        
    	$result = $this->tms->fetchAll($sql);
    	
    	$ctrl = array('login','board','lookup','chgpwd');
    	foreach ($result as $re)
    	{
    		if(!empty($re['menuurl']) && $re['menuurl']!='null' )
    			$ctrl[] = strtolower( substr($re['menuurl'], 0, stripos($re['menuurl'],'/')) );
    	}
    	$_SESSION['rbac']['grants']=implode($ctrl, ',');
        return $result;
    }*/
}
